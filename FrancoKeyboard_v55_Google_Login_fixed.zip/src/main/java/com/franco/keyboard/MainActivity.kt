package com.franco.keyboard

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun styledButton(text: String, action: () -> Unit): TextView {
        val b = TextView(this)
        b.text = text
        b.setTextColor(Color.WHITE)
        b.textSize = 18f
        b.gravity = Gravity.CENTER
        val g = GradientDrawable()
        g.cornerRadius = dp(28).toFloat()
        g.setColor(Color.parseColor("#B33F51B5"))
        g.setStroke(dp(1), Color.parseColor("#80FFFFFF"))
        b.background = g
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(56))
        lp.setMargins(0, dp(8), 0, dp(8))
        b.layoutParams = lp
        b.setOnClickListener { action() }
        return b
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.BLACK
        window.decorView.systemUiVisibility =
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN

        val root = FrameLayout(this)

        val bg = ImageView(this)
        bg.setImageResource(R.drawable.bg)
        bg.scaleType = ImageView.ScaleType.CENTER_CROP
        root.addView(bg, FrameLayout.LayoutParams(-1, -1))

        val scrim = FrameLayout(this)
        scrim.setBackgroundColor(Color.parseColor("#33000000"))
        root.addView(scrim, FrameLayout.LayoutParams(-1, -1))

        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.gravity = Gravity.CENTER
        col.setPadding(dp(32), 0, dp(32), 0)
        col.addView(styledButton("تسجيل الدخول بحساب Google") {
            startActivity(Intent(this, LoginActivity::class.java))
        })
        col.addView(styledButton("تفعيل الكيبورد") {
            startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS))
        })
        col.addView(styledButton("اختيار الكيبورد") {
            val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
            imm.showInputMethodPicker()
        })
        col.addView(styledButton("إعدادات الكيبورد") {
            startActivity(Intent(this, SettingsActivity::class.java))
        })
        root.addView(col, FrameLayout.LayoutParams(-1, -1))

        val links = TextView(this)
        links.text = "Telegram:@GIGA_UP\ndiscord:giga_up"
        links.setTextColor(Color.WHITE)
        links.textSize = 14f
        links.setShadowLayer(6f, 0f, 0f, Color.BLACK)
        val lp = FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )
        lp.gravity = Gravity.BOTTOM or Gravity.START
        lp.setMargins(dp(16), 0, 0, dp(20))
        root.addView(links, lp)

        setContentView(root)
    }
}
