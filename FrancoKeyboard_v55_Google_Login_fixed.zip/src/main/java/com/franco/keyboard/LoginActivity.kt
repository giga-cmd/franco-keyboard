package com.franco.keyboard

import android.app.Activity
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInClient
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.android.gms.common.api.ApiException
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.AuthResult
import com.google.firebase.auth.GoogleAuthProvider
import com.google.android.gms.tasks.Task

class LoginActivity : Activity() {

    companion object {
        private const val RC_GOOGLE_SIGN_IN = 1001
    }

    private lateinit var auth: FirebaseAuth
    private lateinit var googleClient: GoogleSignInClient
    private lateinit var status: TextView

    private fun dp(value: Int): Int =
        (value * resources.displayMetrics.density).toInt()

    private fun button(text: String, onClick: () -> Unit): TextView {
        val view = TextView(this)
        view.text = text
        view.textSize = 17f
        view.gravity = Gravity.CENTER
        view.setTextColor(Color.WHITE)
        val background = GradientDrawable()
        background.cornerRadius = dp(28).toFloat()
        background.setColor(Color.rgb(66, 133, 244))
        view.background = background
        view.setPadding(dp(18), 0, dp(18), 0)
        view.setOnClickListener { onClick() }
        val params = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            dp(56)
        )
        params.setMargins(0, dp(12), 0, 0)
        view.layoutParams = params
        return view
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        auth = FirebaseAuth.getInstance()
        val options = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
            .requestIdToken(getString(R.string.default_web_client_id))
            .requestEmail()
            .build()
        googleClient = GoogleSignIn.getClient(this, options)

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.gravity = Gravity.CENTER
        root.setPadding(dp(28), dp(24), dp(28), dp(24))
        root.setBackgroundColor(Color.rgb(25, 25, 35))

        val title = TextView(this)
        title.text = "تسجيل الدخول"
        title.textSize = 28f
        title.gravity = Gravity.CENTER
        title.setTextColor(Color.WHITE)
        root.addView(title, LinearLayout.LayoutParams(-1, dp(60)))

        status = TextView(this)
        status.text = "سجّل الدخول بحساب Google لاستخدام ميزات AI"
        status.textSize = 16f
        status.gravity = Gravity.CENTER
        status.setTextColor(Color.LTGRAY)
        root.addView(status, LinearLayout.LayoutParams(-1, dp(60)))

        root.addView(button("المتابعة باستخدام Google") {
            startGoogleSignIn()
        })

        root.addView(button("رجوع") {
            finish()
        })

        setContentView(root)
    }

    private fun startGoogleSignIn() {
        status.text = "جاري فتح تسجيل الدخول..."
        startActivityForResult(googleClient.signInIntent, RC_GOOGLE_SIGN_IN)
    }

    @Deprecated("Deprecated in Android API; kept for compatibility with the Google Sign-In flow")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: android.content.Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != RC_GOOGLE_SIGN_IN) return

        val task = GoogleSignIn.getSignedInAccountFromIntent(data)
        try {
            val account = task.getResult(ApiException::class.java)
            val idToken = account.idToken
            if (idToken.isNullOrBlank()) {
                showError("لم يتم استلام بيانات Google")
                return
            }
            firebaseAuthWithGoogle(idToken, account.email)
        } catch (error: ApiException) {
            showError("فشل تسجيل الدخول: ${error.statusCode}")
        }
    }

    private fun firebaseAuthWithGoogle(idToken: String, email: String?) {
        status.text = "جاري تأكيد الحساب..."
        val credential = GoogleAuthProvider.getCredential(idToken, null)
        auth.signInWithCredential(credential)
            .addOnCompleteListener(this) { result: Task<AuthResult> ->
                if (result.isSuccessful) {
                    val user = auth.currentUser
                    val name = user?.displayName ?: email ?: "المستخدم"
                    Toast.makeText(this, "تم تسجيل الدخول باسم $name", Toast.LENGTH_LONG).show()
                    finish()
                } else {
                    showError("تعذر ربط الحساب بـFirebase")
                }
            }
    }

    private fun showError(message: String) {
        status.text = message
        Toast.makeText(this, message, Toast.LENGTH_LONG).show()
    }
}
