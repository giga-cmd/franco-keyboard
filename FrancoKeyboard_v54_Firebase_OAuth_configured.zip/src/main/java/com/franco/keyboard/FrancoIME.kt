package com.franco.keyboard

import android.Manifest
import android.content.ClipboardManager
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.widget.Toast
import android.text.Editable
import android.text.TextWatcher
import android.view.inputmethod.BaseInputConnection
import android.widget.EditText
import org.json.JSONArray
import android.media.AudioManager
import android.os.VibrationEffect
import android.os.Vibrator
import android.graphics.Matrix
import android.graphics.SurfaceTexture
import android.graphics.drawable.InsetDrawable
import android.media.MediaPlayer
import android.view.Surface
import android.view.TextureView
import android.os.SystemClock
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import org.json.JSONObject
import android.content.Context
import android.content.Intent
import android.content.ClipDescription
import android.content.ContentUris
import android.database.ContentObserver
import android.net.Uri
import android.provider.MediaStore
import android.graphics.Typeface
import android.view.inputmethod.InputContentInfo
import android.content.SharedPreferences
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.inputmethodservice.InputMethodService
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.text.TextUtils
import android.util.TypedValue
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputConnection
import android.view.inputmethod.InputMethodManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ImageView
import android.widget.ScrollView
import android.widget.TextView
import java.io.File

class FrancoIME : InputMethodService() {

    companion object {
        const val L_AR = 0
        const val L_EN = 1
        const val L_SYM1 = 2
        const val L_SYM2 = 3
        const val L_NUM = 4
        const val L_CLIP = 5
        const val L_EMO = 6
        const val L_PANEL = 7
        const val L_LANG = 8
        const val L_FR = 9
        const val L_F2A = 10
        const val L_DECO = 11

        const val C_BG = "#1B1B1F"
        const val C_KEY = "#3C3C45"
        const val C_FUNC = "#55555F"
        const val C_PRESS = "#7A7A88"
        const val C_ACCENT = "#3F51B5"
        const val C_GREEN = "#2E7D32"
    }

    private var layer = L_AR
    private var baseLayer = L_AR
    private var vibrator: Vibrator? = null
    private var audio: AudioManager? = null
    private var shift = 0
    private var lastShiftTap = 0L
    private var francoOn = true
    private var curPkg = ""

    private val handler = Handler(Looper.getMainLooper())
    private var content: LinearLayout? = null
    private var toggleBtn: TextView? = null
    private var overlay: FrameLayout? = null
    private var pill: LinearLayout? = null
    private var bgImage: ImageView? = null
    private var bgVideo: LoopVideoView? = null
    private var bgScrim: View? = null
    private var bgOn = false
    private var keyAlpha = 255
    private var bgStamp = -1L
    private var kbFrame: KbFrame? = null
    private var resizeLayer: FrameLayout? = null
    private var resizeMode = false
    private var hScale = 1f
    private var kbL = 0f
    private var kbR = 1f
    private var chipView: TextView? = null
    private var autoBtn: TextView? = null
    private var emoData: LinkedHashMap<String, List<String>>? = null
    private val emoRecent = ArrayList<String>()
    private var emoCat = "smileys"
    private var prevLayer = L_AR
    private val popupViews = ArrayList<TextView>()
    private var repeatTask: Runnable? = null

    // الكلمة الحالية: بالعربي وبالإنجليزي اللي اتكتب لحد دلوقتي
    private val wordAr = StringBuilder()
    private var wordFr = ""

    // قاموس الكلمات والأسماء
    private val dict = HashMap<String, String>()

    // الحافظة
    private val clips = ArrayList<String>()
    private var prefs: SharedPreferences? = null
    private val clipListener = ClipboardManager.OnPrimaryClipChangedListener { grabClip(true) }

    // نص اتمسح من الحافظة: ما نرجعوش من حافظة النظام غير لما يتنسخ تاني
    private var ignoredClip: String? = null

    // الكتابة بالصوت
    private var recognizer: SpeechRecognizer? = null
    private var listening = false
    private var micBtn: TextView? = null

    // تصحيح أونلاين (LanguageTool): مجاني، بيبعت الكلمة نفسها بس
    private var onlineAllowed = true
    private var transAllowed = true
    private var calcExpr = ""
    private var calcRes = ""
    private var autoEnApplied = false
    private var layerBeforeAuto = L_AR
    private var clipChip: String? = null

    // وضع الترجمة: الكتابة بتروح لخانة صغيرة وبتتترجم وبتتكتب في التطبيق
    private var transMode = false
    private var transSrc = "ar"
    private var transTgt = "en"
    private var transSeq = 0
    private var transOut = ""
    private var savedFranco = true
    private var transField: EditText? = null
    private var transBox: LinearLayout? = null
    private var transSrcChip: TextView? = null
    private var transTgtChip: TextView? = null
    private var transConn: InputConnection? = null
    private val transRun = Runnable { doTranslate() }
    private val transLangs = listOf("ar", "en", "fr", "de", "es", "tr", "it", "ru", "pt", "zh-CN", "ja", "ko", "hi", "fa", "ur", "nl", "id")
    private val transNames = mapOf(
        "ar" to "العربية", "en" to "الإنجليزية", "fr" to "الفرنسية", "de" to "الألمانية",
        "es" to "الإسبانية", "tr" to "التركية", "it" to "الإيطالية", "ru" to "الروسية",
        "pt" to "البرتغالية", "zh-CN" to "الصينية", "ja" to "اليابانية", "ko" to "الكورية", "hi" to "الهندية",
        "fa" to "الفارسية", "ur" to "الأردية", "nl" to "الهولندية", "id" to "الإندونيسية"
    )

    private class TransConn(val f: EditText) : BaseInputConnection(f, true) {
        override fun getEditable(): Editable = f.text
    }

    override fun getCurrentInputConnection(): InputConnection? {
        return if (transMode) (transConn ?: super.getCurrentInputConnection()) else super.getCurrentInputConnection()
    }
    private var midMode = 0


    // ---- لقطة الشاشة (بتظهر في شريط الاقتراحات زي الكيبورد العادي) ----
    private var shotUri: Uri? = null
    private var shotMime = "image/png"
    private var shotId = -1L
    private var shotHandledId = -1L
    private val shotExpire = Runnable {
        shotUri = null
        scheduleSug()
    }
    private val shotObserver = object : ContentObserver(Handler(Looper.getMainLooper())) {
        override fun onChange(selfChange: Boolean) {
            checkShot()
        }
    }
    private var onlineBusy = false
    private var onlineLast = 0L
    private val onlineCache = HashMap<String, String?>()

    // حروف الفرانكو للكلمات اللي مش في القاموس (عدّل فيها زي ما تحب)
    private val consonants: Map<Char, String> = mapOf(
        'ب' to "b", 'ت' to "t", 'ث' to "th", 'ج' to "g",
        'ح' to "7", 'خ' to "5", 'د' to "d", 'ذ' to "z",
        'ر' to "r", 'ز' to "z", 'س' to "s", 'ش' to "sh",
        'ص' to "9", 'ض' to "d", 'ط' to "6", 'ظ' to "z",
        'ع' to "3", 'غ' to "gh", 'ف' to "f", 'ق' to "2",
        'ك' to "k", 'ل' to "l", 'م' to "m", 'ن' to "n",
        'ه' to "h", 'ء' to "2", 'ؤ' to "2", 'ئ' to "2"
    )

    // نهايات الكلمات (ضمائر) وطريقة كتابتها
    private val suffixes: List<Pair<String, String>> = listOf(
        Pair("كم", "kom"), Pair("هم", "hom"), Pair("ها", "ha"),
        Pair("ني", "ni"), Pair("نا", "na"), Pair("ك", "ak"), Pair("ه", "o")
    )

    // قائمة الضغط المطوّل على النقطة: تشكيل + علامات ترقيم
    private val dotOpts: List<String> = listOf(
        "َ", "ُ", "ِ", "ً", "ٌ", "ٍ",
        "ّ", "ْ", "ـ", "؟", "!", "؛",
        ":", "\"", "'", "-", "(", ")"
    )

    // ------------------------------------------------------------------
    // دورة حياة الخدمة
    // ------------------------------------------------------------------

    override fun onCreate() {
        super.onCreate()
        loadDict("words_default.txt")
        loadDict("words_user.txt")
        prefs = getSharedPreferences("franco", Context.MODE_PRIVATE)
        prefs?.registerOnSharedPreferenceChangeListener(prefListener)
        loadClips()
        ignoredClip = prefs?.getString("clip_ignored", null)
        loadPins()
        autoOn = prefs?.getBoolean("autocorrect", true) ?: true
        francoOn = prefs?.getBoolean("franco_start", true) ?: true
        loadNoCorrect()
        buildNear()
        Thread { loadSpell() }.start()
        try {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.addPrimaryClipChangedListener(clipListener)
        } catch (e: Exception) {
            // مش مهم
        }
        try {
            contentResolver.registerContentObserver(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, true, shotObserver)
        } catch (e: Exception) {
            // مش مهم
        }
    }

    private val prefListener = android.content.SharedPreferences.OnSharedPreferenceChangeListener { _, k ->
        if (k == "txt_color" || k == "txt_custom" || k == "txt_hue" || k == "txt_sat" || k == "txt_val" || k == "font_weight" || k == "theme" || k == "font_file") {
            handler.post { if (content != null) render() }
        }
    }

    override fun onDestroy() {
        try {
            prefs?.unregisterOnSharedPreferenceChangeListener(prefListener)
        } catch (e: Exception) {
            // مش مهم
        }
        try {
            contentResolver.unregisterContentObserver(shotObserver)
        } catch (e: Exception) {
            // مش مهم
        }
        bgVideo?.stop()
        try {
            recognizer?.destroy()
        } catch (e: Exception) {
            // مش مهم
        }
        recognizer = null
        try {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.removePrimaryClipChangedListener(clipListener)
        } catch (e: Exception) {
            // مش مهم
        }
        super.onDestroy()
    }

    override fun onEvaluateFullscreenMode(): Boolean = false

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        if (!restarting && transMode) exitTrans()
        if (restarting) stateRestored = true
        if (!restarting) {
            val pr = prefs
            if (pr != null && pr.getBoolean("remember_last", true) && pr.contains("last_layer")) {
                val ll = pr.getInt("last_layer", L_AR)
                if (ll == L_AR || ll == L_EN || ll == L_FR) {
                    baseLayer = ll
                    layer = ll
                }
                francoOn = pr.getBoolean("last_franco", francoOn)
            }
            stateRestored = true
            curPkg = info?.packageName ?: ""
            val k = "fa_" + curPkg
            if (curPkg.isNotEmpty() && prefs?.getBoolean("fr_per_app", false) == true && prefs?.contains(k) == true) {
                francoOn = prefs?.getBoolean(k, true) ?: true
            }
        }
        resetWord()
        if (!restarting) {
            loadLearn()
            prevWord = null
        }
        applyBackground()
        applyLayoutPrefs()
        applyRgb()
        render()
        val cls = (info?.inputType ?: 0) and InputType.TYPE_MASK_CLASS
        val variation = (info?.inputType ?: 0) and InputType.TYPE_MASK_VARIATION
        // الترجمة بتشتغل في المتصفح وخانات الروابط، ومش في الباسورد والإيميل
        transAllowed = !(
            (cls == InputType.TYPE_CLASS_TEXT && (
                variation == InputType.TYPE_TEXT_VARIATION_PASSWORD ||
                    variation == InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD ||
                    variation == InputType.TYPE_TEXT_VARIATION_WEB_PASSWORD ||
                    variation == InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS ||
                    variation == InputType.TYPE_TEXT_VARIATION_WEB_EMAIL_ADDRESS)) ||
                (cls == InputType.TYPE_CLASS_NUMBER && variation == InputType.TYPE_NUMBER_VARIATION_PASSWORD)
            )
        onlineAllowed = !(
            (cls == InputType.TYPE_CLASS_TEXT && (
                variation == InputType.TYPE_TEXT_VARIATION_PASSWORD ||
                    variation == InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD ||
                    variation == InputType.TYPE_TEXT_VARIATION_WEB_PASSWORD ||
                    variation == InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS ||
                    variation == InputType.TYPE_TEXT_VARIATION_URI)) ||
                (cls == InputType.TYPE_CLASS_NUMBER && variation == InputType.TYPE_NUMBER_VARIATION_PASSWORD)
            )
        if (cls == InputType.TYPE_CLASS_NUMBER || cls == InputType.TYPE_CLASS_PHONE) {
            layer = L_NUM
        } else if (layer == L_NUM || layer == L_CLIP || layer == L_EMO || layer == L_PANEL || layer == L_LANG || layer == L_F2A || layer == L_DECO) {
            layer = baseLayer
        }
        if (!restarting) {
            val special = cls == InputType.TYPE_CLASS_TEXT && (
                variation == InputType.TYPE_TEXT_VARIATION_URI ||
                    variation == InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS ||
                    variation == InputType.TYPE_TEXT_VARIATION_WEB_EMAIL_ADDRESS ||
                    variation == InputType.TYPE_TEXT_VARIATION_PASSWORD ||
                    variation == InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD ||
                    variation == InputType.TYPE_TEXT_VARIATION_WEB_PASSWORD)
            if (special && prefs?.getBoolean("auto_en", true) != false) {
                if (layer != L_EN) {
                    layerBeforeAuto = layer
                    autoEnApplied = true
                    layer = L_EN
                }
            } else if (autoEnApplied) {
                autoEnApplied = false
                if (layer == L_EN) layer = layerBeforeAuto
            }
        }
        grabClip()
        askShotPermissionOnce()
        checkShot()
        render()
        handler.postDelayed({ currentInputConnection?.let { autoCapital(it) } }, 80)
        val pending = prefs?.getBoolean("resize_pending", false) ?: false
        if (pending) {
            prefs?.edit()?.putBoolean("resize_pending", false)?.apply()
            handler.postDelayed({ enterResizeMode() }, 300)
        }
    }

    private var lastSavedLay = -1
    private var lastSavedFr = -1

    // بيحفظ آخر وضع (عربي/إنجليزي/فرانكو) عشان يفتح عليه
    private var stateRestored = false

    private fun saveLastState() {
        if (!stateRestored || transMode || autoEnApplied) return
        val l = baseLayer
        if (l != L_AR && l != L_EN && l != L_FR) return
        val f = if (francoOn) 1 else 0
        if (l == lastSavedLay && f == lastSavedFr) return
        lastSavedLay = l
        lastSavedFr = f
        prefs?.edit()?.putInt("last_layer", l)?.putBoolean("last_franco", francoOn)?.apply()
    }

    override fun onFinishInputView(finishingInput: Boolean) {
        saveLastState()
        if (transMode && finishingInput) exitTrans()
        val pend0 = currentRaw().first
        if (pend0.isNotEmpty()) learnWord(pend0)
        bgVideo?.pause()
        saveLearn()
        stopVoice()
        exitResizeMode(true)
        dismissPopup()
        super.onFinishInputView(finishingInput)
    }

    // ------------------------------------------------------------------
    // القاموس والتحويل لفرانكو
    // ------------------------------------------------------------------

    private fun loadDict(name: String) {
        try {
            assets.open(name).bufferedReader(Charsets.UTF_8).useLines { lines ->
                for (line in lines) {
                    val t = line.trim()
                    if (t.isEmpty() || t.startsWith("#")) continue
                    val idx = t.indexOf('=')
                    if (idx <= 0) continue
                    val key = normalize(t.substring(0, idx).trim())
                    val value = t.substring(idx + 1).trim()
                    if (key.isNotEmpty() && value.isNotEmpty()) dict[key] = value
                }
            }
        } catch (e: Exception) {
            // الملف مش موجود: عادي
        }
    }

    private fun normalize(s: String): String {
        val sb = StringBuilder()
        for (c in s) {
            when (c) {
                'أ', 'إ', 'آ' -> sb.append('ا')
                'ى' -> sb.append('ي')
                'ة' -> sb.append('ه')
                else -> sb.append(c)
            }
        }
        return sb.toString()
    }

    private fun isMark(c: Char): Boolean = c in '\u064B'..'\u0652'

    private fun hasMarks(w: String): Boolean {
        for (c in w) {
            if (isMark(c)) return true
        }
        return false
    }

    private fun translateSelection() {
        if (prefs?.getBoolean("trans_on", true) == false) {
            toast("الترجمة مقفولة من الإعدادات")
            return
        }
        if (!transAllowed) {
            toast("الترجمة مش متاحة في الخانة دي")
            return
        }
        val ic = currentInputConnection ?: return
        val sel = ic.getSelectedText(0)?.toString()
        if (sel.isNullOrBlank()) {
            toast("حدد نص الأول")
            return
        }
        if (sel.length > 1500) {
            toast("النص طويل للترجمة")
            return
        }
        var arN = 0
        var letters = 0
        for (ch in sel) {
            if (ch.isLetter()) letters++
            if (ch in 'ء'..'ي') arN++
        }
        val toEn = letters > 0 && arN * 2 >= letters
        val src = if (toEn) "ar" else "en"
        val tgt = if (toEn) "en" else "ar"
        toast("بترجم...")
        Thread {
            val res = translateText(sel, src, tgt)
            handler.post {
                if (res == null) {
                    toast("الترجمة مش شغالة (النت؟)")
                } else {
                    val ic2 = currentInputConnection
                    if (ic2 != null && ic2.getSelectedText(0)?.toString() == sel) {
                        ic2.commitText(res, 1)
                    } else {
                        toast("المحدد اتغيّر")
                    }
                }
            }
        }.start()
    }


    // ------------------------------------------------------------------
    // تلخيص النص (من غير نت)
    // ------------------------------------------------------------------

    private fun clipText(): String {
        return try {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            val clip = cm.primaryClip
            if (clip != null && clip.itemCount > 0) clip.getItemAt(0).coerceToText(this)?.toString() ?: "" else ""
        } catch (e: Exception) {
            ""
        }
    }

    // المحدد، ولو مفيش فالخانة كلها (وبتتبدّل بالملخص)، ولو الخانة فاضية فالمنسوخ (وبيتكتب)

    // ------------------------------------------------------------------
    // زخرفة النص: المحدد أو آخر كلمة، بأشكال مختلفة
    // ------------------------------------------------------------------

    private var decoSrc = ""
    private var decoCur = ""

    private val decoEn = listOf(
        "bold", "script", "fraktur", "sans", "mono", "bolditalic",
        "circle", "wide", "small", "dots", "spaced",
        "w1", "w2", "w3", "w4", "w5", "w6", "w7", "w8",
        "sup", "under", "strike", "neg", "sq", "a1", "a2", "a3", "a4", "a5"
    )
    private val decoAr = listOf(
        "en:sans", "en:sansl", "en:bold", "en:wide",
        "en:script", "en:fraktur", "en:circle", "en:mono",
        "fr:sans", "fr:sansl", "fr:bold", "fr:wide",
        "fr:script", "fr:fraktur", "fr:circle", "fr:mono",
        "tatweel", "tw2", "tw3", "harakat",
        "dots", "spaced", "w1", "w2",
        "w3", "w4", "under", "strike", "a2"
    )

    private fun isArabicText(t: String): Boolean {
        var ar = 0
        var other = 0
        for (ch in t) {
            if (ch in 'ء'..'ي') ar++ else if (ch.isLetter()) other++
        }
        return ar >= other
    }

    private fun joinChars(src: String, sep: String): String {
        val sb = StringBuilder()
        for ((i, ch) in src.withIndex()) {
            sb.append(ch)
            if (i + 1 < src.length && !ch.isWhitespace() && !src[i + 1].isWhitespace()) sb.append(sep)
        }
        return sb.toString()
    }

    private fun mapAlpha(src: String, up: Int, lo: Int, dg: Int): String {
        val sb = StringBuilder()
        for (ch in src) {
            when {
                ch in 'A'..'Z' -> sb.appendCodePoint(up + (ch - 'A'))
                ch in 'a'..'z' -> sb.appendCodePoint(lo + (ch - 'a'))
                ch in '0'..'9' && dg > 0 -> sb.appendCodePoint(dg + (ch - '0'))
                else -> sb.append(ch)
            }
        }
        return sb.toString()
    }

    // الكلمة العربي بحروف لاتينية: فرانكو (بأرقام 7 و3) أو إنجليزي (حروف بس)
    private fun translit(src: String, letters: Boolean): String {
        val sb = StringBuilder()
        val w = StringBuilder()
        fun flush() {
            if (w.isEmpty()) return
            var r = convertWordBase(w.toString())
            if (letters) {
                val t = StringBuilder()
                for (c in r) {
                    when (c) {
                        '3' -> t.append("a")
                        '7' -> t.append("h")
                        '5' -> t.append("kh")
                        '6' -> t.append("t")
                        '9' -> t.append("s")
                        '8' -> t.append("gh")
                        '2' -> t.append("'")
                        else -> t.append(c)
                    }
                }
                r = t.toString()
                if (r.isNotEmpty()) r = r.substring(0, 1).uppercase() + r.substring(1)
            }
            sb.append(r)
            w.setLength(0)
        }
        for (c in src) {
            if (c in 'ء'..'ي' || isMark(c)) {
                w.append(c)
            } else {
                flush()
                sb.append(c)
            }
        }
        flush()
        return sb.toString()
    }

    private fun decorate(src: String, st: String): String {
        if (st.startsWith("en:")) return decorate(translit(src, true), st.substring(3))
        if (st.startsWith("fr:")) return decorate(translit(src, false), st.substring(3))
        return when (st) {
            "bold" -> mapAlpha(src, 0x1D400, 0x1D41A, 0x1D7CE)
            "script" -> mapAlpha(src, 0x1D4D0, 0x1D4EA, 0)
            "fraktur" -> mapAlpha(src, 0x1D56C, 0x1D586, 0)
            "sans" -> mapAlpha(src, 0x1D5D4, 0x1D5EE, 0x1D7EC)
            "sansl" -> mapAlpha(src, 0x1D5A0, 0x1D5BA, 0x1D7E2)
            "mono" -> mapAlpha(src, 0x1D670, 0x1D68A, 0x1D7F6)
            "bolditalic" -> mapAlpha(src, 0x1D468, 0x1D482, 0)
            "wide" -> mapAlpha(src, 0xFF21, 0xFF41, 0xFF10)
            "circle" -> {
                val sb = StringBuilder()
                for (ch in src) {
                    when {
                        ch in 'A'..'Z' -> sb.appendCodePoint(0x24B6 + (ch - 'A'))
                        ch in 'a'..'z' -> sb.appendCodePoint(0x24D0 + (ch - 'a'))
                        ch in '1'..'9' -> sb.appendCodePoint(0x2460 + (ch - '1'))
                        ch == '0' -> sb.appendCodePoint(0x24EA)
                        else -> sb.append(ch)
                    }
                }
                sb.toString()
            }
            "small" -> {
                val sc = "ᴀʙᴄᴅᴇꜰɢʜɪᴊᴋʟᴍɴᴏᴘǫʀsᴛᴜᴠᴡxʏᴢ"
                val sb = StringBuilder()
                for (ch in src) {
                    val l = ch.lowercaseChar()
                    if (l in 'a'..'z') sb.append(sc[l - 'a']) else sb.append(ch)
                }
                sb.toString()
            }
            "tatweel", "tw2", "tw3" -> {
                val n = if (st == "tw2") 2 else if (st == "tw3") 3 else 1
                val stop = "اأإآدذرزوؤةىء"
                val sb = StringBuilder()
                for ((i, ch) in src.withIndex()) {
                    sb.append(ch)
                    if (ch in 'ء'..'ي' && stop.indexOf(ch) < 0 && i + 1 < src.length && src[i + 1] in 'ء'..'ي') {
                        for (k in 0 until n) sb.append('ـ')
                    }
                }
                sb.toString()
            }
            "harakat" -> {
                val sb = StringBuilder()
                for (ch in src) {
                    sb.append(ch)
                    if (ch in 'ء'..'ي' && ch != 'ا' && ch != 'ء') sb.append('َ')
                }
                sb.toString()
            }
            "sup" -> {
                val sup = "ᵃᵇᶜᵈᵉᶠᵍʰⁱʲᵏˡᵐⁿᵒᵖqʳˢᵗᵘᵛʷˣʸᶻ"
                val dg = "⁰¹²³⁴⁵⁶⁷⁸⁹"
                val sb = StringBuilder()
                for (ch in src) {
                    val l = ch.lowercaseChar()
                    when {
                        l in 'a'..'z' -> sb.append(sup[l - 'a'])
                        ch in '0'..'9' -> sb.append(dg[ch - '0'])
                        else -> sb.append(ch)
                    }
                }
                sb.toString()
            }
            "under" -> {
                val sb = StringBuilder()
                for (ch in src) {
                    sb.append(ch)
                    if (!ch.isWhitespace()) sb.append('\u0332')
                }
                sb.toString()
            }
            "strike" -> {
                val sb = StringBuilder()
                for (ch in src) {
                    sb.append(ch)
                    if (!ch.isWhitespace()) sb.append('\u0336')
                }
                sb.toString()
            }
            "neg" -> {
                val sb = StringBuilder()
                for (ch in src) {
                    val l = ch.uppercaseChar()
                    if (l in 'A'..'Z') sb.appendCodePoint(0x1F150 + (l - 'A')) else sb.append(ch)
                }
                sb.toString()
            }
            "sq" -> {
                val sb = StringBuilder()
                for (ch in src) {
                    val l = ch.uppercaseChar()
                    if (l in 'A'..'Z') sb.appendCodePoint(0x1F130 + (l - 'A')) else sb.append(ch)
                }
                sb.toString()
            }
            "a1" -> "꒰ $src ꒱"
            "a2" -> "˚₊‧ $src ‧₊˚"
            "a3" -> "🤍 $src 🤍"
            "a4" -> "🍎 $src 🍎"
            "a5" -> "📱 $src 📱"
            "dots" -> joinChars(src, "•")
            "spaced" -> joinChars(src, " ")
            "w6" -> "✨ $src ✨"
            "w7" -> "💙 $src 💙"
            "w8" -> "🔥 $src 🔥"
            "w1" -> "✦ $src ✦"
            "w2" -> "『$src』"
            "w3" -> "﴿ $src ﴾"
            "w4" -> "☆ $src ☆"
            "w5" -> "♥ $src ♥"
            else -> src
        }
    }


    // ---- النص كصورة (بخط الكيبورد، زي مواقع الخطوط) ----
    private fun renderTextImage(text: String, color: Int): Uri? {
        try {
            val p = android.text.TextPaint(android.graphics.Paint.ANTI_ALIAS_FLAG)
            p.color = color
            p.textSize = 110f
            p.typeface = letterFace() ?: kbFont() ?: Typeface.DEFAULT
            val maxW = 1000
            val layout = android.text.StaticLayout.Builder
                .obtain(text, 0, text.length, p, maxW)
                .setAlignment(android.text.Layout.Alignment.ALIGN_CENTER)
                .build()
            var w = 0f
            for (i in 0 until layout.lineCount) w = maxOf(w, layout.getLineWidth(i))
            val pad = 40
            val bw = (w + pad * 2).toInt().coerceAtLeast(120)
            val bh = layout.height + pad * 2
            val bmp = android.graphics.Bitmap.createBitmap(bw, bh, android.graphics.Bitmap.Config.ARGB_8888)
            val cv = android.graphics.Canvas(bmp)
            cv.translate(((bw - maxW) / 2f), pad.toFloat())
            layout.draw(cv)
            val dir = File(cacheDir, "share")
            dir.mkdirs()
            dir.listFiles()?.forEach { f -> if (f.name.startsWith("franco_text_")) f.delete() }
            val name = "franco_text_" + System.currentTimeMillis() + ".png"
            java.io.FileOutputStream(File(dir, name)).use { o -> bmp.compress(android.graphics.Bitmap.CompressFormat.PNG, 100, o) }
            bmp.recycle()
            return Uri.parse("content://" + ShareProvider.AUTH + "/" + name)
        } catch (e: Throwable) {
            return null
        }
    }

    private fun sendTextAsImage(color: Int) {
        val t = decoSrc.trim()
        if (t.isEmpty()) return
        val uri = renderTextImage(t, color)
        if (uri == null) {
            toast("مقدرتش أعمل الصورة")
            return
        }
        val ic = currentInputConnection
        if (ic != null && Build.VERSION.SDK_INT >= 25 && editorAcceptsImages(currentInputEditorInfo)) {
            try {
                val desc = ClipDescription("franco text", arrayOf("image/png"))
                val ci = InputContentInfo(uri, desc, null)
                if (ic.commitContent(ci, InputConnection.INPUT_CONTENT_GRANT_READ_URI_PERMISSION, null)) {
                    go(baseLayer)
                    return
                }
            } catch (e: Exception) {
                // نجرّب المشاركة
            }
        }
        try {
            val send = Intent(Intent.ACTION_SEND)
            send.type = "image/png"
            send.putExtra(Intent.EXTRA_STREAM, uri)
            send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            val ch = Intent.createChooser(send, "ابعت الصورة")
            ch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(ch)
            go(baseLayer)
        } catch (e: Exception) {
            toast("مقدرتش أبعت الصورة")
        }
    }

    private fun openDeco() {
        val ic = currentInputConnection ?: return
        var t = ic.getSelectedText(0)?.toString() ?: ""
        decoCur = ""
        if (t.isBlank()) {
            val b = ic.getTextBeforeCursor(40, 0)?.toString() ?: ""
            var i = b.length
            while (i > 0 && !b[i - 1].isWhitespace()) i--
            t = b.substring(i)
            decoCur = t
        }
        if (t.isBlank()) {
            toast("حدد كلمة أو اكتبها الأول")
            return
        }
        decoSrc = t
        layer = L_DECO
        resetWord()
        render()
    }


    // ---- زخرفة تلقائية: كل كلمة بتتكتب بتتحول للشكل المثبّت أول ما تخلّصها ----
    private var decoLast = ""

    private fun autoDecoStyleFor(word: String): String? {
        val p = prefs ?: return null
        if (!p.getBoolean("auto_deco_on", false)) return null
        if (!transAllowed || !onlineAllowed || transMode) return null
        var ar = false
        var en = false
        for (ch in word) {
            if (ch in 'ء'..'ي') ar = true
            else if (ch in 'A'..'Z' || ch in 'a'..'z') en = true
        }
        val st = when {
            ar && !en -> p.getString("auto_deco_ar", "")
            en && !ar -> p.getString("auto_deco_en", "")
            else -> ""
        }
        return if (st.isNullOrEmpty()) null else st
    }

    private fun decorateLastWord(ic: InputConnection, boundary: String): Boolean {
        if (prefs?.getBoolean("auto_deco_on", false) != true) return false
        val b = ic.getTextBeforeCursor(60, 0)?.toString() ?: return false
        var i = b.length
        while (i > 0) {
            val c = b[i - 1]
            if (c.isLetterOrDigit() || isMark(c) || c == 'ـ') i-- else break
        }
        val w = b.substring(i)
        if (w.isEmpty()) return false
        val st = autoDecoStyleFor(w) ?: return false
        val out = decorate(w, st)
        ic.beginBatchEdit()
        ic.deleteSurroundingText(w.length, 0)
        ic.commitText(out + boundary, 1)
        ic.endBatchEdit()
        resetWord()
        prevWord = null
        lastFix = null
        return true
    }

    private fun toggleAutoDeco() {
        val p = prefs ?: return
        val on = !p.getBoolean("auto_deco_on", false)
        p.edit().putBoolean("auto_deco_on", on).apply()
        if (on && (p.getString("auto_deco_en", "") ?: "").isEmpty() && (p.getString("auto_deco_ar", "") ?: "").isEmpty()) {
            toast("اختار شكل من زخرفة وبعدين دوس \"📌 خليه تلقائي\"")
        } else {
            toast(if (on) "الزخرفة التلقائية شغالة" else "الزخرفة التلقائية اتقفلت")
        }
        render()
    }

    private fun pinDeco() {
        if (decoLast.isEmpty()) {
            toast("جرّب شكل الأول")
            return
        }
        val key = if (isArabicText(decoSrc)) "auto_deco_ar" else "auto_deco_en"
        prefs?.edit()?.putString(key, decoLast)?.putBoolean("auto_deco_on", true)?.apply()
        toast("من دلوقتي كل كلمة هتتزخرف بالشكل ده")
    }

    private fun clearAutoDeco() {
        prefs?.edit()?.putBoolean("auto_deco_on", false)?.apply()
        toast("الزخرفة التلقائية اتقفلت")
    }

    private fun applyDeco(st: String) {
        val ic = currentInputConnection ?: return
        val out = if (st == "orig") decoSrc else decorate(decoSrc, st)
        if (st != "orig") decoLast = st
        if (decoCur.isNotEmpty()) {
            val before = ic.getTextBeforeCursor(decoCur.length, 0)?.toString() ?: ""
            if (before == decoCur) ic.deleteSurroundingText(decoCur.length, 0)
        }
        ic.commitText(out, 1)
        decoCur = out
    }

    private fun buildDeco(c: LinearLayout) {
        val head = newRow()
        head.addView(key("رجوع", 1.4f, C_FUNC, textSize = 14f) { go(baseLayer) })
        head.addView(key("الأصل", 1f, C_FUNC, textSize = 14f) { applyDeco("orig") })
        val title = TextView(this)
        title.text = "اختار الشكل"
        title.setTextColor(Color.WHITE)
        title.textSize = 16f
        title.gravity = Gravity.CENTER
        title.layoutParams = LinearLayout.LayoutParams(0, kh(), 2f)
        head.addView(title)
        c.addView(head)
        val imgRow = newRow()
        imgRow.addView(key("🖼 صورة بيضا", 1f, C_FUNC, textSize = 13f) { sendTextAsImage(Color.WHITE) })
        imgRow.addView(key("🖼 صورة سودا", 1f, C_FUNC, textSize = 13f) { sendTextAsImage(Color.BLACK) })
        imgRow.addView(key("🖼 بلون الحروف", 1f, C_FUNC, textSize = 13f) { sendTextAsImage(letterColor()) })
        c.addView(imgRow)
        val pinRow = newRow()
        pinRow.addView(key("📌 خليه تلقائي", 1.4f, C_FUNC, textSize = 13f) { pinDeco() })
        pinRow.addView(key("⛔ وقّف التلقائي", 1.2f, C_FUNC, textSize = 13f) { clearAutoDeco() })
        c.addView(pinRow)
        // الأشكال كتير: جوه قائمة بتتسحب
        val sv = ScrollView(this)
        sv.layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, (kh() + dp(6)) * 4)
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.layoutDirection = View.LAYOUT_DIRECTION_LTR
        sv.addView(col)
        c.addView(sv)
        var row = newRow()
        val ar = isArabicText(decoSrc)
        val styles = if (ar) decoAr else decoEn
        for ((i, st) in styles.withIndex()) {
            if (i > 0 && i % 4 == 0) {
                col.addView(row)
                row = newRow()
            }
            val sample = when {
                st.startsWith("en:") || st.startsWith("fr:") -> decorate("حبيبي", st)
                st.startsWith("w") && st != "wide" || (st.length == 2 && st[0] == 'a') -> decorate(if (ar) "نص" else "Abc", st)
                ar -> decorate("محمد", st)
                else -> decorate("Abc", st)
            }
            row.addView(key(sample, 1f, C_FUNC, textSize = 13f) { applyDeco(st) })
        }
        val left = styles.size % 4
        if (left != 0) for (k in 0 until 4 - left) row.addView(spacer(1f))
        col.addView(row)
    }

    private fun summarizeText() {
        val ic = currentInputConnection ?: return
        val sel = ic.getSelectedText(0)?.toString()
        if (!sel.isNullOrBlank()) {
            val out = Summarizer.summarize(sel)
            if (out == null) {
                toast("النص قصير أو مش محتاج تلخيص")
                return
            }
            ic.commitText(out, 1)
            toast("اتلخّص. دوس ↶ تراجع لو عايز الأصلي")
            return
        }
        val whole = (ic.getTextBeforeCursor(8000, 0)?.toString() ?: "") + (ic.getTextAfterCursor(8000, 0)?.toString() ?: "")
        if (whole.isNotBlank()) {
            val out = Summarizer.summarize(whole)
            if (out == null) {
                toast("النص قصير أو مش محتاج تلخيص")
                return
            }
            ic.performContextMenuAction(android.R.id.selectAll)
            ic.commitText(out, 1)
            toast("اتلخّص. دوس ↶ تراجع لو عايز الأصلي")
            return
        }
        val ct = clipText()
        val out = Summarizer.summarize(ct)
        if (out == null) {
            toast("مفيش نص طويل تلخّصه (حدد نص أو انسخ نص)")
            return
        }
        ic.commitText(out, 1)
    }

    private fun saveFrancoApp() {
        if (curPkg.isEmpty() || prefs?.getBoolean("fr_per_app", false) != true) return
        prefs?.edit()?.putBoolean("fa_" + curPkg, francoOn)?.apply()
    }

    private fun convertWord(word: String): String {
        val r = convertWordBase(word)
        if ((prefs?.getInt("fr_style", 0) ?: 0) != 1) return r
        val sb = StringBuilder()
        for (c in r) {
            when (c) {
                '3' -> sb.append("a")
                '7' -> sb.append("h")
                '5' -> sb.append("kh")
                '6' -> sb.append("t")
                '9' -> sb.append("s")
                '8' -> sb.append("gh")
                '2' -> sb.append("'")
                else -> sb.append(c)
            }
        }
        return sb.toString()
    }

    private fun convertWordBase(word: String): String {
        if (hasMarks(word)) return explicit(word)
        val hit = dict[normalize(word)]
        return hit ?: fallback(word)
    }

    // كلمة فيها تشكيل: نكتبها بالحركات اللي انت حطيتها بالظبط
    private fun explicit(word: String): String {
        val sb = StringBuilder()
        var lastCons = ""
        var prev = ' '
        for ((i, c) in word.withIndex()) {
            when (c) {
                '\u064E' -> sb.append("a")
                '\u064F' -> sb.append("o")
                '\u0650' -> sb.append("e")
                '\u064B' -> sb.append("an")
                '\u064C' -> sb.append("on")
                '\u064D' -> sb.append("en")
                '\u0651' -> {
                    if (lastCons.isNotEmpty()) {
                        if (sb.endsWith(lastCons)) {
                            sb.append(lastCons)
                        } else if (sb.length > lastCons.length &&
                            sb.substring(sb.length - 1 - lastCons.length, sb.length - 1) == lastCons
                        ) {
                            sb.insert(sb.length - 1, lastCons)
                        }
                    }
                }
                '\u0652' -> {
                    // سكون: مفيش حركة
                }
                'ا', 'أ', 'إ', 'آ' -> {
                    if (!sb.endsWith("a")) sb.append("a")
                }
                'ى', 'ة' -> sb.append("a")
                'و' -> {
                    if (prev == '\u064F') {
                        // واو مدّ بعد ضمة: بتتكتب مرة واحدة
                    } else if (i == 0 || prev == '\u064E') {
                        sb.append("w")
                    } else {
                        sb.append("o")
                    }
                }
                'ي' -> {
                    if (prev == '\u0650') {
                        // ياء مدّ بعد كسرة: بتتكتب مرة واحدة
                    } else if (i == 0 || prev == '\u064E') {
                        sb.append("y")
                    } else {
                        sb.append("i")
                    }
                }
                else -> {
                    val l = consonants[c] ?: c.toString()
                    sb.append(l)
                    lastCons = l
                }
            }
            prev = c
        }
        return sb.toString()
    }

    // كلمة مش في القاموس: نفصل ال والنهايات، ونحط الحركات بالتخمين
    private fun fallback(word: String): String {
        if (word.length > 3 && word.startsWith("ال")) {
            return "el" + convertWord(word.substring(2))
        }
        for (s in suffixes) {
            val minStem = if (s.first.length == 1) 3 else 2
            if (word.length >= s.first.length + minStem && word.endsWith(s.first)) {
                val stemWord = word.substring(0, word.length - s.first.length)
                val st = dict[normalize(stemWord)] ?: stem(stemWord)
                return st + s.second
            }
        }
        return stem(word)
    }

    private fun stem(word: String): String {
        val units = ArrayList<String>()
        val isCons = ArrayList<Boolean>()
        for ((i, c) in word.withIndex()) {
            when (c) {
                'ا', 'أ', 'إ', 'آ', 'ى', 'ة' -> {
                    units.add("a")
                    isCons.add(false)
                }
                'و' -> {
                    units.add(if (i == 0) "w" else "o")
                    isCons.add(i == 0)
                }
                'ي' -> {
                    units.add(if (i == 0) "y" else "i")
                    isCons.add(i == 0)
                }
                else -> {
                    units.add(consonants[c] ?: c.toString())
                    isCons.add(true)
                }
            }
        }
        var nC = 0
        var nV = 0
        for (k in units.indices) {
            if (isCons[k]) {
                nC++
            } else if (!(k == units.size - 1 && (word[k] == 'ة' || word[k] == 'ى'))) {
                nV++
            }
        }
        val sb = StringBuilder()
        var ci = 0
        for (k in units.indices) {
            sb.append(units[k])
            if (isCons[k]) {
                val nextIsCons = (k + 1 < units.size) && isCons[k + 1]
                if (nextIsCons) {
                    if (nC == 4 && nV == 0) {
                        if (ci == 0 || ci == 2) sb.append("a")
                    } else {
                        sb.append(if (ci == 0) "a" else "e")
                    }
                }
                ci++
            }
        }
        return sb.toString()
    }

    private fun resetWord() {
        wordAr.setLength(0)
        wordFr = ""
        typed.setLength(0)
        lastFix = null
        scheduleSug()
    }

    private fun replaceWord(ic: InputConnection) {
        val newFr = convertWord(wordAr.toString())
        ic.beginBatchEdit()
        if (wordFr.isNotEmpty()) ic.deleteSurroundingText(wordFr.length, 0)
        ic.commitText(newFr, 1)
        ic.endBatchEdit()
        wordFr = newFr
    }

    // ------------------------------------------------------------------
    // الكتابة
    // ------------------------------------------------------------------

    // أي حاجة مش حرف عربي بيتحول لفرانكو (إنجليزي، رقم، مسافة، رمز)
    private fun commitOther(text: String) {
        val ic = currentInputConnection ?: return
        if (text == "=" && tryEquals(ic)) return
        if (text == " " && prefs?.getBoolean("dblspace", false) == true) {
            val b2 = ic.getTextBeforeCursor(2, 0)?.toString() ?: ""
            if (b2.length == 2 && b2[1] == ' ' && b2[0].isLetterOrDigit()) {
                ic.beginBatchEdit()
                ic.deleteSurroundingText(1, 0)
                ic.commitText(". ", 1)
                ic.endBatchEdit()
                resetWord()
                autoCapital(ic)
                return
            }
        }
        if (text.length == 1) {
            val ch = text[0]
            val apostrophe = (ch == '\'' || ch == '’') && typed.isNotEmpty()
            if (ch.isLetterOrDigit() || apostrophe) {
                // بيكمل الكلمة الحالية
                lastFix = null
                if (wordAr.isNotEmpty()) {
                    wordAr.setLength(0)
                    wordFr = ""
                }
                typed.append(ch)
                ic.commitText(text, 1)
                scheduleSug()
                return
            }
            // مسافة أو علامة ترقيم: نصحح الكلمة قبلها
            if (decorateLastWord(ic, text)) {
                if (text == " ") autoCapital(ic)
                return
            }
            val rawBefore = currentRaw().first
            if (layer == L_EN && !transMode && typed.length == 1 && typed[0] == 'i' && prefs?.getBoolean("cap_i", true) != false) {
                val bef = ic.getTextBeforeCursor(1, 0)?.toString() ?: ""
                if (bef == "i") {
                    ic.beginBatchEdit()
                    ic.deleteSurroundingText(1, 0)
                    ic.commitText("I" + text, 1)
                    ic.endBatchEdit()
                    resetWord()
                    prevWord = null
                    if (text == " ") autoCapital(ic)
                    return
                }
            }
            if (tryCorrect(text)) return
            if (rawBefore.isNotEmpty()) learnWord(rawBefore)
            if (text != " ") prevWord = null
        }
        resetWord()
        ic.commitText(text, 1)
        if (text == " ") autoCapital(ic)
    }

    // بعد نقطة ومسافة في الإنجليزي: الحرف الجاي كبير
    private fun autoCapital(ic: InputConnection) {
        if (layer != L_EN || shift != 0) return
        if (prefs?.getBoolean("autocap", true) != true) return
        val b = ic.getTextBeforeCursor(2, 0)?.toString() ?: ""
        val atStart = b.isEmpty() || b.endsWith("\n")
        if (atStart || (b.length == 2 && b[1] == ' ' && (b[0] == '.' || b[0] == '!' || b[0] == '?'))) {
            shift = 1
            render()
        }
    }

    private fun typeLetter(ch: Char) {
        val ic = currentInputConnection ?: return
        lastFix = null
        if (!francoOn) {
            wordAr.setLength(0)
            wordFr = ""
            typed.append(ch)
            ic.commitText(ch.toString(), 1)
            scheduleSug()
            return
        }
        if (wordFr.isNotEmpty()) {
            val before = ic.getTextBeforeCursor(wordFr.length, 0)?.toString() ?: ""
            if (before != wordFr) resetWord()
        }
        wordAr.append(ch)
        replaceWord(ic)
        scheduleSug()
    }

    // رموز الضغط المطوّل: التشكيل في وضع العربي بيتكتب زي ما هو،
    // وفي وضع فرانكو بيتحوّل لحركات (فتحة a، ضمة o، كسرة e، شدة تضاعف الحرف)
    private fun typeSymbol(s: String) {
        val c = s[0]
        if (isMark(c) || c == 'ـ') {
            if (francoOn) {
                if (c != 'ـ' && wordAr.isNotEmpty()) typeLetter(c)
                return
            }
            if (typed.isNotEmpty()) typed.append(c)
            currentInputConnection?.commitText(s, 1)
            return
        }
        commitOther(s)
    }

    private fun doDelete() {
        val ic = currentInputConnection ?: return
        val selected = ic.getSelectedText(0)
        if (selected != null && selected.isNotEmpty()) {
            ic.commitText("", 1)
            resetWord()
            return
        }
        // مسح بعد تصحيح تلقائي: نرجّع الكلمة اللي انت كتبتها
        val fix = lastFix
        if (fix != null) {
            lastFix = null
            val expect = fix.shownNew + fix.boundary
            val before = ic.getTextBeforeCursor(expect.length, 0)?.toString() ?: ""
            if (before == expect) {
                ic.beginBatchEdit()
                ic.deleteSurroundingText(expect.length, 0)
                ic.commitText(fix.shownOld, 1)
                ic.endBatchEdit()
                rememberNoCorrect(fix.raw)
                wordAr.setLength(0)
                typed.setLength(0)
                wordFr = ""
                if (fix.franco) {
                    wordAr.append(fix.raw)
                    wordFr = fix.shownOld
                } else {
                    typed.append(fix.raw)
                }
                return
            }
        }
        if (francoOn && layer == L_AR && wordAr.isNotEmpty() && wordFr.isNotEmpty()) {
            val before = ic.getTextBeforeCursor(wordFr.length, 0)?.toString() ?: ""
            if (before == wordFr) {
                wordAr.setLength(wordAr.length - 1)
                if (wordAr.isEmpty()) {
                    ic.deleteSurroundingText(wordFr.length, 0)
                    wordFr = ""
                } else {
                    replaceWord(ic)
                }
                return
            }
        }
        if (typed.isNotEmpty()) {
            typed.setLength(typed.length - 1)
            ic.deleteSurroundingText(1, 0)
            return
        }
        resetWord()
        ic.deleteSurroundingText(1, 0)
    }

    private fun doEnter() {
        if (transMode) {
            exitTrans()
            return
        }
        currentInputConnection?.let { decorateLastWord(it, "") }
        val pend = currentRaw().first
        if (pend.isNotEmpty()) learnWord(pend)
        prevWord = null
        resetWord()
        val ic = currentInputConnection ?: return
        val options = currentInputEditorInfo?.imeOptions ?: 0
        val action = options and EditorInfo.IME_MASK_ACTION
        val noEnterAction = (options and EditorInfo.IME_FLAG_NO_ENTER_ACTION) != 0
        if (!noEnterAction &&
            action != EditorInfo.IME_ACTION_NONE &&
            action != EditorInfo.IME_ACTION_UNSPECIFIED
        ) {
            ic.performEditorAction(action)
        } else {
            sendDownUpKeyEvents(KeyEvent.KEYCODE_ENTER)
            handler.postDelayed({ currentInputConnection?.let { autoCapital(it) } }, 80)
        }
    }

    // ------------------------------------------------------------------
    // التصحيح التلقائي (عربي وإنجليزي)
    // ------------------------------------------------------------------

    private class Fix(
        val raw: String,
        val shownOld: String,
        val shownNew: String,
        val boundary: String,
        val franco: Boolean
    )

    private val typed = StringBuilder()
    private var lastFix: Fix? = null
    private var autoOn = true
    @Volatile
    private var spellReady = false
    private val arRank = HashMap<String, Int>()
    private val enRank = HashMap<String, Int>()
    private val arWords = ArrayList<String>()
    private val arNorm = ArrayList<String>()
    private val enWords = ArrayList<String>()
    private val pins = ArrayList<String>()
    private var sugViews: List<TextView> = emptyList()
    private val sugRun = Runnable { updateSuggestions() }
    private val shortAr = setOf(
        "صح", "مش", "لا", "ده", "دي", "ايه", "ليه", "فين", "كده", "اوي", "يلا", "بس", "مع",
        "في", "من", "على", "عن", "انا", "انت", "هو", "هي", "لو", "يا", "اه", "طب", "ايوه",
        "ما", "كل", "اي", "ان", "او", "ام", "ثم", "قد", "لم", "لن", "بعد", "قبل", "كان",
        "عشان", "لسه", "برضه", "تمام", "خلاص"
    )

    private class Sug(val shown: String, val word: String, val ar: Boolean)

    // الكلمات اللي بتكتبها كتير (بتتحفظ على الموبايل بس)
    private val uni = HashMap<String, Int>()
    private val bi = HashMap<String, Int>()
    private var prevWord: String? = null
    private var learnDirty = 0
    private val lastSeen = HashMap<String, Long>()
    private var pickSrc = false

    // كلمات بتيجي بعد كلمات شائعة
    private val nextSeed: Map<String, List<String>> = mapOf(
        "انا" to listOf("عايز", "مش", "كنت"),
        "انت" to listOf("فين", "عامل", "مش"),
        "احنا" to listOf("هنروح", "مش", "في"),
        "هو" to listOf("مش", "كان", "في"),
        "هي" to listOf("مش", "كانت", "في"),
        "عايز" to listOf("اعمل", "احط", "اقولك"),
        "عايزه" to listOf("اعمل", "احط", "اروح"),
        "عايزين" to listOf("نعمل", "نحط", "نروح"),
        "مش" to listOf("عارف", "فاهم", "كده"),
        "ازاي" to listOf("اعمل", "اعرف", "ده"),
        "ايه" to listOf("رايك", "اللي", "ده"),
        "ليه" to listOf("كده", "مش", "ده"),
        "فين" to listOf("ده", "انت", "المشكلة"),
        "امتى" to listOf("هتيجي", "هنروح", "ده"),
        "مين" to listOf("ده", "اللي", "قالك"),
        "ان" to listOf("شاء", "احنا", "ده"),
        "شاء" to listOf("الله"),
        "ماشاء" to listOf("الله"),
        "الحمد" to listOf("لله"),
        "سبحان" to listOf("الله"),
        "صباح" to listOf("الخير", "النور"),
        "مساء" to listOf("الخير", "النور"),
        "تصبح" to listOf("على", "على خير"),
        "كل" to listOf("سنة", "يوم", "حاجة"),
        "على" to listOf("فكرة", "كده", "خير"),
        "في" to listOf("الموضوع", "نفس", "حاجة"),
        "من" to listOf("غير", "فضلك", "امتى"),
        "كده" to listOf("صح", "تمام", "يعني"),
        "تمام" to listOf("كده", "يا", "خلاص"),
        "خلاص" to listOf("كده", "يا", "تمام"),
        "بحبك" to listOf("اوي", "يا", "جدا"),
        "شكرا" to listOf("ليك", "جدا", "يا"),
        "لو" to listOf("سمحت", "عايز", "فيه"),
        "يلا" to listOf("بينا", "نروح", "تعالى"),
        "والله" to listOf("العظيم", "ما", "انا"),
        "معلش" to listOf("بقى", "يا", "انا"),
        "بقى" to listOf("يا", "عايز", "ده"),
        "ده" to listOf("مش", "كان", "حلو"),
        "دي" to listOf("مش", "كانت", "حلوة"),
        "بجد" to listOf("والله", "يعني", "ده"),
        "ايوه" to listOf("طبعا", "كده", "صح"),
        "لا" to listOf("مش", "خلاص", "ده"),
        "i" to listOf("am", "have", "will"),
        "you" to listOf("are", "can", "have"),
        "we" to listOf("are", "can", "have"),
        "how" to listOf("are", "do", "to"),
        "what" to listOf("is", "are", "do"),
        "thank" to listOf("you"),
        "thanks" to listOf("for", "a", "so"),
        "see" to listOf("you", "the", "it"),
        "good" to listOf("morning", "night", "luck"),
        "hello" to listOf("there", "world", "how"),
        "hi" to listOf("there", "how", "i"),
        "the" to listOf("best", "same", "only"),
        "can" to listOf("you", "i", "we"),
        "do" to listOf("you", "not", "it"),
        "is" to listOf("it", "this", "there"),
        "this" to listOf("is", "one", "was"),
        "on" to listOf("the", "my", "it"),
        "in" to listOf("the", "a", "my"),
        "to" to listOf("the", "be", "do")
    )
    private val noCorrect = HashSet<String>()
    private val arNear = HashMap<Char, String>()
    private val enNear = HashMap<Char, String>()
    private val arRows = listOf("ضصثقفغعهخحج", "شسيبلاتنمكط", "ذءؤرىةوزظد")
    private val enRows = listOf("qwertyuiop", "asdfghjkl", "zxcvbnm")
    private val arPre = listOf(
        "و", "ف", "ب", "ل", "ك", "ال", "وال", "بال", "فال", "كال", "لل", "ولل", "وب", "ول"
    )
    private val arFixPre = listOf("", "ال", "لل", "بال")
    private val arSuf = listOf(
        "ه", "ها", "هم", "هن", "ك", "كم", "ني", "نا", "ات", "ين", "ون", "وا", "تي", "ان", "يه", "ته"
    )

    private fun buildNear() {
        for ((r, row) in arRows.withIndex()) {
            for ((c, ch) in row.withIndex()) {
                val sb = StringBuilder()
                for (dr in -1..1) {
                    for (dc in -1..1) {
                        if (dr == 0 && dc == 0) continue
                        val rr = r + dr
                        val cc = c + dc
                        if (rr < 0 || rr >= arRows.size) continue
                        if (cc < 0 || cc >= arRows[rr].length) continue
                        val nbCh = arRows[rr][cc]
                        // حروف نادرة (ة ى ء ؤ ئ) مش بنقترحها كتصحيح
                        if ("ةىءؤئ".indexOf(nbCh) >= 0) continue
                        sb.append(nbCh)
                    }
                }
                arNear[ch] = sb.toString()
            }
        }
        for ((r, row) in enRows.withIndex()) {
            for ((c, ch) in row.withIndex()) {
                val sb = StringBuilder()
                val offs = listOf(
                    Pair(r, c - 1), Pair(r, c + 1),
                    Pair(r - 1, c), Pair(r - 1, c + 1),
                    Pair(r + 1, c - 1), Pair(r + 1, c)
                )
                for (p in offs) {
                    if (p.first < 0 || p.first >= enRows.size) continue
                    if (p.second < 0 || p.second >= enRows[p.first].length) continue
                    sb.append(enRows[p.first][p.second])
                }
                enNear[ch] = sb.toString()
            }
        }
    }

    private fun loadSpell() {
        try {
            var i = 0
            assets.open("words_ar.txt").bufferedReader(Charsets.UTF_8).useLines { lines ->
                for (line in lines) {
                    val w = normalize(line.trim())
                    if (w.isNotEmpty() && !arRank.containsKey(w)) {
                        arRank[w] = i
                        arWords.add(line.trim())
                        arNorm.add(w)
                        i++
                    }
                }
            }
            for (k in dict.keys) {
                if (!arRank.containsKey(k)) {
                    arRank[k] = 100000
                    if (k.length >= 2 && !k.contains(' ')) {
                        arWords.add(k)
                        arNorm.add(normalize(k))
                    }
                }
            }
        } catch (e: Exception) {
            // مش مهم
        }
        try {
            var i = 0
            assets.open("words_en.txt").bufferedReader(Charsets.UTF_8).useLines { lines ->
                for (line in lines) {
                    val w = line.trim()
                    if (w.isNotEmpty() && !enRank.containsKey(w)) {
                        enRank[w] = i
                        enWords.add(w)
                        i++
                    }
                }
            }
        } catch (e: Exception) {
            // مش مهم
        }
        spellReady = true
    }

    private fun loadNoCorrect() {
        noCorrect.clear()
        val s = prefs?.getString("nocorrect", "") ?: ""
        if (s.isNotEmpty()) {
            for (p in s.split("\u0001")) {
                if (p.isNotEmpty()) noCorrect.add(p)
            }
        }
    }

    private fun rememberNoCorrect(raw: String) {
        if (raw.isEmpty()) return
        val k = if (raw[0] in 'ء'..'ي') normalize(raw) else raw.lowercase()
        noCorrect.add(k)
        if (noCorrect.size > 600) {
            val it = noCorrect.iterator()
            if (it.hasNext()) {
                it.next()
                it.remove()
            }
        }
        prefs?.edit()?.putString("nocorrect", noCorrect.joinToString("\u0001"))?.apply()
    }

    private fun isKnownAr(n: String): Boolean {
        if (arRank.containsKey(n)) return true
        for (p in arPre) {
            if (n.length > p.length + 1 && n.startsWith(p)) {
                val r = n.substring(p.length)
                if (arRank.containsKey(r)) return true
                for (s in arSuf) {
                    if (r.length > s.length + 1 && r.endsWith(s) &&
                        arRank.containsKey(r.substring(0, r.length - s.length))
                    ) {
                        return true
                    }
                }
            }
        }
        for (s in arSuf) {
            if (n.length > s.length + 1 && n.endsWith(s) &&
                arRank.containsKey(n.substring(0, n.length - s.length))
            ) {
                return true
            }
        }
        return false
    }

    // أحسن تصحيح بحرف جنبه على الكيبورد أو حرفين متبدلين
    private fun bestFix(
        s: String,
        near: Map<Char, String>,
        rank: Map<String, Int>,
        maxRank: Int,
        norm: (String) -> String,
        keyOf: (Char) -> Char
    ): String? {
        var best: String? = null
        var bestKey = Int.MAX_VALUE
        for (i in 0 until s.length - 1) {
            if (s[i] == s[i + 1]) continue
            val cand = s.substring(0, i) + s[i + 1] + s[i] + s.substring(i + 2)
            val r = rank[norm(cand)]
            if (r != null && r < maxRank && r < bestKey) {
                bestKey = r
                best = cand
            }
        }
        for (i in s.indices) {
            val nb = near[keyOf(s[i])] ?: continue
            for (c in nb) {
                val cand = s.substring(0, i) + c + s.substring(i + 1)
                val r = rank[norm(cand)]
                if (r != null && r < maxRank && 1000000 + r < bestKey) {
                    bestKey = 1000000 + r
                    best = cand
                }
            }
        }
        return best
    }

    private fun fixArabic(raw: String): String? {
        if (raw.length < 4) return null
        for (c in raw) {
            if (c !in 'ء'..'ي' || c == 'ـ') return null
        }
        val n = normalize(raw)
        if (noCorrect.contains(n) || isKnownAr(n)) return null
        var best: String? = null
        var bestRank = Int.MAX_VALUE
        for (p in arFixPre) {
            if (n.length < p.length + 4 || !n.startsWith(p)) continue
            val base = raw.substring(p.length)
            val fixed = bestFix(
                base, arNear, arRank, 500,
                { x -> normalize(x) },
                { c -> if (c == 'أ' || c == 'إ' || c == 'آ') 'ا' else c }
            ) ?: continue
            val r = arRank[normalize(fixed)] ?: continue
            if (r < bestRank) {
                bestRank = r
                best = raw.substring(0, p.length) + fixed
            }
        }
        return best
    }

    // كلمات قصيرة (2-3 حروف): بنصححها بس لو حرف جنبه على الكيبورد بيطلّع كلمة شائعة
    private fun fixArabicShort(raw: String): String? {
        if (raw.length < 2 || raw.length > 3) return null
        for (c in raw) {
            if (c !in 'ء'..'ي' || c == 'ـ') return null
        }
        val n = normalize(raw)
        if (noCorrect.contains(n) || shortAr.contains(n) || isKnownAr(n)) return null
        for (i in raw.indices) {
            val k = if (raw[i] == 'أ' || raw[i] == 'إ' || raw[i] == 'آ') 'ا' else raw[i]
            val nb = arNear[k] ?: continue
            for (c in nb) {
                val cand = raw.substring(0, i) + c + raw.substring(i + 1)
                if (shortAr.contains(normalize(cand))) return cand
            }
        }
        return null
    }

    private fun fixEnglish(raw: String): String? {
        if (raw.length < 3) return null
        for (c in raw) {
            if (c !in 'a'..'z' && c !in 'A'..'Z') return null
        }
        for (i in 1 until raw.length) {
            if (raw[i] in 'A'..'Z') return null
        }
        val low = raw.lowercase()
        if (noCorrect.contains(low) || enRank.containsKey(low)) return null
        val fixed = bestFix(
            low, enNear, enRank, Int.MAX_VALUE,
            { x -> x },
            { c -> c }
        ) ?: return null
        return if (raw[0] in 'A'..'Z') fixed.substring(0, 1).uppercase() + fixed.substring(1) else fixed
    }

    // بتتنادى لما تدوس مسافة أو علامة ترقيم بعد كلمة
    private fun tryCorrect(boundary: String): Boolean {
        if (!autoOn || !spellReady) return false
        val ic = currentInputConnection ?: return false
        val franco = francoOn && layer == L_AR && wordAr.isNotEmpty()
        val raw = if (franco) wordAr.toString() else typed.toString()
        if (raw.length < 2) return false
        val fixed = if (raw[0] in 'ء'..'ي') {
            if (raw.length < 4) fixArabicShort(raw) else fixArabic(raw)
        } else {
            fixEnglish(raw)
        }
        if (fixed == null || fixed == raw) {
            val old = if (franco) wordFr else raw
            val bd = boundary
            handler.post { maybeOnline(raw, old, franco, bd) }
            return false
        }
        val shownOld = if (franco) wordFr else raw
        val shownNew = if (franco) convertWord(fixed) else fixed
        val before = ic.getTextBeforeCursor(shownOld.length, 0)?.toString() ?: ""
        if (before != shownOld) return false
        ic.beginBatchEdit()
        ic.deleteSurroundingText(shownOld.length, 0)
        ic.commitText(shownNew + boundary, 1)
        ic.endBatchEdit()
        resetWord()
        lastFix = Fix(raw, shownOld, shownNew, boundary, franco)
        learnWord(fixed)
        if (boundary != " ") prevWord = null
        return true
    }

    private fun showPicker() {
        val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
        imm.showInputMethodPicker()
    }

    private fun go(target: Int) {
        layer = target
        resetWord()
        render()
    }

    // ------------------------------------------------------------------
    // الكيبورد بيتعلم الكلمات اللي بتكتبها كتير (محفوظة على الموبايل بس)
    // ------------------------------------------------------------------

    private fun learnWord(w0: String) {
        val w = w0.trim()
        if (transMode || prefs?.getBoolean("learn_on", true) == false || prefs?.getBoolean("incog", false) == true) {
            prevWord = null
            return
        }
        if (!onlineAllowed || w.length < 2) {
            prevWord = null
            return
        }
        val ar = w[0] in 'ء'..'ي'
        for (c in w) {
            val ok = if (ar) (c in 'ء'..'ي' || isMark(c)) else (c in 'a'..'z' || c in 'A'..'Z' || c == '\'')
            if (!ok) {
                prevWord = null
                return
            }
        }
        val k = if (ar) w else w.lowercase()
        uni[k] = (uni[k] ?: 0) + 1
        val p = prevWord
        if (p != null) {
            val bk = p + "\u0003" + k
            bi[bk] = (bi[bk] ?: 0) + 1
        }
        prevWord = k
        lastSeen[k] = SystemClock.uptimeMillis()
        learnDirty++
        if (learnDirty >= 4) saveLearn()
    }

    private fun encodeMap(m: Map<String, Int>): String {
        val sb = StringBuilder()
        for ((k, v) in m) {
            if (sb.isNotEmpty()) sb.append('\u0001')
            sb.append(k).append('\u0002').append(v)
        }
        return sb.toString()
    }

    private fun decodeMap(str: String, m: HashMap<String, Int>) {
        m.clear()
        if (str.isEmpty()) return
        for (p in str.split("\u0001")) {
            val i = p.lastIndexOf('\u0002')
            if (i <= 0) continue
            val n = p.substring(i + 1).toIntOrNull() ?: continue
            m[p.substring(0, i)] = n
        }
    }

    private fun loadLearn() {
        decodeMap(prefs?.getString("uni", "") ?: "", uni)
        decodeMap(prefs?.getString("bi", "") ?: "", bi)
        learnDirty = 0
    }

    private fun saveLearn() {
        if (learnDirty == 0) return
        if (uni.size > 3000) {
            val it = uni.entries.iterator()
            while (it.hasNext()) if (it.next().value <= 1) it.remove()
        }
        if (bi.size > 6000) {
            val it = bi.entries.iterator()
            while (it.hasNext()) if (it.next().value <= 1) it.remove()
        }
        prefs?.edit()?.putString("uni", encodeMap(uni))?.putString("bi", encodeMap(bi))?.apply()
        learnDirty = 0
    }

    // الكلمات المتوقعة بعد كلمة معينة: اللي كتبتها قبل كده الأول، وبعدين الشائعة
    private fun nextWords(p: String): List<String> {
        val res = ArrayList<String>()
        val prefix = p + "\u0003"
        val list = ArrayList<Map.Entry<String, Int>>()
        for (e in bi.entries) if (e.key.startsWith(prefix)) list.add(e)
        list.sortByDescending { it.value }
        for (e in list) {
            res.add(e.key.substring(prefix.length))
            if (res.size >= 3) break
        }
        val key = if (p[0] in 'ء'..'ي') normalize(p) else p.lowercase()
        val seed = nextSeed[key]
        if (seed != null) {
            for (w in seed) if (res.size < 3 && !res.contains(w)) res.add(w)
        }
        return res
    }

    private fun nextSug(): List<Sug> {
        val out = ArrayList<Sug>()
        val p = prevWord ?: return out
        val ic = currentInputConnection ?: return out
        val b = ic.getTextBeforeCursor(1, 0)?.toString() ?: ""
        if (b != " ") return out
        val franco = francoOn && layer == L_AR
        for (w in nextWords(p)) {
            val ar = w[0] in 'ء'..'ي'
            out.add(Sug(if (ar && franco) convertWord(w) else w, w, ar))
        }
        return out
    }

    // ------------------------------------------------------------------
    // اقتراحات الكلمات (إكمال + تصحيح) في الشريط العلوي
    // ------------------------------------------------------------------

    override fun onUpdateSelection(
        oldSelStart: Int, oldSelEnd: Int, newSelStart: Int, newSelEnd: Int,
        candidatesStart: Int, candidatesEnd: Int
    ) {
        super.onUpdateSelection(oldSelStart, oldSelEnd, newSelStart, newSelEnd, candidatesStart, candidatesEnd)
        if (!transMode && newSelStart == 0 && newSelEnd == 0) {
            val pending = currentRaw().first
            if (pending.isNotEmpty()) {
                learnWord(pending)
                resetWord()
            }
            prevWord = null
        }
        scheduleSug()
    }

    private fun scheduleSug() {
        handler.removeCallbacks(sugRun)
        handler.postDelayed(sugRun, 110)
    }

    private fun currentRaw(): Pair<String, Boolean> {
        val franco = francoOn && layer == L_AR && wordAr.isNotEmpty()
        return Pair(if (franco) wordAr.toString() else typed.toString(), franco)
    }

    private val enToAr: Map<Char, String> = mapOf(
        'q' to "ض", 'w' to "ص", 'e' to "ث", 'r' to "ق", 't' to "ف", 'y' to "غ", 'u' to "ع", 'i' to "ه",
        'o' to "خ", 'p' to "ح", 'a' to "ش", 's' to "س", 'd' to "ي", 'f' to "ب", 'g' to "ل", 'h' to "ا",
        'j' to "ت", 'k' to "ن", 'l' to "م", 'z' to "ئ", 'x' to "ء", 'c' to "ؤ", 'v' to "ر", 'b' to "لا",
        'n' to "ى", 'm' to "ة"
    )
    private val arToEn: Map<Char, Char> by lazy {
        val m = HashMap<Char, Char>()
        for ((k, v) in enToAr) if (v.length == 1) m[v[0]] = k
        m
    }

    // كتبت على لغة غلط (hgsghl بدل السلام، أو ؤشق بدل car)
    private fun wrongLayout(raw: String, ar: Boolean, franco: Boolean): String? {
        if (franco || !spellReady) return null
        if (prefs?.getBoolean("wrong_layout", true) == false) return null
        if (!ar) {
            if (raw.length < 3) return null
            val low = raw.lowercase()
            if (enRank.containsKey(low) || uni.containsKey(low)) return null
            val sb = StringBuilder()
            for (c in low) sb.append(enToAr[c] ?: return null)
            val w = sb.toString()
            return if (isKnownAr(normalize(w))) w else null
        }
        if (raw.length < 4) return null
        if (isKnownAr(normalize(raw)) || uni.containsKey(raw)) return null
        val sb = StringBuilder()
        for (c in raw) sb.append(arToEn[c] ?: return null)
        val w = sb.toString()
        return if (enRank.containsKey(w)) w else null
    }

    private val emojiPairs: List<Pair<String, String>> = listOf(
        "حب" to "❤️", "قلب" to "❤️", "بحبك" to "😍", "حبيبي" to "😍", "حبيبتي" to "😍", "وحشتني" to "🥺", "وحشتيني" to "🥺",
        "ضحك" to "😂", "هههه" to "😂", "تمام" to "👌", "ماشي" to "👌", "اوكي" to "👌", "شكرا" to "🙏", "ربنا" to "🤲", "دعاء" to "🤲",
        "حزين" to "😢", "زعلان" to "😞", "عياط" to "😭", "تعبان" to "😩", "نايم" to "😴", "نوم" to "😴", "غضبان" to "😡", "غضب" to "😡",
        "نار" to "🔥", "ورد" to "🌹", "وردة" to "🌹", "مبروك" to "🎉", "حفلة" to "🎉", "صباح" to "☀️", "شمس" to "☀️", "ليل" to "🌙", "قمر" to "🌙",
        "بيت" to "🏠", "اكل" to "🍽️", "جعان" to "🍽️", "قهوة" to "☕", "شاي" to "🍵", "بيتزا" to "🍕", "ماء" to "💧", "مطر" to "🌧️",
        "سيارة" to "🚗", "عربية" to "🚗", "طيارة" to "✈️", "فلوس" to "💰", "مال" to "💰", "هدية" to "🎁", "كورة" to "⚽", "مباراة" to "⚽",
        "برافو" to "👏", "تصفيق" to "👏", "كويس" to "👍", "ممتاز" to "👍", "جامد" to "💪", "قوة" to "💪", "تفكير" to "🤔", "مفاجأة" to "😮",
        "خجلان" to "😳", "خايف" to "😨", "مريض" to "🤒", "كتاب" to "📚", "مذاكرة" to "📚", "تليفون" to "📱", "موبايل" to "📱", "ساعة" to "⏰",
        "love" to "❤️", "heart" to "❤️", "lol" to "😂", "haha" to "😂", "funny" to "😂", "happy" to "😊", "smile" to "😊", "sad" to "😢",
        "cry" to "😭", "ok" to "👌", "okay" to "👌", "thanks" to "🙏", "thank" to "🙏", "please" to "🙏", "pray" to "🙏", "fire" to "🔥",
        "party" to "🎉", "congrats" to "🎉", "pizza" to "🍕", "coffee" to "☕", "tea" to "🍵", "sleep" to "😴", "tired" to "😩", "angry" to "😡",
        "cool" to "😎", "birthday" to "🎂", "cake" to "🎂", "home" to "🏠", "hi" to "👋", "hello" to "👋", "bye" to "👋", "yes" to "👍",
        "no" to "👎", "kiss" to "😘", "money" to "💰", "gift" to "🎁", "car" to "🚗", "plane" to "✈️", "sun" to "☀️", "moon" to "🌙",
        "rain" to "🌧️", "flower" to "🌹", "rose" to "🌹", "clap" to "👏", "strong" to "💪", "think" to "🤔", "wow" to "😮", "sick" to "🤒",
        "phone" to "📱", "book" to "📚", "football" to "⚽", "food" to "🍽️", "eat" to "🍽️", "hungry" to "🍽️", "miss" to "🥺", "good" to "👍"
    )
    private val emojiMap: HashMap<String, String> by lazy {
        val m = HashMap<String, String>()
        for ((k, v) in emojiPairs) {
            val key = if (k[0] in 'ء'..'ي') normalize(k) else k
            if (!m.containsKey(key)) m[key] = v
        }
        m
    }

    private fun emojiFor(raw: String, ar: Boolean): String? {
        if (prefs?.getBoolean("emoji_sug", true) == false) return null
        return emojiMap[if (ar) normalize(raw) else raw.lowercase()]
    }

    private fun computeSug(): List<Sug> {
        val out = ArrayList<Sug>()
        if (!spellReady || (layer != L_AR && layer != L_EN)) return out
        val pr = currentRaw()
        val raw = pr.first
        val franco = pr.second
        if (raw.isEmpty()) return nextSug()
        val ar = raw[0] in 'ء'..'ي'
        fun show(w: String): String = if (franco && ar) convertWord(w) else w
        fun add(w: String) {
            if (w == raw || out.size >= 3) return
            for (x in out) if (x.word == w) return
            out.add(Sug(show(w), w, ar))
        }
        val fix = try {
            if (ar) (if (raw.length < 4) fixArabicShort(raw) else fixArabic(raw)) else fixEnglish(raw)
        } catch (e: Exception) {
            null
        }
        val wl = wrongLayout(raw, ar, franco)
        if (wl != null) out.add(Sug(wl, wl, wl[0] in 'ء'..'ي'))
        if (fix != null) add(fix)
        // كلماتك اللي كتبتها كتير الأول
        val low = if (ar) raw else raw.lowercase()
        val mine = ArrayList<Map.Entry<String, Int>>()
        for (e in uni.entries) {
            if (e.key.length > low.length && e.key.startsWith(low)) mine.add(e)
        }
        mine.sortWith(
            compareByDescending<Map.Entry<String, Int>> { it.value }
                .thenByDescending { lastSeen[it.key] ?: 0L }
        )
        val capMine = !ar && raw[0] in 'A'..'Z'
        for (e in mine) {
            if (out.size >= 3) break
            add(if (capMine) e.key.substring(0, 1).uppercase() + e.key.substring(1) else e.key)
        }
        if (ar) {
            val p = normalize(raw)
            for (i in arNorm.indices) {
                if (out.size >= 3) break
                val w = arNorm[i]
                if (w.length > p.length && w.startsWith(p)) add(arWords[i])
            }
        } else {
            val p = raw.lowercase()
            val cap = raw[0] in 'A'..'Z'
            for (w in enWords) {
                if (out.size >= 3) break
                if (w.length > p.length && w.startsWith(p)) {
                    add(if (cap) w.substring(0, 1).uppercase() + w.substring(1) else w)
                }
            }
        }
        val em = emojiFor(raw, ar)
        if (em != null) {
            val es = Sug(em, "\u0000" + em, false)
            if (out.size >= 3) out[2] = es else out.add(es)
        }
        return out
    }

    private fun updateSuggestions() {
        val views = sugViews
        if (views.size < 3) return
        val kf = kbFont()
        if (kf != null) for (v in views) v.typeface = kf
        if (layer != L_AR && layer != L_EN) {
            for (v in views) {
                v.text = ""
                v.tag = null
                v.visibility = View.INVISIBLE
            }
            midMode = 0
            return
        }
        val typing = currentRaw().first.isNotEmpty()
        if (typing) clipChip = null
        val sugOn = prefs?.getBoolean("sug_on", true) ?: true
        val list = if (sugOn) {
            try {
                computeSug()
            } catch (e: Exception) {
                ArrayList<Sug>()
            }
        } else {
            ArrayList<Sug>()
        }
        val chip = clipChip
        val calcOn = calcLookup()
        if (calcOn) {
            midMode = 3
            views[0].visibility = View.GONE
            views[2].visibility = View.GONE
            views[1].visibility = View.VISIBLE
            views[1].text = "= " + calcRes
            views[1].tag = null
        } else if (!typing && shotUri != null) {
            // لقطة شاشة جديدة
            midMode = 4
            views[0].visibility = View.GONE
            views[2].visibility = View.GONE
            views[1].visibility = View.VISIBLE
            views[1].text = "🖼  لقطة شاشة"
            views[1].tag = null
        } else if (!typing && chip != null) {
            // اللي نسخته: بيظهر في النص لحد ما تكتب
            midMode = 1
            val longClip = chip.length >= 400 && Summarizer.summarize(chipOut(chip)) != null
            if (longClip) {
                views[0].visibility = View.VISIBLE
                views[0].text = "📝 لخّص"
                views[0].tag = null
            } else {
                views[0].visibility = View.GONE
            }
            views[2].visibility = View.GONE
            views[1].visibility = View.VISIBLE
            val one = chipOut(chip).replace('\n', ' ')
            views[1].text = "📋  " + (if (one.length > 40) one.substring(0, 40) + "…" else one)
            views[1].tag = null
        } else if (list.isNotEmpty()) {
            midMode = 0
            for ((i, v) in views.withIndex()) {
                v.visibility = View.VISIBLE
                if (i < list.size) {
                    v.text = list[i].shown
                    v.tag = list[i]
                } else {
                    v.text = ""
                    v.tag = null
                }
            }
        } else {
            // مفيش اقتراحات: علامة الحافظة في النص
            midMode = 2
            views[0].visibility = View.GONE
            views[2].visibility = View.GONE
            views[1].visibility = View.VISIBLE
            views[1].text = "📋"
            views[1].tag = null
        }
    }

    private fun applySug(sg: Sug) {
        val ic = currentInputConnection ?: return
        if (sg.word.startsWith("\u0000")) {
            // إيموجي مقترح: بيتحط بعد الكلمة
            ic.commitText(" " + sg.shown + " ", 1)
            resetWord()
            return
        }
        val pr = currentRaw()
        val old = if (pr.second) wordFr else pr.first
        ic.beginBatchEdit()
        if (old.isNotEmpty()) {
            val before = ic.getTextBeforeCursor(old.length, 0)?.toString() ?: ""
            if (before != old) {
                ic.endBatchEdit()
                return
            }
            ic.deleteSurroundingText(old.length, 0)
        }
        ic.commitText(sg.shown + " ", 1)
        ic.endBatchEdit()
        resetWord()
        learnWord(sg.word)
    }

    // ------------------------------------------------------------------
    // تصحيح أونلاين للعربي والإنجليزي (منفصل تماماً عن الفرانكو)
    // ------------------------------------------------------------------

    private fun maybeOnline(raw: String, shownOld: String, franco: Boolean, boundary: String) {
        if (!onlineAllowed || !autoOn) return
        if (prefs?.getBoolean("incog", false) == true) return
        if (prefs?.getBoolean("online", true) != true) return
        val ar = raw[0] in 'ء'..'ي'
        if (ar) {
            if (raw.length < 4) return
            for (c in raw) {
                if (c !in 'ء'..'ي' || c == 'ـ') return
            }
            val n = normalize(raw)
            if (noCorrect.contains(n) || isKnownAr(n)) return
        } else {
            if (raw.length < 3) return
            for (c in raw) {
                if (c !in 'a'..'z' && c !in 'A'..'Z') return
            }
            if (raw[0] in 'A'..'Z') return
            val low = raw.lowercase()
            if (noCorrect.contains(low) || enRank.containsKey(low)) return
        }
        val key = (if (ar) "ar:" else "en:") + raw
        if (onlineCache.containsKey(key)) {
            val c = onlineCache[key]
            if (c != null) applyOnline(raw, c, shownOld, franco, boundary)
            return
        }
        val now = SystemClock.uptimeMillis()
        if (onlineBusy || now - onlineLast < 3200) return
        onlineBusy = true
        onlineLast = now
        Thread {
            var ok = false
            var fix: String? = null
            try {
                val c = URL("https://api.languagetool.org/v2/check").openConnection() as HttpURLConnection
                c.requestMethod = "POST"
                c.connectTimeout = 3000
                c.readTimeout = 3500
                c.doOutput = true
                c.setRequestProperty("Content-Type", "application/x-www-form-urlencoded")
                val body = "language=" + (if (ar) "ar" else "en-US") +
                    "&text=" + URLEncoder.encode(raw, "UTF-8")
                c.outputStream.use { it.write(body.toByteArray()) }
                if (c.responseCode == 200) {
                    ok = true
                    val txt = c.inputStream.bufferedReader().readText()
                    val m = JSONObject(txt).getJSONArray("matches")
                    if (m.length() == 1) {
                        val o = m.getJSONObject(0)
                        val type = o.getJSONObject("rule").optString("issueType")
                        val reps = o.getJSONArray("replacements")
                        if (type == "misspelling" && o.getInt("offset") == 0 &&
                            o.getInt("length") == raw.length && reps.length() > 0
                        ) {
                            val r = reps.getJSONObject(0).getString("value")
                            if (r.isNotBlank() && !r.contains(' ') && r != raw &&
                                Math.abs(r.length - raw.length) <= 2
                            ) {
                                fix = r
                            }
                        }
                    }
                }
                c.disconnect()
            } catch (e: Exception) {
                ok = false
            }
            handler.post {
                onlineBusy = false
                if (ok) {
                    if (onlineCache.size > 500) onlineCache.clear()
                    onlineCache[key] = fix
                    if (fix != null) applyOnline(raw, fix!!, shownOld, franco, boundary)
                }
            }
        }.start()
    }

    private fun applyOnline(raw: String, fixed: String, shownOld: String, franco: Boolean, boundary: String) {
        val ic = currentInputConnection ?: return
        val shownNew = if (franco) convertWord(fixed) else fixed
        val tail = shownOld + boundary
        val before = ic.getTextBeforeCursor(tail.length + 40, 0)?.toString() ?: return
        val idx = before.lastIndexOf(tail)
        if (idx < 0) return
        // لو لسه بتكتب كلمات بعدها، بنرجعها زي ما هي
        val suffix = before.substring(idx + tail.length)
        ic.beginBatchEdit()
        ic.deleteSurroundingText(tail.length + suffix.length, 0)
        ic.commitText(shownNew + boundary + suffix, 1)
        ic.endBatchEdit()
        if (suffix.isEmpty()) {
            resetWord()
            lastFix = Fix(raw, shownOld, shownNew, boundary, franco)
        }
    }

    // ------------------------------------------------------------------
    // الترجمة (جوجل ترانسليت): اكتب في الخانة الصغيرة والترجمة بتتكتب في التطبيق
    // ------------------------------------------------------------------

    private fun enterTrans() {
        if (!transAllowed) {
            toast("الترجمة مش متاحة في خانات الباسورد والإيميل")
            return
        }
        if (prefs?.getBoolean("trans_on", true) == false) {
            toast("الترجمة مقفولة من الإعدادات")
            return
        }
        if (transMode) return
        savedFranco = francoOn
        francoOn = false
        transMode = true
        transOut = ""
        transField?.setText("")
        transBox?.visibility = View.VISIBLE
        layer = if (transSrc == "ar") L_AR else L_EN
        resetWord()
        refreshTransChips()
        render()
    }

    private fun exitTrans() {
        if (!transMode) return
        handler.removeCallbacks(transRun)
        transSeq++
        transMode = false
        transBox?.visibility = View.GONE
        transField?.setText("")
        transOut = ""
        francoOn = savedFranco
        layer = L_AR
        resetWord()
        render()
    }

    private fun refreshTransChips() {
        transSrcChip?.text = transNames[transSrc] ?: transSrc
        transTgtChip?.text = transNames[transTgt] ?: transTgt
    }

    private fun transLayer(): Int = if (transSrc == "ar") L_AR else L_EN

    private fun swapTransLang() {
        val t = transSrc
        transSrc = transTgt
        transTgt = t
        layer = transLayer()
        resetWord()
        refreshTransChips()
        render()
        scheduleTranslate()
    }

    // دوسة واحدة: تظهر قائمة اللغات
    private fun openLangPicker(forSrc: Boolean) {
        pickSrc = forSrc
        layer = L_LANG
        resetWord()
        render()
    }

    private fun chooseLang(code: String) {
        if (pickSrc) {
            if (code == transTgt) transTgt = transSrc
            transSrc = code
        } else {
            if (code == transSrc) transSrc = transTgt
            transTgt = code
        }
        layer = transLayer()
        resetWord()
        refreshTransChips()
        render()
        scheduleTranslate()
    }

    private fun buildLangPicker(c: LinearLayout) {
        val head = newRow()
        head.addView(key("رجوع", 1.4f, C_FUNC, textSize = 14f) {
            layer = transLayer()
            render()
        })
        val title = TextView(this)
        title.text = if (pickSrc) "ترجم من" else "ترجم إلى"
        title.setTextColor(Color.WHITE)
        title.textSize = 16f
        title.gravity = Gravity.CENTER
        title.layoutParams = LinearLayout.LayoutParams(0, kh(), 3f)
        head.addView(title)
        c.addView(head)
        val cur = if (pickSrc) transSrc else transTgt
        var row = newRow()
        for ((i, code) in transLangs.withIndex()) {
            if (i > 0 && i % 4 == 0) {
                c.addView(row)
                row = newRow()
            }
            row.addView(
                key(transNames[code] ?: code, 1f, if (code == cur) C_GREEN else C_FUNC, textSize = 13f) {
                    chooseLang(code)
                }
            )
        }
        val left = transLangs.size % 4
        if (left != 0) {
            for (k in 0 until 4 - left) row.addView(spacer(1f))
        }
        c.addView(row)
    }

    private fun scheduleTranslate() {
        if (!transMode) return
        handler.removeCallbacks(transRun)
        handler.postDelayed(transRun, 700)
    }

    private fun doTranslate() {
        if (!transMode) return
        val text = (transField?.text?.toString() ?: "").trim()
        if (text.isEmpty()) {
            transSeq++
            applyTrans("")
            return
        }
        if (text.length > 1500) {
            toast("النص طويل للترجمة")
            return
        }
        val my = ++transSeq
        val src = transSrc
        val tgt = transTgt
        Thread {
            val res = translateText(text, src, tgt)
            handler.post {
                if (my == transSeq && transMode) {
                    if (res != null) applyTrans(res) else toast("الترجمة مش شغالة (النت؟)")
                }
            }
        }.start()
    }

    // بيكتب الترجمة في التطبيق، وبيبدّل الترجمة القديمة بالجديدة
    private fun applyTrans(res: String) {
        val r = super.getCurrentInputConnection() ?: return
        r.beginBatchEdit()
        if (transOut.isNotEmpty()) {
            val b = r.getTextBeforeCursor(transOut.length, 0)?.toString() ?: ""
            if (b == transOut) r.deleteSurroundingText(transOut.length, 0)
        }
        if (res.isNotEmpty()) r.commitText(res, 1)
        r.endBatchEdit()
        transOut = res
    }

    private fun httpGet(u: String): String? {
        return try {
            val c = URL(u).openConnection() as HttpURLConnection
            c.connectTimeout = 4000
            c.readTimeout = 5000
            c.setRequestProperty("User-Agent", "Mozilla/5.0")
            val body = if (c.responseCode == 200) c.inputStream.bufferedReader().readText() else null
            c.disconnect()
            body
        } catch (e: Exception) {
            null
        }
    }

    // جوجل ترانسليت (الرابط العام من غير مفتاح)، ولو فشل MyMemory
    private fun translateText(text: String, src: String, tgt: String): String? {
        val q = URLEncoder.encode(text, "UTF-8")
        try {
            val body = httpGet(
                "https://translate.googleapis.com/translate_a/single?client=gtx&sl=$src&tl=$tgt&dt=t&q=$q"
            )
            if (body != null) {
                val arr = JSONArray(body).getJSONArray(0)
                val sb = StringBuilder()
                for (i in 0 until arr.length()) {
                    val part = arr.optJSONArray(i)?.optString(0, "") ?: ""
                    if (part != "null") sb.append(part)
                }
                val out = sb.toString()
                if (out.isNotBlank()) return out
            }
        } catch (e: Exception) {
            // نجرّب البديل
        }
        try {
            val body = httpGet("https://api.mymemory.translated.net/get?q=$q&langpair=$src|$tgt")
            if (body != null) {
                val out = JSONObject(body).getJSONObject("responseData").optString("translatedText", "")
                if (out.isNotBlank()) return out
            }
        } catch (e: Exception) {
            // مش مهم
        }
        return null
    }

    // ------------------------------------------------------------------
    // الكتابة بالصوت: بتتكلم عربي، وبيتكتب عربي أو فرانكو
    // حسب زرار "فرانكو" اللي في الشريط (أخضر = فرانكو)
    // ------------------------------------------------------------------

    private fun toast(msg: String) {
        try {
            Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            // مش مهم
        }
    }

    private fun refreshMic() {
        val b = micBtn ?: return
        b.text = if (listening) "⏹" else "🎤"
        b.background = roundBg(if (listening) "#C62828" else C_FUNC)
    }

    private fun hasMicPermission(): Boolean =
        Build.VERSION.SDK_INT < 23 ||
            checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    // ---- خط الكيبورد (ملف ttf/otf المستورد من الإعدادات) ----
    private var fontName: String? = null
    private var fontStamp = 0L
    private var fontCache: Typeface? = null

    private fun kbFont(): Typeface? {
        val tk = "font_file_t" + effTheme()
        val name = if (prefs?.contains(tk) == true) prefs?.getString(tk, null) else prefs?.getString("font_file", null)
        if (name.isNullOrEmpty()) {
            fontName = null
            fontCache = null
            return null
        }
        val f = File(File(filesDir, "fonts"), name)
        if (!f.exists()) return null
        if (name == fontName && f.lastModified() == fontStamp && fontCache != null) return fontCache
        return try {
            val tf = Typeface.createFromFile(f)
            fontName = name
            fontStamp = f.lastModified()
            fontCache = tf
            tf
        } catch (e: Exception) {
            null
        }
    }

    // خط حروف الزراير بالسُمك المختار (رفيع/متوسط/عريض) فوق الخط الأساسي
    private var weightKey = ""
    private var weightCache: Typeface? = null

    private fun letterFace(): Typeface? {
        val w = (prefs?.getInt("font_weight", 0) ?: 0).coerceIn(0, 3)
        val base = kbFont()
        if (w == 0) return base
        val key = w.toString() + "|" + System.identityHashCode(base)
        if (key == weightKey && weightCache != null) return weightCache
        val b = base ?: Typeface.DEFAULT
        val tf = try {
            if (Build.VERSION.SDK_INT >= 28) {
                Typeface.create(b, when (w) { 1 -> 200; 2 -> 500; else -> 700 }, false)
            } else if (w == 3) {
                Typeface.create(b, Typeface.BOLD)
            } else {
                base
            }
        } catch (e: Throwable) {
            base
        }
        weightKey = key
        weightCache = tf
        return tf
    }

    private fun hasShotPermission(): Boolean {
        if (Build.VERSION.SDK_INT < 23) return true
        val perm = if (Build.VERSION.SDK_INT >= 33) {
            Manifest.permission.READ_MEDIA_IMAGES
        } else {
            Manifest.permission.READ_EXTERNAL_STORAGE
        }
        return checkSelfPermission(perm) == PackageManager.PERMISSION_GRANTED
    }

    // بنطلب إذن الصور مرة واحدة بس (عشان زرار لقطة الشاشة)
    private fun askShotPermissionOnce() {
        try {
            if (hasShotPermission()) return
            if (prefs?.getBoolean("shot_asked", false) == true) return
            prefs?.edit()?.putBoolean("shot_asked", true)?.apply()
            val i = Intent(this, MediaPermissionActivity::class.java)
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(i)
        } catch (e: Exception) {
            // مش مهم
        }
    }

    // بيدور على آخر صورة اتضافت، ولو لقطة شاشة جديدة (أقل من دقيقة) بيظهرها
    private fun checkShot() {
        try {
            if (prefs?.getBoolean("shot_on", true) == false) return
            if (!hasShotPermission()) return
            val proj = arrayOf(
                MediaStore.Images.Media._ID,
                MediaStore.Images.Media.DISPLAY_NAME,
                MediaStore.Images.Media.DATE_ADDED,
                MediaStore.Images.Media.MIME_TYPE
            )
            val c = contentResolver.query(
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                proj, null, null, MediaStore.Images.Media.DATE_ADDED + " DESC"
            ) ?: return
            c.use {
                if (!it.moveToFirst()) return
                val id = it.getLong(0)
                val name = (it.getString(1) ?: "").lowercase()
                val added = it.getLong(2)
                val mime = it.getString(3) ?: "image/png"
                val ageSec = System.currentTimeMillis() / 1000 - added
                val isShot = name.contains("screenshot") || name.contains("screen_shot") ||
                    name.contains("screen-shot") || name.contains("لقطة")
                if (isShot && ageSec in -5L..60L && id != shotHandledId) {
                    shotId = id
                    shotMime = mime
                    shotUri = ContentUris.withAppendedId(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, id)
                    handler.removeCallbacks(shotExpire)
                    handler.postDelayed(shotExpire, 60000)
                    scheduleSug()
                }
            }
        } catch (e: Exception) {
            // مش مهم
        }
    }

    private fun editorAcceptsImages(info: EditorInfo?): Boolean {
        if (info == null) return false
        try {
            val f = EditorInfo::class.java.getField("contentMimeTypes")
            val arr = f.get(info) as? Array<*>
            if (arr != null && arr.any { m -> (m as? String)?.let { x -> x.startsWith("image/") || x == "*/*" } == true }) return true
        } catch (e: Exception) {
            // مش مهم
        }
        try {
            val ex = info.extras
            val arr = ex?.getStringArray("androidx.core.view.inputmethod.EditorInfoCompat.CONTENT_MIME_TYPES")
            if (arr != null && arr.any { x -> x.startsWith("image/") || x == "*/*" }) return true
        } catch (e: Exception) {
            // مش مهم
        }
        return false
    }

    private fun sendShot() {
        val uri = shotUri ?: return
        val ic = currentInputConnection
        var ok = false
        if (ic != null && Build.VERSION.SDK_INT >= 25 && editorAcceptsImages(currentInputEditorInfo)) {
            try {
                val desc = ClipDescription("screenshot", arrayOf(shotMime))
                val ci = InputContentInfo(uri, desc, null)
                ok = ic.commitContent(ci, InputConnection.INPUT_CONTENT_GRANT_READ_URI_PERMISSION, null)
            } catch (e: Exception) {
                ok = false
            }
        }
        if (ok) {
            shotHandledId = shotId
            shotUri = null
            handler.removeCallbacks(shotExpire)
            scheduleSug()
        } else {
            toast("الخانة دي مش بتقبل صور")
        }
    }

    private fun askMicPermission() {
        try {
            val i = Intent(this, MicPermissionActivity::class.java)
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(i)
        } catch (e: Exception) {
            // مش مهم
        }
    }

    private fun toggleMic() {
        if (listening) {
            stopVoice()
            return
        }
        if (!hasMicPermission()) {
            askMicPermission()
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            toast("مفيش خدمة تعرّف على الصوت في الموبايل")
            return
        }
        startVoice()
    }

    private fun startVoice() {
        resetWord()
        try {
            recognizer?.destroy()
            val sr = SpeechRecognizer.createSpeechRecognizer(this)
            recognizer = sr
            sr.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onPartialResults(partialResults: Bundle?) {}
                override fun onEvent(eventType: Int, params: Bundle?) {}

                override fun onError(error: Int) {
                    listening = false
                    refreshMic()
                    when (error) {
                        SpeechRecognizer.ERROR_NO_MATCH,
                        SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> toast("ماسمعتش حاجة، جرب تاني")
                        SpeechRecognizer.ERROR_NETWORK,
                        SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> toast("محتاج إنترنت عشان الصوت")
                        SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> askMicPermission()
                        SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> {
                        }
                        else -> toast("الصوت مش شغال دلوقتي (كود $error)")
                    }
                }

                override fun onResults(results: Bundle?) {
                    listening = false
                    refreshMic()
                    val list = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    val text = list?.firstOrNull()?.trim() ?: ""
                    if (text.isNotEmpty()) insertSpoken(text)
                }
            })
            val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            i.putExtra(
                RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                RecognizerIntent.LANGUAGE_MODEL_FREE_FORM
            )
            val vl = prefs?.getString("voice_lang", "ar-EG") ?: "ar-EG"
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, vl)
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, vl)
            i.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
            i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
            i.putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
            listening = true
            refreshMic()
            sr.startListening(i)
        } catch (e: Exception) {
            listening = false
            refreshMic()
            toast("الصوت مش شغال دلوقتي")
        }
    }

    private fun stopVoice() {
        try {
            recognizer?.cancel()
        } catch (e: Exception) {
            // مش مهم
        }
        listening = false
        refreshMic()
    }

    // كل كلمة عربي بتتحول فرانكو، وأي حاجة تانية بتفضل زي ما هي
    private fun francoize(text: String): String {
        val sb = StringBuilder()
        val w = StringBuilder()
        for (c in text) {
            if (c in 'ء'..'ي' || isMark(c)) {
                w.append(c)
            } else {
                if (w.isNotEmpty()) {
                    sb.append(convertWord(w.toString()))
                    w.setLength(0)
                }
                sb.append(c)
            }
        }
        if (w.isNotEmpty()) sb.append(convertWord(w.toString()))
        return sb.toString()
    }

    private fun insertSpoken(text: String) {
        val ic = currentInputConnection ?: return
        val out = if (francoOn) francoize(text) else text
        resetWord()
        val before = ic.getTextBeforeCursor(1, 0)?.toString() ?: ""
        val prefix = if (before.isNotEmpty() && !before[0].isWhitespace()) " " else ""
        ic.commitText(prefix + out, 1)
    }

    // ------------------------------------------------------------------
    // الحافظة
    // ------------------------------------------------------------------

    private fun loadClips() {
        clips.clear()
        val s = prefs?.getString("clips", "") ?: ""
        if (s.isNotEmpty()) {
            for (p in s.split("\u0001")) {
                if (p.isNotEmpty()) clips.add(p)
            }
        }
    }

    private fun saveClips() {
        prefs?.edit()?.putString("clips", clips.joinToString("\u0001"))?.apply()
    }

    private fun addClip(t: String) {
        val s = t.trim()
        if (s.isEmpty() || s.length > 3000) return
        if (pins.contains(s)) return
        clips.remove(s)
        clips.add(0, s)
        while (clips.size > clipMax()) clips.removeAt(clips.size - 1)
        saveClips()
        refreshChip()
    }

    // fromCopy = true لما المستخدم ينسخ فعلاً (حدث جاي من النظام)
    private fun grabClip(fromCopy: Boolean = false) {
        if (prefs?.getBoolean("clip_on", true) == false || prefs?.getBoolean("incog", false) == true) return
        try {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            val clip = cm.primaryClip ?: return
            if (clip.itemCount > 0) {
                val t = clip.getItemAt(0).coerceToText(this)?.toString() ?: return
                val tt = t.trim()
                if (fromCopy) {
                    ignoredClip = null
                    prefs?.edit()?.remove("clip_ignored")?.apply()
                    addClip(t)
                    if (tt.isNotEmpty()) clipChip = tt
                    scheduleSug()
                } else if (tt != ignoredClip) {
                    if (tt.isNotEmpty() && (clips.isEmpty() || clips[0] != tt) && !pins.contains(tt)) {
                        clipChip = tt
                    }
                    addClip(t)
                }
            }
        } catch (e: Exception) {
            // مش مهم
        }
    }

    private fun clipMax(): Int = (prefs?.getInt("clip_max", 30) ?: 30).coerceIn(5, 100)

    private fun systemClipText(): String? {
        return try {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            val clip = cm.primaryClip
            if (clip != null && clip.itemCount > 0) {
                clip.getItemAt(0).coerceToText(this)?.toString()
            } else {
                null
            }
        } catch (e: Exception) {
            null
        }
    }

    // نمنع النص ده يرجع من حافظة النظام بعد ما اتمسح من الكيبورد
    private fun blockSystemClip(t: String) {
        ignoredClip = t
        prefs?.edit()?.putString("clip_ignored", t)?.apply()
    }

    private fun forgetClip(t: String) {
        clips.remove(t)
        saveClips()
        val cur = systemClipText()
        if (cur != null && cur.trim() == t.trim()) blockSystemClip(cur.trim())
        refreshChip()
    }

    private fun forgetAllClips() {
        clips.clear()
        saveClips()
        val cur = systemClipText()
        if (cur != null && cur.isNotBlank()) blockSystemClip(cur.trim())
        refreshChip()
    }

    // ------------------------------------------------------------------
    // أدوات الرسم
    // ------------------------------------------------------------------

    private fun dp(v: Int): Int =
        TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP, v.toFloat(), resources.displayMetrics
        ).toInt()

    // ارتفاع الزرار (بيتغير من تغيير الحجم)
    private fun kh(): Int = (dp(46) * hScale).toInt()

    private fun roundBg(color: String): GradientDrawable {
        val bg = GradientDrawable()
        bg.cornerRadius = dp(8).toFloat()
        bg.setColor(Color.parseColor(color))
        return bg
    }

    private fun newRow(): LinearLayout {
        val r = LinearLayout(this)
        r.orientation = LinearLayout.HORIZONTAL
        r.layoutDirection = View.LAYOUT_DIRECTION_LTR
        r.layoutParams = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )
        return r
    }

    private fun spacer(weight: Float, forward: Boolean = false): View {
        val v = View(this)
        v.layoutParams = LinearLayout.LayoutParams(0, kh() + dp(6), weight)
        if (forward) {
            // اللمس على الفراغ يتحول للزرار اللي جنبه (زي الكيبورد العادي)
            v.setOnTouchListener { sp, e ->
                val row = sp.parent as? LinearLayout
                if (row != null) {
                    val i = row.indexOfChild(sp)
                    val target = if (i == 0) row.getChildAt(1) else row.getChildAt(row.childCount - 2)
                    if (target != null) {
                        val ev = MotionEvent.obtain(e)
                        ev.offsetLocation((sp.left - target.left).toFloat(), 0f)
                        target.dispatchTouchEvent(ev)
                        ev.recycle()
                    }
                }
                true
            }
        }
        return v
    }

    private fun toolButton(label: String, onClick: () -> Unit): TextView {
        val t = TextView(this)
        t.text = label
        t.setTextColor(Color.WHITE)
        t.textSize = 15f
        t.gravity = Gravity.CENTER
        t.setPadding(dp(10), 0, dp(10), 0)
        t.background = roundBg(C_FUNC)
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(32))
        lp.setMargins(dp(4), dp(3), dp(4), dp(3))
        t.layoutParams = lp
        t.setOnClickListener { onClick() }
        return t
    }

    // لون الزرار مع الشفافية (لما يكون في خلفية صورة)
    // ألوان الزراير الجاهزة (الثيم): الأول زرار الحروف، والتاني زراير الوظايف
    private val themes = listOf(
        Pair(C_KEY, C_FUNC),
        Pair("#2F4A78", "#3F63A0"),
        Pair("#2F5E3F", "#3F7F55"),
        Pair("#533A78", "#6D4D9C"),
        Pair("#6E2F36", "#8E414A"),
        Pair("#7A3A5E", "#9C4F7C"),
        Pair("#0E0E10", "#26262B"),
        Pair("#F4F4F6", "#C9C9D0")
    )

    private var autoColors: Pair<String, String>? = null
    private var autoText: Int = Color.WHITE

    // لون حروف الكيبورد (من الإعدادات): نفس ألوان الزراير
    private fun letterColor(): Int {
        val pc = prefs
        if (pc != null && pc.getBoolean("txt_custom", false)) {
            val h = pc.getInt("txt_hue", 200).toFloat().coerceIn(0f, 360f)
            val sa = (pc.getInt("txt_sat", 100) / 100f).coerceIn(0f, 1f)
            val v = (pc.getInt("txt_val", 100) / 100f).coerceIn(0.3f, 1f)
            return Color.HSVToColor(floatArrayOf(h, sa, v))
        }
        val def = if (lightTheme()) Color.parseColor("#1B1B1F") else Color.WHITE
        return when ((prefs?.getInt("txt_color", 0) ?: 0).coerceIn(0, 8)) {
            1 -> Color.parseColor("#6EA8FF")
            2 -> Color.parseColor("#5EE08A")
            3 -> Color.parseColor("#C39BFF")
            4 -> Color.parseColor("#FF5A5A")
            5 -> Color.parseColor("#FF8FC0")
            6 -> Color.BLACK
            7 -> Color.WHITE
            8 -> autoText
            else -> def
        }
    }

    private fun calcAutoColors(bmp: android.graphics.Bitmap) {
        try {
            val sm = android.graphics.Bitmap.createScaledBitmap(bmp, 8, 8, true)
            var r = 0L
            var g = 0L
            var b = 0L
            for (x in 0 until 8) for (y in 0 until 8) {
                val p = sm.getPixel(x, y)
                r += Color.red(p)
                g += Color.green(p)
                b += Color.blue(p)
            }
            val hsv = FloatArray(3)
            Color.RGBToHSV((r / 64).toInt(), (g / 64).toInt(), (b / 64).toInt(), hsv)
            val s1 = Math.min(0.75f, Math.max(0.25f, hsv[1]))
            val k = Color.HSVToColor(floatArrayOf(hsv[0], s1, 0.32f))
            val f = Color.HSVToColor(floatArrayOf(hsv[0], s1 * 0.85f, 0.46f))
            autoColors = Pair(String.format("#%06X", k and 0xFFFFFF), String.format("#%06X", f and 0xFFFFFF))
            autoText = Color.HSVToColor(floatArrayOf(hsv[0], 0.45f, 1f))
        } catch (e: Throwable) {
            autoColors = null
            autoText = Color.WHITE
        }
    }


    // الثيم الفعلي: ثيم التطبيق، وبعده الوقت (فاتح بالنهار)، وبعده الثيم العادي
    private fun effTheme(): Int {
        val p = prefs ?: return 0
        if (p.getBoolean("app_theme_on", true) && curPkg.isNotEmpty()) {
            val a = p.getInt("app_theme_" + curPkg, -1)
            if (a in 0..8) return a
        }
        if (p.getBoolean("theme_auto", false)) {
            val h = java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY)
            if (h in 6..17) return 7
        }
        return p.getInt("theme", 0)
    }

    private val themeNames = listOf("أساسي", "أزرق", "أخضر", "بنفسجي", "أحمر", "وردي", "أسود", "فاتح", "من الخلفية")

    // بيلف على الثيمات للتطبيق اللي فاتح، وآخرها الرجوع للافتراضي
    private fun cycleAppTheme() {
        val p = prefs ?: return
        if (curPkg.isEmpty()) {
            toast("مفيش تطبيق دلوقتي")
            return
        }
        if (!p.getBoolean("app_theme_on", true)) {
            toast("شغّل \"ثيم لكل تطبيق\" من الإعدادات")
            return
        }
        val k = "app_theme_" + curPkg
        val next = maxOf(p.getInt(k, 0), 0) + 1
        if (next > 8) {
            p.edit().remove(k).apply()
            toast("ثيم التطبيق: الافتراضي")
        } else {
            p.edit().putInt(k, next).apply()
            toast("ثيم التطبيق: " + themeNames[next])
        }
        applyBackground()
        render()
    }

    private fun lightTheme(): Boolean = effTheme() == 7

    private fun themed(color: String): String {
        if (color != C_KEY && color != C_FUNC) return color
        val t = effTheme().coerceIn(0, 8)
        if (t == 8) {
            val ac = autoColors ?: return color
            return if (color == C_KEY) ac.first else ac.second
        }
        if (t == 0) return color
        return if (color == C_KEY) themes[t].first else themes[t].second
    }

    private fun keyInt(color: String): Int {
        val v = Color.parseColor(themed(color))
        return if (bgOn && (color == C_KEY || color == C_FUNC)) {
            (v and 0x00FFFFFF) or (keyAlpha shl 24)
        } else {
            v
        }
    }

    // اهتزاز وصوت عند الضغط (من الإعدادات)
    private fun feedback(rx: Float = -1f, ry: Float = -1f) {
        val p = prefs ?: return
        if (p.getBoolean("vib", false)) {
            val ms = when (p.getInt("vib_str", 2)) {
                1 -> 12L
                3 -> 40L
                else -> 22L
            }
            try {
                val v = vibrator ?: (getSystemService(Context.VIBRATOR_SERVICE) as Vibrator).also { vibrator = it }
                if (Build.VERSION.SDK_INT >= 26) {
                    v.vibrate(VibrationEffect.createOneShot(ms, VibrationEffect.DEFAULT_AMPLITUDE))
                } else {
                    @Suppress("DEPRECATION")
                    v.vibrate(ms)
                }
            } catch (e: Exception) {
                // مش مهم
            }
        }
        if (p.getBoolean("snd", false)) {
            try {
                val style = p.getInt("snd_style", 0)
                if (style == 0) {
                    val am = audio ?: (getSystemService(Context.AUDIO_SERVICE) as AudioManager).also { audio = it }
                    am.playSoundEffect(AudioManager.FX_KEYPRESS_STANDARD, p.getInt("snd_vol", 60) / 100f)
                } else {
                    val ks = keySounds ?: KeySounds(this).also { keySounds = it }
                    val w = kbFrame?.width ?: 0
                    val pos = if (w > 0 && rx >= 0f) rx / w else 0.5f
                    ks.play(style, p.getInt("snd_vol", 60) / 100f, pos)
                }
            } catch (e: Exception) {
                // مش مهم
            }
        }
        if (rx >= 0f) rgbView?.pulse(rx, ry)
    }

    private var keySounds: KeySounds? = null
    private var rgbView: RgbView? = null

    private fun applyRgb() {
        val p = prefs ?: return
        rgbView?.applyState(p.getBoolean("rgb_border", false), p.getBoolean("rgb_press", false), p.getInt("rgb_style", 0), p.getInt("rgb_press_style", 0))
        val style = p.getInt("snd_style", 0)
        if (p.getBoolean("snd", false) && style > 0) {
            val ks = keySounds ?: KeySounds(this).also { keySounds = it }
            ks.prepare(style)
        }
    }

    // زرار عام: ضغطة، ضغط مطوّل (قائمة اختيارات أو حدث)، وتكرار للمسح
    // pre = رقم الاختيار المظلل أول ما القائمة تفتح (-1 = مفيش)
    private fun key(
        label: String,
        weight: Float = 1f,
        color: String = C_KEY,
        hint: String? = null,
        opts: List<String> = emptyList(),
        onOpt: ((String) -> Unit)? = null,
        onLong: (() -> Unit)? = null,
        autoRepeat: Boolean = false,
        pre: Int = -1,
        textSize: Float = 18f,
        swipeCursor: Boolean = false,
        forceHint: Boolean = false,
        onTap: () -> Unit
    ): FrameLayout {
        val fl = FrameLayout(this)
        // من غير هوامش: الزرار بياخد المساحة كلها (مفيش فواصل ميتة)، والمسافة الشكلية بتتعمل بالـ Inset
        val lp = LinearLayout.LayoutParams(0, kh() + dp(6), weight)
        fl.layoutParams = lp
        val bg = roundBg(color)
        val boxOn = (prefs?.getBoolean("key_box", true) ?: true) || effTheme() != (prefs?.getInt("theme", 0) ?: 0)
        val boxSize = prefs?.getInt("key_box_size", 100) ?: 100
        val restColor = if (boxOn) keyInt(color) else Color.TRANSPARENT
        bg.setColor(restColor)
        val insH = ((100 - boxSize) / 100f * dp(14)).toInt()
        val insV = ((100 - boxSize) / 100f * dp(10)).toInt()
        fl.background = InsetDrawable(bg, insH + dp(2), insV + dp(3), insH + dp(2), insV + dp(3))

        val tv = TextView(this)
        tv.text = label
        val lc = letterColor()
        tv.setTextColor(lc)
        if ((prefs?.getInt("txt_color", 0) ?: 0) != 0 || prefs?.getBoolean("txt_custom", false) == true) {
            var hasLetter = false
            for (ch in label) if (ch.isLetterOrDigit()) hasLetter = true
            if (hasLetter) tv.paint.colorFilter = android.graphics.PorterDuffColorFilter(lc, android.graphics.PorterDuff.Mode.SRC_IN)
        }
        tv.textSize = if (textSize == 18f || textSize == 22f) letterSize() else textSize
        if (!boxOn) tv.setShadowLayer(8f, 0f, 0f, Color.BLACK)
        tv.gravity = Gravity.CENTER
        letterFace()?.let { tv.typeface = it }
        fl.addView(
            tv,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        )

        if (hint != null && (forceHint || (prefs?.getBoolean("hints", true) ?: true))) {
            val h = TextView(this)
            h.text = hint
            h.textSize = 10f
            h.setTextColor(Color.parseColor(if (lightTheme()) "#555560" else "#C8C8D0"))
            val hp = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
            hp.gravity = Gravity.TOP or Gravity.END
            hp.setMargins(0, dp(2), dp(5), 0)
            fl.addView(h, hp)
        }

        var longHandled = false
        var popupShown = false
        var selected = -1
        var downX = 0f
        var downY = 0f
        var swiped = false
        var lastSwipeX = 0f

        val longTask = Runnable {
            if (onLong != null) {
                longHandled = true
                onLong()
            } else if (opts.isNotEmpty()) {
                popupShown = true
                showPopup(fl, opts, pre)
                selected = pre
                highlightPopup(pre)
            }
        }

        fl.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    longHandled = false
                    popupShown = false
                    selected = -1
                    downX = e.rawX
                    downY = e.rawY
                    swiped = false
                    lastSwipeX = e.rawX
                    bg.setColor(Color.parseColor(C_PRESS))
                    feedback(e.rawX, e.rawY)
                    if (autoRepeat) {
                        onTap()
                        startRepeat(onTap)
                    } else if (onLong != null || opts.isNotEmpty()) {
                        handler.postDelayed(longTask, (prefs?.getInt("lp_ms", 350) ?: 350).toLong())
                    }
                }
                MotionEvent.ACTION_MOVE -> {
                    if (swipeCursor && !popupShown && !longHandled) {
                        val step = dp(16).toFloat()
                        val dx = e.rawX - lastSwipeX
                        if (Math.abs(dx) >= step) {
                            handler.removeCallbacks(longTask)
                            if (!swiped) resetWord()
                            val n = (Math.abs(dx) / step).toInt()
                            val code = if (dx > 0) KeyEvent.KEYCODE_DPAD_RIGHT else KeyEvent.KEYCODE_DPAD_LEFT
                            for (k in 0 until n) sendDownUpKeyEvents(code)
                            lastSwipeX += (if (dx > 0) 1 else -1) * n * step
                            swiped = true
                        }
                    }
                    if (popupShown) {
                        val moved = Math.abs(e.rawX - downX) > dp(10) ||
                            Math.abs(e.rawY - downY) > dp(10)
                        if (moved) {
                            val hit = popupHit(e.rawX, e.rawY)
                            if (hit >= 0) {
                                selected = hit
                            } else if (pre < 0) {
                                selected = -1
                            }
                            highlightPopup(selected)
                        }
                    }
                }
                MotionEvent.ACTION_UP -> {
                    handler.removeCallbacks(longTask)
                    stopRepeat()
                    bg.setColor(restColor)
                    if (popupShown) {
                        val idx = selected
                        dismissPopup()
                        if (idx >= 0) {
                            val cb = onOpt
                            if (cb != null) cb(opts[idx])
                        } else {
                            onTap()
                        }
                    } else if (!longHandled && !autoRepeat && !swiped) {
                        onTap()
                    }
                }
                MotionEvent.ACTION_CANCEL -> {
                    handler.removeCallbacks(longTask)
                    stopRepeat()
                    bg.setColor(restColor)
                    dismissPopup()
                }
            }
            true
        }
        return fl
    }

    private fun startRepeat(action: () -> Unit) {
        stopRepeat()
        val r = object : Runnable {
            override fun run() {
                action()
                handler.postDelayed(this, 55)
            }
        }
        repeatTask = r
        handler.postDelayed(r, 400)
    }

    private fun stopRepeat() {
        val r = repeatTask
        if (r != null) handler.removeCallbacks(r)
        repeatTask = null
    }

    // ------------------------------------------------------------------
    // قائمة الضغط المطوّل
    // ------------------------------------------------------------------

    private fun pillBg(color: String, radiusDp: Int): GradientDrawable {
        val g = GradientDrawable()
        g.cornerRadius = dp(radiusDp).toFloat()
        g.setColor(Color.parseColor(color))
        return g
    }

    // القائمة بتترسم جوه الكيبورد نفسه (طبقة فوق الزراير)
    private fun showPopup(anchor: View, opts: List<String>, pre: Int) {
        dismissPopup()
        val ov = overlay ?: return
        val n = opts.size
        val rows = if (n <= 6) 1 else if (n <= 16) 2 else 3
        val perRow = (n + rows - 1) / rows
        val itemW = dp(40)
        val itemH = dp(44)

        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.layoutDirection = View.LAYOUT_DIRECTION_LTR
        box.background = pillBg("#F2383842", 24)
        box.setPadding(dp(6), dp(5), dp(6), dp(5))
        var r: LinearLayout? = null
        for ((i, o) in opts.withIndex()) {
            if (i % perRow == 0) {
                val nr = LinearLayout(this)
                nr.orientation = LinearLayout.HORIZONTAL
                nr.layoutDirection = View.LAYOUT_DIRECTION_LTR
                box.addView(nr)
                r = nr
            }
            val t = TextView(this)
            val c = o[0]
            t.text = if (c in 'ً'..'ْ') "◌" + o else o
            t.setTextColor(Color.WHITE)
            t.textSize = 20f
            t.gravity = Gravity.CENTER
            t.layoutParams = LinearLayout.LayoutParams(itemW, itemH)
            r?.addView(t)
            popupViews.add(t)
        }
        box.measure(
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED),
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
        )
        val w = box.measuredWidth
        val h = box.measuredHeight

        val a = IntArray(2)
        anchor.getLocationOnScreen(a)
        val o2 = IntArray(2)
        ov.getLocationOnScreen(o2)
        val keyCx = a[0] - o2[0] + anchor.width / 2
        val keyTop = a[1] - o2[1]

        val col = if (pre >= 0) pre % perRow else 0
        var x = keyCx - dp(6) - col * itemW - itemW / 2
        if (x + w > ov.width - dp(2)) x = ov.width - dp(2) - w
        if (x < dp(2)) x = dp(2)
        var y = keyTop - h - dp(4)
        if (y < 0) y = 0

        val lp = FrameLayout.LayoutParams(w, h)
        lp.gravity = Gravity.TOP or Gravity.LEFT
        lp.leftMargin = x
        lp.topMargin = y
        ov.addView(box, lp)
        pill = box
    }

    private fun popupHit(x: Float, y: Float): Int {
        val b = pill ?: return -1
        if (popupViews.isEmpty()) return -1
        val loc = IntArray(2)
        b.getLocationOnScreen(loc)
        val tol = dp(24)
        if (x < loc[0] - tol || x > loc[0] + b.width + tol) return -1
        val itemH = popupViews[0].height
        if (itemH <= 0) return -1
        var ri = ((y - loc[1] - b.paddingTop) / itemH).toInt()
        if (ri < 0) ri = 0
        if (ri >= b.childCount) ri = b.childCount - 1
        val rowV = b.getChildAt(ri) as LinearLayout
        var best = -1
        var bestD = Float.MAX_VALUE
        val l2 = IntArray(2)
        for (k in 0 until rowV.childCount) {
            val v = rowV.getChildAt(k) as TextView
            v.getLocationOnScreen(l2)
            val d = Math.abs(l2[0] + v.width / 2f - x)
            if (d < bestD) {
                bestD = d
                best = popupViews.indexOf(v)
            }
        }
        return best
    }

    private fun highlightPopup(sel: Int) {
        for ((i, v) in popupViews.withIndex()) {
            if (i == sel) v.background = pillBg("#5B8DEF", 22) else v.background = null
        }
    }

    private fun dismissPopup() {
        val p = pill
        if (p != null) {
            try {
                (p.parent as? ViewGroup)?.removeView(p)
            } catch (e: Exception) {
                // مش مهم
            }
        }
        pill = null
        popupViews.clear()
    }

    // ------------------------------------------------------------------
    // الشاشة والطبقات
    // ------------------------------------------------------------------

    override fun onCreateInputView(): View {
        val frame = KbFrame(this)
        frame.layoutDirection = View.LAYOUT_DIRECTION_LTR
        kbFrame = frame

        // طبقة 0: لون الخلفية، 1: صورة الخلفية، 2: تغميق
        val body = View(this)
        body.setBackgroundColor(Color.parseColor(C_BG))
        frame.addView(body, FrameLayout.LayoutParams(-1, -1))
        val holder = FrameLayout(this)
        val img = ImageView(this)
        img.scaleType = ImageView.ScaleType.CENTER_CROP
        img.visibility = View.GONE
        holder.addView(img, FrameLayout.LayoutParams(-1, -1))
        bgImage = img
        val vid = LoopVideoView(this)
        vid.visibility = View.GONE
        holder.addView(vid, FrameLayout.LayoutParams(-1, -1))
        bgVideo = vid
        frame.addView(holder, FrameLayout.LayoutParams(-1, -1))
        val scrim = View(this)
        scrim.visibility = View.GONE
        frame.addView(scrim, FrameLayout.LayoutParams(-1, -1))
        bgScrim = scrim

        // طبقة 3: الكيبورد نفسه
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.layoutDirection = View.LAYOUT_DIRECTION_LTR
        root.setPadding(dp(3), dp(2), dp(3), dp(6))

        // الشريط العلوي
        val bar = LinearLayout(this)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.layoutDirection = View.LAYOUT_DIRECTION_LTR
        bar.gravity = Gravity.CENTER_VERTICAL
        bar.layoutParams = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            if (isLandscape()) dp(36) else dp(46)
        )
        topBar = bar
        val mic = toolButton("🎤") { toggleMic() }
        micBtn = mic
        bar.addView(mic)

        // اقتراحات الكلمات
        val svs = ArrayList<TextView>()
        for (k in 0 until 3) {
            val t = TextView(this)
            t.setTextColor(Color.WHITE)
            t.textSize = 16f
            t.maxLines = 1
            t.ellipsize = TextUtils.TruncateAt.END
            t.gravity = Gravity.CENTER
            t.setPadding(dp(4), 0, dp(4), 0)
            t.layoutParams = LinearLayout.LayoutParams(0, dp(36), 1f)
            t.setOnClickListener {
                if (midMode == 3) {
                    applyCalc()
                } else if (midMode == 4) {
                    sendShot()
                } else if (midMode == 1) {
                    val c = clipChip
                    if (c != null) {
                        val wantSum = it === sugViews.getOrNull(0)
                        clipChip = null
                        val full = chipOut(c)
                        commitOther(if (wantSum) (Summarizer.summarize(full) ?: full) else full)
                        scheduleSug()
                    }
                } else if (midMode == 2) {
                    layer = L_CLIP
                    resetWord()
                    grabClip()
                    render()
                } else {
                    val sg = it.tag
                    if (sg is Sug) applySug(sg)
                }
            }
            t.setOnLongClickListener {
                if (midMode == 4) {
                    shotHandledId = shotId
                    shotUri = null
                    scheduleSug()
                    true
                } else if (midMode == 1) {
                    clipChip = null
                    scheduleSug()
                    true
                } else {
                    val sg = it.tag
                    if (midMode == 0 && sg is Sug) {
                        forgetWord(sg.word)
                        true
                    } else {
                        false
                    }
                }
            }
            svs.add(t)
            bar.addView(t)
        }
        sugViews = svs

        val grid = toolButton("☰") {
            layer = if (layer == L_PANEL) L_AR else L_PANEL
            resetWord()
            render()
        }
        bar.addView(grid)
        // صندوق الترجمة (بيظهر في وضع الترجمة بس)
        val tb = LinearLayout(this)
        tb.orientation = LinearLayout.VERTICAL
        tb.layoutDirection = View.LAYOUT_DIRECTION_LTR
        tb.visibility = View.GONE
        val tr = LinearLayout(this)
        tr.orientation = LinearLayout.HORIZONTAL
        tr.gravity = Gravity.CENTER
        tr.addView(toolButton("✕") { exitTrans() })
        val sc = toolButton("") { openLangPicker(true) }
        transSrcChip = sc
        tr.addView(sc)
        tr.addView(toolButton("⇄") { swapTransLang() })
        val tc = toolButton("") { openLangPicker(false) }
        transTgtChip = tc
        tr.addView(tc)
        tb.addView(tr)
        val ef = EditText(this)
        ef.isFocusable = false
        ef.isFocusableInTouchMode = false
        ef.setTextColor(Color.WHITE)
        ef.setHintTextColor(Color.parseColor("#99FFFFFF"))
        ef.hint = "اكتب النص هنا لترجمته"
        ef.textSize = 16f
        ef.maxLines = 3
        ef.background = roundBg(C_FUNC)
        ef.setPadding(dp(12), 0, dp(12), 0)
        val elp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(40))
        elp.setMargins(dp(4), dp(2), dp(4), dp(4))
        ef.layoutParams = elp
        ef.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(a: CharSequence?, b: Int, c: Int, d: Int) {}
            override fun onTextChanged(a: CharSequence?, b: Int, c: Int, d: Int) {}
            override fun afterTextChanged(e: Editable?) {
                scheduleTranslate()
            }
        })
        transField = ef
        transConn = TransConn(ef)
        tb.addView(ef)
        transBox = tb
        refreshTransChips()
        root.addView(tb)
        root.addView(bar)

        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.layoutDirection = View.LAYOUT_DIRECTION_LTR
        content = c
        root.addView(c)
        frame.addView(root, FrameLayout.LayoutParams(-1, -2))

        // طبقة 4: قوائم الضغط المطوّل
        val ov = FrameLayout(this)
        ov.layoutDirection = View.LAYOUT_DIRECTION_LTR
        frame.addView(ov, FrameLayout.LayoutParams(-1, -1))
        overlay = ov

        // طبقة 5: وضع تغيير الحجم
        val rl = buildResizeLayer()
        frame.addView(rl, FrameLayout.LayoutParams(-1, -1))
        resizeLayer = rl

        val rgb = RgbView(this)
        frame.addView(rgb, FrameLayout.LayoutParams(-1, -1))
        rgbView = rgb

        applyBackground()
        applyLayoutPrefs()
        applyRgb()
        render()
        return frame
    }

    // قراءة إعدادات الخلفية (صورة + تغميق + شفافية الزراير)
    private fun applyBackground() {
        val p = prefs ?: getSharedPreferences("franco", Context.MODE_PRIVATE)
        val iv = bgImage ?: return
        val sc = bgScrim ?: return
        val vid = bgVideo
        val vf = File(filesDir, "kb_bg.mp4")
        val useVideo = vid != null && vf.exists() && p.getString("bg_type", "image") == "video"
        if (useVideo && vid != null) {
            iv.visibility = View.GONE
            vid.visibility = View.VISIBLE
            vid.play(vf.path, vf.lastModified())
            bgOn = true
        } else {
            vid?.stop()
            vid?.visibility = View.GONE
            val f = File(filesDir, "kb_bg.jpg")
            if (f.exists()) {
                if (bgStamp != f.lastModified()) {
                    try {
                        val bo = BitmapFactory.Options()
                        bo.inJustDecodeBounds = true
                        BitmapFactory.decodeFile(f.path, bo)
                        var sm = 1
                        while (bo.outWidth / sm > 1400 || bo.outHeight / sm > 1400) sm *= 2
                        val bo2 = BitmapFactory.Options()
                        bo2.inSampleSize = sm
                        val bmp = BitmapFactory.decodeFile(f.path, bo2)
                        iv.setImageBitmap(bmp)
                        if (bmp != null) calcAutoColors(bmp)
                        bgStamp = if (bmp != null) f.lastModified() else -1L
                    } catch (e: Throwable) {
                        bgStamp = -1L
                    }
                }
            } else {
                iv.setImageDrawable(null)
                bgStamp = -1L
            }
            bgOn = bgStamp >= 0
            iv.visibility = if (bgOn) View.VISIBLE else View.GONE
        }
        val dim = p.getInt("bg_dim", 35)
        sc.setBackgroundColor(Color.argb(dim * 255 / 100, 0, 0, 0))
        sc.visibility = if (bgOn) View.VISIBLE else View.GONE
        keyAlpha = if (bgOn) p.getInt("key_alpha", 60) * 255 / 100 else 255
    }

    private var topBar: LinearLayout? = null

    private fun isLandscape(): Boolean =
        resources.configuration.orientation == android.content.res.Configuration.ORIENTATION_LANDSCAPE

    private fun minScale(): Float = if (isLandscape()) 0.4f else 0.6f

    override fun onConfigurationChanged(newConfig: android.content.res.Configuration) {
        super.onConfigurationChanged(newConfig)
        applyLayoutPrefs()
        if (content != null) render()
    }

    // حجم ومكان الكيبورد المحفوظين
    private fun applyLayoutPrefs() {
        val p = prefs ?: return
        val land = isLandscape()
        if (!resizeMode) {
            hScale = p.getFloat(if (land) "kb_h_l" else "kb_h", if (land) 0.62f else 1f).coerceIn(minScale(), 1.7f)
            kbL = p.getFloat(if (land) "kb_l_l" else "kb_l", if (land) 0.12f else 0f).coerceIn(0f, 0.55f)
            kbR = p.getFloat(if (land) "kb_r_l" else "kb_r", if (land) 0.88f else 1f).coerceIn(0.45f, 1f)
            if (kbR - kbL < 0.45f) {
                kbL = 0f
                kbR = 1f
            }
        }
        kbFrame?.setBounds(kbL, kbR)
        topBar?.let { b ->
            val lp = b.layoutParams
            if (lp != null) {
                val want = if (land) dp(36) else dp(46)
                if (lp.height != want) {
                    lp.height = want
                    b.layoutParams = lp
                }
            }
        }
    }

    // ------------------------------------------------------------------
    // وضع تغيير الحجم: إطار أزرق ومقابض
    // ------------------------------------------------------------------

    private fun resizeButton(label: String, onClick: () -> Unit): TextView {
        val t = TextView(this)
        t.text = label
        t.setTextColor(Color.WHITE)
        t.textSize = 15f
        t.gravity = Gravity.CENTER
        t.setPadding(dp(18), 0, dp(18), 0)
        t.background = pillBg("#4F7DF3", 22)
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(44))
        lp.setMargins(dp(6), 0, dp(6), 0)
        t.layoutParams = lp
        t.setOnClickListener { onClick() }
        return t
    }

    private fun handleBox(wDp: Int, hDp: Int, pillW: Int, pillH: Int, gravity: Int): FrameLayout {
        val box = FrameLayout(this)
        val p = View(this)
        p.background = pillBg("#4F7DF3", 4)
        box.addView(p, FrameLayout.LayoutParams(dp(pillW), dp(pillH), Gravity.CENTER))
        box.layoutParams = FrameLayout.LayoutParams(dp(wDp), dp(hDp), gravity)
        return box
    }

    private fun buildResizeLayer(): FrameLayout {
        val rl = FrameLayout(this)
        rl.visibility = View.GONE
        rl.setBackgroundColor(Color.parseColor("#55000000"))
        // بيمنع الضغط على الزراير اللي تحته
        rl.setOnTouchListener { _, _ -> true }

        val border = View(this)
        val bd = GradientDrawable()
        bd.setColor(Color.TRANSPARENT)
        bd.setStroke(dp(3), Color.parseColor("#4F7DF3"))
        bd.cornerRadius = dp(14).toFloat()
        border.background = bd
        rl.addView(border, FrameLayout.LayoutParams(-1, -1))

        // مقبض فوق: الارتفاع
        val top = handleBox(160, 34, 64, 6, Gravity.TOP or Gravity.CENTER_HORIZONTAL)
        var startY = 0f
        var startH = 1f
        top.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    startY = e.rawY
                    startH = hScale
                }
                MotionEvent.ACTION_MOVE -> {
                    val d = (startY - e.rawY) / (4f * dp(46))
                    val nh = (startH + d).coerceIn(minScale(), 1.7f)
                    if (nh != hScale) {
                        hScale = nh
                        render()
                    }
                }
            }
            true
        }
        rl.addView(top)

        // مقبض الشمال واليمين: العرض
        val left = handleBox(34, 120, 6, 64, Gravity.START or Gravity.CENTER_VERTICAL)
        left.setOnTouchListener { _, e ->
            val f = kbFrame
            if (f != null && f.width > 0 &&
                (e.actionMasked == MotionEvent.ACTION_DOWN || e.actionMasked == MotionEvent.ACTION_MOVE)
            ) {
                val loc = IntArray(2)
                f.getLocationOnScreen(loc)
                kbL = ((e.rawX - loc[0]) / f.width).coerceIn(0f, kbR - 0.45f)
                f.setBounds(kbL, kbR)
            }
            true
        }
        rl.addView(left)

        val right = handleBox(34, 120, 6, 64, Gravity.END or Gravity.CENTER_VERTICAL)
        right.setOnTouchListener { _, e ->
            val f = kbFrame
            if (f != null && f.width > 0 &&
                (e.actionMasked == MotionEvent.ACTION_DOWN || e.actionMasked == MotionEvent.ACTION_MOVE)
            ) {
                val loc = IntArray(2)
                f.getLocationOnScreen(loc)
                kbR = ((e.rawX - loc[0]) / f.width).coerceIn(kbL + 0.45f, 1f)
                f.setBounds(kbL, kbR)
            }
            true
        }
        rl.addView(right)

        // النص: تم - تحريك - إعادة ضبط
        val mid = LinearLayout(this)
        mid.orientation = LinearLayout.HORIZONTAL
        mid.layoutDirection = View.LAYOUT_DIRECTION_LTR
        mid.gravity = Gravity.CENTER
        mid.addView(resizeButton("تم ✓") { exitResizeMode(true) })

        val move = TextView(this)
        move.text = "✥"
        move.setTextColor(Color.WHITE)
        move.textSize = 22f
        move.gravity = Gravity.CENTER
        move.background = pillBg("#4F7DF3", 26)
        val mlp = LinearLayout.LayoutParams(dp(52), dp(52))
        mlp.setMargins(dp(6), 0, dp(6), 0)
        move.layoutParams = mlp
        var lastX = 0f
        move.setOnTouchListener { _, e ->
            val f = kbFrame
            if (f != null && f.width > 0) {
                when (e.actionMasked) {
                    MotionEvent.ACTION_DOWN -> lastX = e.rawX
                    MotionEvent.ACTION_MOVE -> {
                        val dx = (e.rawX - lastX) / f.width
                        lastX = e.rawX
                        val w = kbR - kbL
                        val nl = (kbL + dx).coerceIn(0f, 1f - w)
                        kbL = nl
                        kbR = nl + w
                        f.setBounds(kbL, kbR)
                    }
                }
            }
            true
        }
        mid.addView(move)

        mid.addView(resizeButton("إعادة ضبط") {
            val ls = isLandscape()
            hScale = if (ls) 0.62f else 1f
            kbL = if (ls) 0.12f else 0f
            kbR = if (ls) 0.88f else 1f
            kbFrame?.setBounds(kbL, kbR)
            render()
        })
        rl.addView(mid, FrameLayout.LayoutParams(-2, -2, Gravity.CENTER))
        return rl
    }

    private fun enterResizeMode() {
        if (resizeMode) return
        resizeMode = true
        dismissPopup()
        resizeLayer?.visibility = View.VISIBLE
    }

    private fun exitResizeMode(save: Boolean) {
        if (!resizeMode) return
        resizeMode = false
        resizeLayer?.visibility = View.GONE
        if (save) {
            val ls = isLandscape()
            prefs?.edit()
                ?.putFloat(if (ls) "kb_h_l" else "kb_h", hScale)
                ?.putFloat(if (ls) "kb_l_l" else "kb_l", kbL)
                ?.putFloat(if (ls) "kb_r_l" else "kb_r", kbR)
                ?.apply()
        }
    }

    // زرار آخر منسوخ في الشريط
    private fun refreshChip() {
        val c = chipView ?: return
        if (clips.isEmpty()) {
            c.text = ""
            c.background = null
        } else {
            c.text = clips[0].replace('\n', ' ').trim()
            c.background = roundBg(C_FUNC)
        }
    }

    private fun refreshToggle() {
        refreshMic()
        val b = toggleBtn ?: return
        b.text = if (francoOn) "فرانكو ✓" else "عربي"
        b.background = roundBg(if (francoOn) C_GREEN else C_FUNC)
        val a = autoBtn
        if (a != null) {
            a.text = if (autoOn) "تصحيح ✓" else "تصحيح ✗"
            a.background = roundBg(if (autoOn) C_GREEN else C_FUNC)
        }
    }

    private fun render() {
        val c = content ?: return
        dismissPopup()
        c.removeAllViews()
        if (layer == L_AR || layer == L_EN || layer == L_FR) baseLayer = layer
        saveLastState()
        when (layer) {
            L_FR -> buildFranco(c)
            L_AR -> buildArabic(c)
            L_EN -> buildEnglish(c)
            L_SYM1 -> buildSym1(c)
            L_SYM2 -> buildSym2(c)
            L_NUM -> buildNumpad(c)
            L_CLIP -> buildClipboard(c)
            L_EMO -> buildEmoji(c)
            L_PANEL -> buildPanel(c)
            L_LANG -> buildLangPicker(c)
            L_F2A -> buildF2A(c)
            L_DECO -> buildDeco(c)
        }
        refreshToggle()
        refreshChip()
        scheduleSug()
    }

    private fun variants(ch: Char): List<String> = when (ch) {
        'ا' -> listOf("أ", "إ", "آ", "ء")
        'و' -> listOf("ؤ")
        'ي' -> listOf("ئ", "ى")
        'ه' -> listOf("ة")
        'ب' -> listOf("پ")
        'ج' -> listOf("چ")
        'ف' -> listOf("ڤ")
        'ك' -> listOf("گ")
        'ز' -> listOf("ژ")
        'ل' -> listOf("لا", "لأ", "لإ", "لآ")
        else -> emptyList()
    }

    private val marks: List<String> = listOf(
        "َ", "ُ", "ِ", "ً", "ٌ", "ٍ", "ّ", "ْ"
    )

    // الصف الفوقاني: الرقم (غربي وعربي) أول، وبعده البدايل والتشكيل.
    // باقي الحروف: الحرف نفسه مظلل أول، وبعده البدايل والتشكيل.
    private fun arKey(ch: Char, digit: String?): FrameLayout {
        val opts = ArrayList<String>()
        if (digit != null) {
            opts.add(digit)
            opts.add(arabicIndic(digit[0]))
        } else {
            opts.add(ch.toString())
        }
        opts.addAll(variants(ch))
        opts.addAll(marks)
        return key(ch.toString(), 1f, C_KEY, digit, opts, { o ->
            val c = o[0]
            if (c.isDigit()) {
                commitOther(o)
            } else if (isMark(c)) {
                typeSymbol(o)
            } else {
                for (x in o) typeLetter(x)
            }
        }, pre = 0) {
            typeLetter(ch)
        }
    }

    private fun nextLang() {
        val frOn = prefs?.getBoolean("fr_layout", true) != false
        val t = when (layer) {
            L_AR -> L_EN
            L_EN -> if (frOn) L_FR else L_AR
            else -> L_AR
        }
        go(t)
    }

    private fun baseLabel(): String = when (baseLayer) {
        L_EN -> "English"
        L_FR -> "Franco"
        else -> if (francoOn) "فرانكو" else "العربية"
    }

    private fun abcLabel(): String = if (baseLayer == L_AR) "أبج" else "ABC"

    // كتابة حرف زي ما هو من غير تحويل ولا تصحيح (لوحة فرانكو)
    private fun typeRaw(t: String) {
        val ic = currentInputConnection ?: return
        resetWord()
        ic.commitText(t, 1)
    }

    private fun frKey(ch: Char, digit: String?, map: Map<Char, Pair<String, List<String>>>): FrameLayout {
        val e = map[ch] ?: Pair(FrDefaults.defMain(ch), emptyList<String>())
        val list = ArrayList<String>()
        list.add(e.first)
        for (a in e.second) if (a.isNotEmpty() && !list.contains(a)) list.add(a)
        if (digit != null && !list.contains(digit)) list.add(digit)
        val showHint = prefs?.getBoolean("fr_hint", true) != false
        val opts: List<String> = if (list.size > 1) list else emptyList()
        return key(
            e.first, 1f, C_KEY, if (showHint) ch.toString() else null, opts, { o -> typeRaw(o) },
            pre = if (opts.isEmpty()) -1 else 0,
            textSize = if (e.first.length > 1) 15f else 18f,
            forceHint = true
        ) {
            typeRaw(e.first)
        }
    }

    private fun buildFranco(c: LinearLayout) {
        val map = FrDefaults.toList(FrDefaults.loadRaw(prefs))
        val digits = "1234567890"
        val rows = listOf("ضصثقفغعهخحج", "شسيبلاتنمكط", "ذءؤرىةوزظد")
        for ((ri, row) in rows.withIndex()) {
            val r = newRow()
            for ((i, ch) in row.withIndex()) {
                r.addView(frKey(ch, if (ri == 0 && i < 10) digits[i].toString() else null, map))
            }
            if (ri == 2) r.addView(backKey())
            c.addView(r)
        }
        val b = newRow()
        b.addView(key("?123", 1.4f, C_FUNC, textSize = 14f) { go(L_SYM1) })
        b.addView(
            key(
                ",", 1f, C_KEY, hint = "☺",
                opts = listOf(OPT_CLIP, OPT_EMO, OPT_KB, OPT_SET),
                onOpt = { commaOpt(it) }, pre = 1, forceHint = true
            ) { commitOther(",") }
        )
        b.addView(key("🌐", 1f, C_FUNC, onLong = { showPicker() }) { nextLang() })
        b.addView(spaceKey("Franco", 4f))
        b.addView(dotKey(true))
        b.addView(enterKey())
        c.addView(b)
    }

    private fun spaceKey(label: String, w: Float = 4f): FrameLayout =
        key(label, w, C_KEY, textSize = 14f, swipeCursor = true, onLong = {
            try {
                showPicker()
            } catch (e: Exception) {
                // مش مهم
            }
        }) { commitOther(" ") }

    private fun enterKey(): FrameLayout =
        key("⏎", 1.4f, C_ACCENT) { doEnter() }

    private val enDotOpts: List<String> = listOf(
        "?", "!", ",", "'", "\"", "-", ":", ";", "(", ")", "@", "…"
    )

    private fun dotKey(english: Boolean = false): FrameLayout =
        if (english) {
            key(".", 1f, C_KEY, opts = enDotOpts, onOpt = { commitOther(it) }) { commitOther(".") }
        } else {
            key(".", 1f, C_KEY, opts = dotOpts, onOpt = { typeSymbol(it) }) { commitOther(".") }
        }

    private fun backKey(): FrameLayout =
        key("⌫", 1.5f, C_FUNC, autoRepeat = true) { doDelete() }

    // ---------------- عربي ----------------

    private fun buildArabic(c: LinearLayout) {
        val digits = "1234567890"
        val r0 = newRow()
        for ((i, ch) in "ضصثقفغعهخحج".withIndex()) {
            r0.addView(arKey(ch, if (i < 10) digits[i].toString() else null))
        }
        c.addView(r0)

        val r1 = newRow()
        for (ch in "شسيبلاتنمكط") r1.addView(arKey(ch, null))
        c.addView(r1)

        val r2 = newRow()
        for (ch in "ذءؤرىةوزظد") r2.addView(arKey(ch, null))
        r2.addView(backKey())
        c.addView(r2)

        val b = newRow()
        b.addView(key(if (francoOn) "?123" else "?١٢٣", 1.4f, C_FUNC, textSize = 14f) { go(L_SYM1) })
        b.addView(
            key("،", 1f, C_KEY, hint = "☺", opts = listOf(OPT_CLIP, OPT_EMO, OPT_KB, OPT_SET), onOpt = { commaOpt(it) }, pre = 1, forceHint = true) {
                commitOther("،")
            }
        )
        b.addView(key("🌐", 1f, C_FUNC, onLong = { showPicker() }) { nextLang() })
        b.addView(spaceKey(if (francoOn) "فرانكو" else "العربية", 4f))
        b.addView(dotKey())
        b.addView(enterKey())
        c.addView(b)
    }

    // ---------------- إنجليزي ----------------

    private fun enVariants(ch: Char): List<String> = when (ch) {
        'a' -> listOf("à", "á", "â", "ä", "æ", "ã", "å", "ā")
        'c' -> listOf("ç", "ć", "č")
        'd' -> listOf("ð")
        'e' -> listOf("è", "é", "ê", "ë", "ē", "ė", "ę")
        'g' -> listOf("ğ")
        'i' -> listOf("î", "ï", "í", "ī", "į", "ì")
        'l' -> listOf("ł")
        'n' -> listOf("ñ", "ń")
        'o' -> listOf("ô", "ö", "ò", "ó", "œ", "ø", "ō", "õ")
        's' -> listOf("ß", "ś", "š")
        'u' -> listOf("û", "ü", "ù", "ú", "ū")
        'y' -> listOf("ý", "ÿ")
        'z' -> listOf("ž", "ź", "ż")
        else -> emptyList()
    }

    private fun enKey(ch: Char, digit: String?): FrameLayout {
        val shown = if (shift > 0) ch.uppercaseChar().toString() else ch.toString()
        val vs = enVariants(ch)
        val opts = ArrayList<String>()
        if (digit != null) {
            opts.add(digit)
        } else if (vs.isNotEmpty()) {
            opts.add(shown)
        }
        if (opts.isNotEmpty()) {
            for (v in vs) opts.add(if (shift > 0) v.uppercase() else v)
        }
        return key(shown, 1f, C_KEY, digit, opts, { o ->
            commitOther(o)
            if (shift == 1) {
                shift = 0
                render()
            }
        }, pre = if (opts.isNotEmpty()) 0 else -1) {
            commitOther(shown)
            if (shift == 1) {
                shift = 0
                render()
            }
        }
    }

    private fun buildEnglish(c: LinearLayout) {
        val digits = "1234567890"
        val r0 = newRow()
        for ((i, ch) in "qwertyuiop".withIndex()) r0.addView(enKey(ch, digits[i].toString()))
        c.addView(r0)

        val r1 = newRow()
        r1.addView(spacer(0.5f, true))
        for (ch in "asdfghjkl") r1.addView(enKey(ch, null))
        r1.addView(spacer(0.5f, true))
        c.addView(r1)

        val r2 = newRow()
        r2.addView(
            key(if (shift == 2) "⇪" else "⇧", 1.5f, if (shift > 0) C_ACCENT else C_FUNC) {
                val now = System.currentTimeMillis()
                shift = if (shift == 1 && now - lastShiftTap < 350) {
                    2
                } else if (shift == 0) {
                    1
                } else {
                    0
                }
                lastShiftTap = now
                render()
            }
        )
        for (ch in "zxcvbnm") r2.addView(enKey(ch, null))
        r2.addView(backKey())
        c.addView(r2)

        val b = newRow()
        b.addView(key("?123", 1.4f, C_FUNC, textSize = 14f) { go(L_SYM1) })
        b.addView(
            key(
                ",", 1f, C_KEY, hint = "☺",
                opts = listOf(OPT_CLIP, OPT_EMO, OPT_KB, OPT_SET),
                onOpt = { commaOpt(it) }, pre = 1, forceHint = true
            ) { commitOther(",") }
        )
        b.addView(key("🌐", 1f, C_FUNC, onLong = { showPicker() }) { nextLang() })
        b.addView(spaceKey("English", 4f))
        b.addView(dotKey(true))
        b.addView(enterKey())
        c.addView(b)
    }

    // ---------------- رموز 1 ----------------

    private fun symVariants(ch: Char): List<String> = when (ch) {
        '(' -> listOf("(", "[", "{", "<")
        ')' -> listOf(")", "]", "}", ">")
        '[' -> listOf("[", "(", "{", "<")
        ']' -> listOf("]", ")", "}", ">")
        '-' -> listOf("-", "–", "—", "•")
        '_' -> listOf("_", "—", "–", "·")
        '+' -> listOf("+", "±")
        '/' -> listOf("/", "\\", "|")
        '|' -> listOf("|", "\\", "¦")
        '$' -> listOf("\$", "¢", "£", "€", "¥", "₹", "₽")
        '&' -> listOf("&", "§")
        '#' -> listOf("#", "№")
        '"' -> listOf("\"", "„", "“", "”", "«", "»")
        '\'' -> listOf("'", "‚", "‘", "’", "‹", "›")
        '!' -> listOf("!", "¡")
        '؟' -> listOf("؟", "?")
        ':' -> listOf(":", "…")
        '*' -> listOf("*", "★", "†", "‡")
        '=' -> listOf("=", "≠", "≈", "∞")
        '%' -> listOf("%", "‰")
        '°' -> listOf("°", "′", "″")
        '^' -> listOf("^", "↑", "←", "↓", "→")
        'π' -> listOf("π", "Ω", "µ")
        '•' -> listOf("•", "♪", "♥", "♦", "♣", "♠")
        '~' -> listOf("~", "≈")
        '£' -> listOf("£", "\$", "€")
        '€' -> listOf("€", "\$", "£")
        '¥' -> listOf("¥", "\$", "€")
        '{' -> listOf("{", "[", "(", "<")
        '}' -> listOf("}", "]", ")", ">")
        else -> emptyList()
    }

    private fun symKey(ch: Char): FrameLayout {
        val s = ch.toString()
        val v = symVariants(ch)
        return key(s, 1f, C_KEY, opts = v, onOpt = { commitOther(it) }, pre = if (v.isNotEmpty()) 0 else -1) {
            commitOther(s)
        }
    }

    private fun arabicIndic(d: Char): String =
        ('٠' + (d - '0')).toString()

    private fun digitOpts(d: Char): List<String> = when (d) {
        '0' -> listOf("0", "⁰", "ⁿ", "∅", "°")
        '1' -> listOf("1", "¹", "½", "⅓", "¼", "⅕", "⅙", "⅐", "⅛", "⅑", "⅒")
        '2' -> listOf("2", "²", "⅔", "⅖")
        '3' -> listOf("3", "³", "¾", "⅗", "⅜")
        '4' -> listOf("4", "⁴", "⅘")
        '5' -> listOf("5", "⁵", "⅚", "⅝")
        '6' -> listOf("6", "⁶")
        '7' -> listOf("7", "⁷", "⅞")
        '8' -> listOf("8", "⁸")
        '9' -> listOf("9", "⁹")
        else -> listOf(d.toString())
    }

    private fun digitKey(d: Char): FrameLayout {
        val list = ArrayList<String>(digitOpts(d))
        list.add(arabicIndic(d))
        return key(d.toString(), 1f, C_KEY, opts = list, onOpt = { commitOther(it) }, pre = 0) {
            commitOther(d.toString())
        }
    }

    // أرقام عربية (١٢٣): الأساسية، والضغط المطوّل بيدي الأرقام الإنجليزي
    private fun digitKeyAr(d: Char): FrameLayout {
        val list = ArrayList<String>()
        list.add(arabicIndic(d))
        list.addAll(digitOpts(d))
        return key(arabicIndic(d), 1f, C_KEY, opts = list, onOpt = { commitOther(it) }, pre = 0) {
            commitOther(arabicIndic(d))
        }
    }

    private fun buildSym1(c: LinearLayout) {
        val r0 = newRow()
        val arSym = !francoOn && baseLayer == L_AR
        for (d in "1234567890") {
            r0.addView(if (arSym) digitKeyAr(d) else digitKey(d))
        }
        c.addView(r0)

        val r1 = newRow()
        for (ch in "@#\$_&-+()/") r1.addView(symKey(ch))
        c.addView(r1)

        val r2 = newRow()
        r2.addView(key("=\\<", 1.5f, C_FUNC, textSize = 14f) { go(L_SYM2) })
        for (ch in (if (arSym) "*\"':؛!؟" else "*\"':;!?")) r2.addView(symKey(ch))
        r2.addView(backKey())
        c.addView(r2)

        val b = newRow()
        b.addView(key(abcLabel(), 1.4f, C_FUNC, textSize = 14f) { go(baseLayer) })
        val comma = if (arSym) "،" else ","
        b.addView(key(comma, 1f) { commitOther(comma) })
        b.addView(key("12/34", 1f, C_FUNC, textSize = 12f) { go(L_NUM) })
        b.addView(spaceKey(baseLabel()))
        b.addView(dotKey(baseLayer != L_AR))
        b.addView(enterKey())
        c.addView(b)
    }

    // ---------------- رموز 2 ----------------

    private fun buildSym2(c: LinearLayout) {
        val r0 = newRow()
        for (ch in "~`|•√π÷×§∆") r0.addView(symKey(ch))
        c.addView(r0)

        val r1 = newRow()
        for (ch in "£¢€¥^°={}\\") r1.addView(symKey(ch))
        c.addView(r1)

        val r2 = newRow()
        r2.addView(key(if (francoOn || baseLayer != L_AR) "?123" else "?١٢٣", 1.5f, C_FUNC, textSize = 14f) { go(L_SYM1) })
        for (ch in "%©®™✓[]") r2.addView(symKey(ch))
        r2.addView(backKey())
        c.addView(r2)

        val b = newRow()
        b.addView(key(abcLabel(), 1.4f, C_FUNC, textSize = 14f) { go(baseLayer) })
        b.addView(key("«", 1f) { commitOther("«") })
        b.addView(key("12/34", 1f, C_FUNC, textSize = 12f) { go(L_NUM) })
        b.addView(spaceKey(baseLabel()))
        b.addView(key("»", 1f) { commitOther("»") })
        b.addView(enterKey())
        c.addView(b)
    }

    // ---------------- لوحة الأرقام ----------------

    private fun numKey(label: String, weight: Float, color: String = C_KEY): FrameLayout =
        key(label, weight, color, textSize = 22f) { commitOther(label) }

    private fun buildNumpad(c: LinearLayout) {
        val ops = 0.8f
        val num = 1.4f

        val r0 = newRow()
        r0.addView(numKey("+", ops, C_FUNC))
        r0.addView(numKey("1", num))
        r0.addView(numKey("2", num))
        r0.addView(numKey("3", num))
        r0.addView(numKey("%", ops, C_FUNC))
        c.addView(r0)

        val r1 = newRow()
        r1.addView(numKey("-", ops, C_FUNC))
        r1.addView(numKey("4", num))
        r1.addView(numKey("5", num))
        r1.addView(numKey("6", num))
        r1.addView(key("␣", ops, C_FUNC) { commitOther(" ") })
        c.addView(r1)

        val r2 = newRow()
        r2.addView(numKey("*", ops, C_FUNC))
        r2.addView(numKey("7", num))
        r2.addView(numKey("8", num))
        r2.addView(numKey("9", num))
        r2.addView(key("⌫", ops, C_FUNC, autoRepeat = true) { doDelete() })
        c.addView(r2)

        val r3 = newRow()
        r3.addView(key(abcLabel(), 1.2f, C_FUNC, textSize = 14f) { go(baseLayer) })
        r3.addView(numKey("،", 0.9f))
        r3.addView(key("!?#", 1f, C_FUNC, textSize = 14f) { go(L_SYM1) })
        r3.addView(numKey("0", num))
        r3.addView(numKey("=", 0.9f))
        r3.addView(numKey(".", 0.9f))
        r3.addView(key("⏎", 1.2f, C_ACCENT) { doEnter() })
        c.addView(r3)
    }

    // ---------------- الإيموجي ----------------

    private val emoTabs = listOf(
        Pair("recent", "🕒"), Pair("smileys", "😀"), Pair("people", "👋"),
        Pair("nature", "🐶"), Pair("food", "🍔"), Pair("activities", "⚽"),
        Pair("travel", "🚗"), Pair("objects", "💡"), Pair("symbols", "🔣"),
        Pair("flags", "🏁")
    )

    private fun loadEmoji() {
        if (emoData != null) return
        val m = LinkedHashMap<String, List<String>>()
        try {
            assets.open("emoji.txt").bufferedReader(Charsets.UTF_8).useLines { lines ->
                for (line in lines) {
                    val t = line.indexOf('\t')
                    if (t > 0) {
                        m[line.substring(0, t)] =
                            line.substring(t + 1).trim().split(" ").filter { it.isNotEmpty() }
                    }
                }
            }
        } catch (e: Exception) {
            // مش مهم
        }
        emoData = m
        emoRecent.clear()
        val s = prefs?.getString("emo_recent", "") ?: ""
        for (p in s.split("\u0001")) {
            if (p.isNotEmpty()) emoRecent.add(p)
        }
    }

    private fun addEmoRecent(e: String) {
        emoRecent.remove(e)
        emoRecent.add(0, e)
        while (emoRecent.size > 32) emoRecent.removeAt(emoRecent.size - 1)
        prefs?.edit()?.putString("emo_recent", emoRecent.joinToString("\u0001"))?.apply()
    }

    private val OPT_CLIP = "📋"
    private val OPT_EMO = "😊"
    private val OPT_KB = "⌨"
    private val OPT_SET = "⚙"

    private fun openEmoji() {
        loadEmoji()
        prevLayer = layer
        emoCat = if (emoRecent.isNotEmpty()) "recent" else "smileys"
        go(L_EMO)
    }

    // ضغطة طويلة على الفاصلة: الحافظة، الإيموجي، تغيير الكيبورد، الإعدادات
    private fun commaOpt(o: String) {
        when (o) {
            OPT_CLIP -> {
                layer = L_CLIP
                resetWord()
                grabClip()
                render()
            }
            OPT_EMO -> openEmoji()
            OPT_KB -> showPicker()
            OPT_SET -> {
                try {
                    val i = Intent(this, SettingsActivity::class.java)
                    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    startActivity(i)
                } catch (e: Exception) {
                    // مش مهم
                }
            }
            else -> commitOther(o)
        }
    }

    private fun emojiKey(): FrameLayout =
        key("😊", 1f, C_FUNC) {
            loadEmoji()
            prevLayer = layer
            emoCat = if (emoRecent.isNotEmpty()) "recent" else "smileys"
            go(L_EMO)
        }

    private fun buildEmoji(c: LinearLayout) {
        loadEmoji()
        val tabs = newRow()
        tabs.layoutParams = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, dp(40)
        )
        for (tab in emoTabs) {
            val t = TextView(this)
            t.text = tab.second
            t.textSize = 19f
            kbFont()?.let { t.typeface = it }
            t.gravity = Gravity.CENTER
            val lp = LinearLayout.LayoutParams(0, dp(36), 1f)
            lp.setMargins(dp(2), dp(2), dp(2), dp(2))
            t.layoutParams = lp
            if (tab.first == emoCat) t.background = pillBg("#6A6F80", 18)
            t.setOnClickListener {
                emoCat = tab.first
                render()
            }
            tabs.addView(t)
        }
        c.addView(tabs)

        val items: List<String> =
            if (emoCat == "recent") ArrayList(emoRecent) else (emoData?.get(emoCat) ?: emptyList())
        val scroll = ScrollView(this)
        scroll.layoutParams = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, dp(150)
        )
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.layoutDirection = View.LAYOUT_DIRECTION_LTR
        if (items.isEmpty()) {
            val empty = TextView(this)
            empty.text = "الإيموجي اللي بتستخدمها هتظهر هنا"
            empty.setTextColor(Color.parseColor("#C8C8D0"))
            empty.textSize = 15f
            empty.gravity = Gravity.CENTER
            empty.setPadding(dp(8), dp(50), dp(8), dp(8))
            col.addView(empty)
        }
        var row: LinearLayout? = null
        var inRow = 0
        for ((i, e) in items.withIndex()) {
            if (i % 8 == 0) {
                val r = newRow()
                col.addView(r)
                row = r
                inRow = 0
            }
            val tv = TextView(this)
            tv.text = e
            tv.textSize = 24f
            kbFont()?.let { tv.typeface = it }
            tv.gravity = Gravity.CENTER
            tv.layoutParams = LinearLayout.LayoutParams(0, dp(44), 1f)
            tv.setOnClickListener {
                addEmoRecent(e)
                commitOther(e)
            }
            row?.addView(tv)
            inRow++
        }
        if (row != null && inRow in 1..7) {
            for (k in inRow until 8) {
                val sp = View(this)
                sp.layoutParams = LinearLayout.LayoutParams(0, dp(44), 1f)
                row.addView(sp)
            }
        }
        scroll.addView(col)
        c.addView(scroll)

        val b = newRow()
        b.addView(key("أبج", 1.4f, C_FUNC, textSize = 14f) { go(prevLayer) })
        b.addView(spaceKey(baseLabel(), 4f))
        b.addView(backKey())
        c.addView(b)
    }

    // ---------------- الحافظة ----------------

    private fun buildClipboard(c: LinearLayout) {
        val head = newRow()
        head.addView(key(abcLabel(), 1.2f, C_FUNC, textSize = 14f) { go(baseLayer) })
        val title = TextView(this)
        title.text = "الحافظة"
        title.setTextColor(Color.WHITE)
        title.textSize = 16f
        title.gravity = Gravity.CENTER
        title.layoutParams = LinearLayout.LayoutParams(0, kh(), 3f)
        head.addView(title)
        head.addView(key("مسح الكل", 1.6f, C_FUNC, textSize = 13f) {
            forgetAllClips()
            render()
        })
        c.addView(head)

        val scroll = ScrollView(this)
        scroll.layoutParams = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            dp(190)
        )
        val list = LinearLayout(this)
        list.orientation = LinearLayout.VERTICAL
        if (clips.isEmpty() && pins.isEmpty()) {
            val empty = TextView(this)
            empty.text = "انسخ أي نص وهيظهر هنا"
            empty.setTextColor(Color.parseColor("#B0B0B8"))
            empty.textSize = 15f
            empty.gravity = Gravity.CENTER
            empty.setPadding(dp(8), dp(40), dp(8), dp(8))
            list.addView(empty)
        } else {
            val all = ArrayList(clips)
            val nums = ArrayList<String>()
            val texts = ArrayList<String>()
            for (t in all) if (isNumberClip(t)) nums.add(t) else texts.add(t)
            clipSection(list, "📌 مثبّت", ArrayList(pins), true)
            clipSection(list, "🔢 أرقام", nums, false)
            clipSection(list, "💬 جمل", texts, false)
        }
        scroll.addView(list)
        c.addView(scroll)
    }

    private fun isNumberClip(t: String): Boolean {
        var digit = false
        for (c in t.trim()) {
            if (c.isDigit()) {
                digit = true
            } else if ("+-().,/ :".indexOf(c) < 0) {
                return false
            }
        }
        return digit
    }

    private fun savePins() {
        prefs?.edit()?.putString("pins", pins.joinToString("\u0001"))?.apply()
    }

    private fun loadPins() {
        pins.clear()
        val v = prefs?.getString("pins", "") ?: ""
        if (v.isNotEmpty()) {
            for (p in v.split("\u0001")) if (p.isNotEmpty()) pins.add(p)
        }
    }

    private fun clipSection(list: LinearLayout, title: String, items: List<String>, pinned: Boolean) {
        if (items.isEmpty()) return
        val h = TextView(this)
        h.text = title
        h.setTextColor(Color.parseColor("#C8C8D0"))
        h.textSize = 13f
        h.setPadding(dp(8), dp(8), dp(8), dp(2))
        list.addView(h)
        for (t in items) list.addView(clipItem(t, pinned))
    }

    private fun clipItem(text: String, pinned: Boolean): View {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.background = roundBg(C_KEY)
        val rlp = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )
        rlp.setMargins(dp(2), dp(3), dp(2), dp(3))
        row.layoutParams = rlp

        val tv = TextView(this)
        tv.text = text
        tv.setTextColor(Color.WHITE)
        tv.textSize = 15f
        tv.maxLines = 2
        tv.ellipsize = TextUtils.TruncateAt.END
        tv.setPadding(dp(12), dp(10), dp(12), dp(10))
        tv.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        tv.setOnClickListener {
            commitOther(chipOut(text))
            go(baseLayer)
        }

        val pin = TextView(this)
        pin.text = "📌"
        pin.textSize = 16f
        pin.alpha = if (pinned) 1f else 0.35f
        pin.gravity = Gravity.CENTER
        pin.setPadding(dp(10), dp(10), dp(10), dp(10))
        pin.setOnClickListener {
            if (pinned) {
                pins.remove(text)
                clips.remove(text)
                clips.add(0, text)
            } else {
                clips.remove(text)
                pins.remove(text)
                pins.add(0, text)
            }
            savePins()
            saveClips()
            refreshChip()
            render()
        }

        val del = TextView(this)
        del.text = "✕"
        del.setTextColor(Color.parseColor("#B0B0B8"))
        del.textSize = 16f
        del.gravity = Gravity.CENTER
        del.setPadding(dp(14), dp(10), dp(14), dp(10))
        del.setOnClickListener {
            if (pinned) {
                pins.remove(text)
                savePins()
            } else {
                forgetClip(text)
            }
            render()
        }

        row.addView(tv)
        row.addView(pin)
        row.addView(del)
        return row
    }

    // ---------------- لوحة المميزات (☰) ----------------

    private fun letterSize(): Float = (prefs?.getInt("key_text", 18) ?: 18).toFloat()

    private fun changeLetterSize(d: Int) {
        val v = ((prefs?.getInt("key_text", 18) ?: 18) + d).coerceIn(12, 28)
        prefs?.edit()?.putInt("key_text", v)?.apply()
        render()
    }

    private fun forgetWord(w: String) {
        val k = if (w.isNotEmpty() && w[0] in 'ء'..'ي') w else w.lowercase()
        if (uni.remove(k) != null) {
            bi.keys.removeAll { it.endsWith("\u0003" + k) || it.startsWith(k + "\u0003") }
            saveLearn()
            toast("اتنسيت: " + k)
        } else {
            toast("الكلمة دي من القاموس الجاهز")
        }
        scheduleSug()
    }

    private fun sendCtrlZ() {
        val ic = currentInputConnection ?: return
        val now = SystemClock.uptimeMillis()
        ic.sendKeyEvent(KeyEvent(now, now, KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_Z, 0, KeyEvent.META_CTRL_ON))
        ic.sendKeyEvent(KeyEvent(now, now, KeyEvent.ACTION_UP, KeyEvent.KEYCODE_Z, 0, KeyEvent.META_CTRL_ON))
    }

    private val calcRegex = Regex("(?:[0-9٠-٩]+(?:[.,][0-9٠-٩]+)?[ ]?[+\\-*/x×÷][ ]?)+[0-9٠-٩]+(?:[.,][0-9٠-٩]+)?$")

    private fun calcLookup(): Boolean {
        calcExpr = ""
        calcRes = ""
        if (prefs?.getBoolean("calc", true) == false) return false
        if (typed.isEmpty() || !typed.last().isDigit()) return false
        val ic = currentInputConnection ?: return false
        val b = ic.getTextBeforeCursor(40, 0)?.toString() ?: return false
        if (b.isEmpty() || !b.last().isDigit()) return false
        val m = calcRegex.find(b) ?: return false
        val st = m.range.first
        if (st > 0 && (b[st - 1].isLetterOrDigit() || b[st - 1] == '.')) return false
        val expr = m.value
        val hasOp = expr.any { it == '+' || it == '*' || it == '/' || it == 'x' || it == '×' || it == '÷' }
        if (!hasOp && !expr.contains(" - ")) return false
        if (expr.count { it == '/' } >= 2 && !expr.any { it == '+' || it == '*' || it == 'x' || it == '×' }) return false
        val v = evalExpr(expr) ?: return false
        calcExpr = expr
        calcRes = fmtNum(v)
        return true
    }

    private fun evalExpr(e: String): Double? {
        val sb = StringBuilder()
        for (c0 in e.replace("في", "*").replace("على", "/")) {
            var c = c0
            if (c.isWhitespace()) continue
            if (c == '×' || c == 'x') c = '*'
            if (c == '÷') c = '/'
            if (c == ',') c = '.'
            if (c in '٠'..'٩') c = '0' + (c - '٠')
            sb.append(c)
        }
        val str = sb.toString()
        val nums = ArrayList<Double>()
        val ops = ArrayList<Char>()
        var i = 0
        while (i < str.length) {
            var j = i
            while (j < str.length && (str[j].isDigit() || str[j] == '.')) j++
            if (j == i) return null
            val n = str.substring(i, j).toDoubleOrNull() ?: return null
            nums.add(n)
            if (j < str.length) {
                if (str[j] != '+' && str[j] != '-' && str[j] != '*' && str[j] != '/') return null
                ops.add(str[j])
                j++
            }
            i = j
        }
        if (nums.size != ops.size + 1) return null
        val n2 = ArrayList<Double>()
        val o2 = ArrayList<Char>()
        n2.add(nums[0])
        for (k in ops.indices) {
            val op = ops[k]
            val x = nums[k + 1]
            if (op == '*') {
                n2[n2.size - 1] = n2[n2.size - 1] * x
            } else if (op == '/') {
                if (x == 0.0) return null
                n2[n2.size - 1] = n2[n2.size - 1] / x
            } else {
                o2.add(op)
                n2.add(x)
            }
        }
        var r = n2[0]
        for (k in o2.indices) r = if (o2[k] == '+') r + n2[k + 1] else r - n2[k + 1]
        if (r.isNaN() || r.isInfinite()) return null
        return r
    }

    private fun fmtNum(v: Double): String {
        if (v == Math.rint(v) && Math.abs(v) < 1e15) return v.toLong().toString()
        return String.format(java.util.Locale.US, "%.6f", v).trimEnd('0').trimEnd('.')
    }

    private fun applyCalc() {
        val ic = currentInputConnection ?: return
        val e = calcExpr
        val r = calcRes
        if (e.isEmpty()) return
        val bef = ic.getTextBeforeCursor(e.length, 0)?.toString() ?: ""
        if (bef != e) return
        ic.beginBatchEdit()
        ic.deleteSurroundingText(e.length, 0)
        ic.commitText(r, 1)
        ic.endBatchEdit()
        resetWord()
        calcExpr = ""
        calcRes = ""
        scheduleSug()
    }

    private val trackKeys = setOf(
        "fbclid", "gclid", "igshid", "igsh", "mc_cid", "mc_eid", "ref_src", "si", "feature",
        "yclid", "msclkid", "_hsenc", "_hsmi", "mkt_tok", "ttclid", "twclid", "wbraid", "gbraid",
        "dclid", "srsltid"
    )

    private fun cleanUrl(s0: String): String {
        val s = s0.trim()
        if (!(s.startsWith("http://") || s.startsWith("https://")) || s.any { it.isWhitespace() }) return s0
        val h = s.indexOf('#')
        val frag = if (h >= 0) s.substring(h) else ""
        val noFrag = if (h >= 0) s.substring(0, h) else s
        val q = noFrag.indexOf('?')
        if (q < 0) return s0
        val base = noFrag.substring(0, q)
        val kept = ArrayList<String>()
        for (p in noFrag.substring(q + 1).split("&")) {
            if (p.isEmpty()) continue
            val k = p.substringBefore('=').lowercase()
            if (k.startsWith("utm_") || trackKeys.contains(k)) continue
            kept.add(p)
        }
        return base + (if (kept.isEmpty()) "" else "?" + kept.joinToString("&")) + frag
    }

    private val emailRe = Regex("[A-Za-z0-9._%+\\-]+@[A-Za-z0-9.\\-]+\\.[A-Za-z]{2,}")
    private val urlRe = Regex("https?://[^\\s|<>\"'«»]+")

    // إيميل أو لينك وحواليه رموز زيادة (زي ||): بيرجع الإيميل أو اللينك بس
    private fun tidyClip(s0: String): String {
        val s = s0.trim()
        if (s.isEmpty() || s.length > 300) return s0
        val em = emailRe.find(s)
        if (em != null) {
            val rest = s.removeRange(em.range)
            if (rest.none { it.isLetterOrDigit() }) return em.value
        }
        val um = urlRe.find(s)
        if (um != null) {
            val u = um.value.trimEnd(')', ',', '.', ';', ']')
            val rest = s.removeRange(um.range.first, um.range.first + u.length)
            if (rest.none { it.isLetterOrDigit() }) return u
        }
        return s0
    }

    private fun chipOut(c: String): String {
        val t = tidyClip(c)
        return if (prefs?.getBoolean("link_clean", true) == false) t else cleanUrl(t)
    }

    private fun pasteCleanLink() {
        val ic = currentInputConnection ?: return
        var t = ""
        try {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            val clip = cm.primaryClip
            if (clip != null && clip.itemCount > 0) t = clip.getItemAt(0).coerceToText(this)?.toString() ?: ""
        } catch (e: Exception) {
            // مش مهم
        }
        if (t.isBlank()) {
            toast("مفيش حاجة منسوخة")
            return
        }
        resetWord()
        ic.commitText(cleanUrl(tidyClip(t)), 1)
    }

    // اكتب 5*5 وبعدها = والناتج يتكتب. + زائد، - ناقص، * ضرب (أو في)، / قسمة (أو على)
    private val eqRegex = Regex("(?:[0-9٠-٩]+(?:[.,][0-9٠-٩]+)?\\s*(?:[+\\-*/x×÷]|في|على)\\s*)+[0-9٠-٩]+(?:[.,][0-9٠-٩]+)?\\s*$")

    private fun tryEquals(ic: InputConnection): Boolean {
        if (prefs?.getBoolean("calc", true) == false) return false
        val b = ic.getTextBeforeCursor(60, 0)?.toString() ?: return false
        if (b.isEmpty()) return false
        val m = eqRegex.find(b) ?: return false
        val st = m.range.first
        if (st > 0 && (b[st - 1].isLetterOrDigit() || b[st - 1] == '.')) return false
        val v = evalExpr(m.value.trim()) ?: return false
        resetWord()
        if (prefs?.getBoolean("calc_keep", true) == false) {
            ic.deleteSurroundingText(m.value.length, 0)
            ic.commitText(fmtNum(v), 1)
        } else {
            ic.commitText("=" + fmtNum(v), 1)
        }
        return true
    }

    // ------------------------------------------------------------------
    // تحويل فرانكو -> عربي (للرسايل اللي حد يبعتهالك فرانكو)
    // ------------------------------------------------------------------

    private var f2aSrc = ""
    private var f2aOut = ""
    private var f2aRev: HashMap<String, String>? = null

    // كلمات شات شائعة (بتتغلب على التخمين)
    private val f2aCommon: Map<String, String> = mapOf(
        "ana" to "انا", "enta" to "انت", "enty" to "انتي", "enti" to "انتي", "howa" to "هو", "hya" to "هي", "7na" to "احنا",
        "ezay" to "ازاي", "ezayak" to "ازيك", "ezayek" to "ازيك", "eh" to "ايه", "eih" to "ايه", "leh" to "ليه", "fen" to "فين",
        "emta" to "امتى", "meen" to "مين", "min" to "مين", "keda" to "كده", "kda" to "كده", "dah" to "ده", "da" to "ده", "di" to "دي", "dy" to "دي",
        "mesh" to "مش", "msh" to "مش", "bas" to "بس", "law" to "لو", "lw" to "لو", "ya" to "يا", "yaa" to "يا", "wallahi" to "والله", "wallah" to "والله",
        "tamam" to "تمام", "tmam" to "تمام", "khalas" to "خلاص", "5alas" to "خلاص", "ok" to "اوكي", "okay" to "اوكي",
        "shokran" to "شكرا", "shukran" to "شكرا", "sho2ran" to "شكرا", "afwan" to "عفوا", "3afwan" to "عفوا",
        "3ashan" to "عشان", "3shan" to "عشان", "bardo" to "برضو", "bardu" to "برضو", "lesa" to "لسه", "lsa" to "لسه",
        "dlw2ty" to "دلوقتي", "dilwa2ty" to "دلوقتي", "delwa2ty" to "دلوقتي", "ya3ni" to "يعني", "y3ni" to "يعني", "ma3a" to "مع", "m3a" to "مع",
        "kwayes" to "كويس", "kwaies" to "كويس", "kowayes" to "كويس", "7elw" to "حلو", "7lw" to "حلو", "a7la" to "احلى",
        "ahlan" to "اهلا", "ahlaan" to "اهلا", "salam" to "سلام", "salamo" to "سلامو", "marhaba" to "مرحبا",
        "sa7by" to "صاحبي", "sa7bi" to "صاحبي", "7abibi" to "حبيبي", "7bibi" to "حبيبي", "ya7bibi" to "يا حبيبي",
        "inshallah" to "ان شاء الله", "insha2allah" to "ان شاء الله", "mashallah" to "ما شاء الله", "alhamdulillah" to "الحمد لله", "al7amdulillah" to "الحمد لله",
        "gamed" to "جامد", "gamda" to "جامدة", "kteer" to "كتير", "kter" to "كتير", "awi" to "اوي", "awy" to "اوي", "gedan" to "جدا", "giddan" to "جدا",
        "bokra" to "بكرة", "bukra" to "بكرة", "elnaharda" to "النهارده", "el naharda" to "النهارده", "naharda" to "النهارده", "ams" to "امس",
        "ayz" to "عايز", "3ayez" to "عايز", "3ayz" to "عايز", "3ayza" to "عايزة", "3ayeza" to "عايزة", "mafish" to "مفيش", "mafesh" to "مفيش", "fe" to "في", "fi" to "في",
        "e3mel" to "اعمل", "a3mel" to "اعمل", "3amel" to "عامل", "3amla" to "عاملة", "rou7" to "روح", "ro7" to "روح", "ta3ala" to "تعالى", "ta3al" to "تعالى",
        "mn" to "من", "men" to "من", "3la" to "على", "3ala" to "على", "ela" to "الا", "ila" to "الى", "7aga" to "حاجة", "7ga" to "حاجة", "kol" to "كل", "kolo" to "كله"
    )

    private fun f2aBuildRev() {
        if (f2aRev != null) return
        val m = HashMap<String, String>()
        try {
            val lines = ArrayList<String>()
            assets.open("words_ar.txt").bufferedReader(Charsets.UTF_8).useLines { seq ->
                for (l in seq) {
                    val t = l.trim()
                    if (t.isNotEmpty() && !t.startsWith("#")) lines.add(t.substringBefore('=').trim())
                }
            }
            for (k in dict.keys) lines.add(k)
            for (w in lines) {
                if (w.isEmpty() || w.any { it !in 'ء'..'ي' }) continue
                val fr = convertWord(w).lowercase()
                if (fr.isNotEmpty() && !m.containsKey(fr)) m[fr] = w
            }
        } catch (e: Exception) {
            // مش مهم
        }
        f2aRev = m
    }

    private fun f2aCollapse(w: String): String {
        val sb = StringBuilder()
        var run = 0
        for ((i, c) in w.withIndex()) {
            if (i > 0 && c == w[i - 1]) run++ else run = 1
            if (run <= 2) sb.append(c)
        }
        return sb.toString()
    }

    private fun f2aWord(raw: String): String {
        val w = raw.lowercase()
        if (w.all { it.isDigit() }) return raw
        val c1 = f2aCollapse(w)
        f2aCommon[w]?.let { return it }
        f2aCommon[c1]?.let { return it }
        f2aRev?.get(w)?.let { return it }
        f2aRev?.get(c1)?.let { return it }
        if (c1.length > 3 && (c1.startsWith("el") || c1.startsWith("al")) && c1[2] != ' ') {
            return "ال" + f2aWord(c1.substring(2))
        }
        // حرف واحد مكرر كتير (مثلاً tamaaam) بنقلله وندور تاني
        return f2aRules(c1)
    }

    private fun f2aRules(s: String): String {
        val out = StringBuilder()
        val n = s.length
        var i = 0
        while (i < n) {
            val c = s[i]
            val nx = if (i + 1 < n) s[i + 1] else ' '
            val atStart = i == 0
            val atEnd = i == n - 1
            // رقم + ' = حرف تاني (3' غ ، 7' خ ، 6' ظ ، 9' ض)
            if (nx == '\'' && (c == '3' || c == '7' || c == '6' || c == '9')) {
                out.append(when (c) { '3' -> 'غ'; '7' -> 'خ'; '6' -> 'ظ'; else -> 'ض' })
                i += 2
                continue
            }
            if (c == 's' && nx == 'h') { out.append('ش'); i += 2; continue }
            if (c == 'k' && nx == 'h') { out.append('خ'); i += 2; continue }
            if (c == 'g' && nx == 'h') { out.append('غ'); i += 2; continue }
            if (c == 't' && nx == 'h') { out.append('ث'); i += 2; continue }
            if (c == 'c' && nx == 'h') { out.append("تش"); i += 2; continue }
            if (c == 'a' && nx == 'a') { out.append('ا'); i += 2; continue }
            if ((c == 'e' && nx == 'e') || (c == 'i' && nx == 'i') || (c == 'e' && nx == 'i')) { out.append('ي'); i += 2; continue }
            if ((c == 'o' && nx == 'o') || (c == 'o' && nx == 'u') || (c == 'u' && nx == 'u')) { out.append('و'); i += 2; continue }
            when (c) {
                'a' -> if (atStart || atEnd || (i == n - 2 && nx.isLetter() && "aeiouyw".indexOf(nx) < 0) || (i == 1 && s[0] == 'y')) out.append('ا')
                'e' -> if (atStart) out.append('ا')
                'i' -> if (atStart) out.append('ا') else if (atEnd || (i == n - 2 && nx.isLetter() && "aeiouyw".indexOf(nx) < 0)) out.append('ي')
                'o', 'u' -> if (atStart) out.append('ا') else if (atEnd) out.append('و')
                'y' -> out.append('ي')
                'w' -> out.append('و')
                'b', 'p' -> out.append('ب')
                't' -> out.append('ت')
                'g', 'j' -> out.append('ج')
                'd' -> out.append('د')
                'r' -> out.append('ر')
                'z' -> out.append('ز')
                's' -> out.append('س')
                'f', 'v' -> out.append('ف')
                'q' -> out.append('ق')
                'k' -> out.append('ك')
                'l' -> out.append('ل')
                'm' -> out.append('م')
                'n' -> out.append('ن')
                'h' -> out.append('ه')
                'x' -> out.append("كس")
                'c' -> out.append('ك')
                '2' -> out.append('ق')
                '3' -> out.append('ع')
                '5' -> out.append('خ')
                '6' -> out.append('ط')
                '7' -> out.append('ح')
                '8' -> out.append('غ')
                '9' -> out.append('ص')
                else -> out.append(c)
            }
            i++
        }
        return out.toString()
    }

    private fun francoToArabic(text: String): String {
        f2aBuildRev()
        val sb = StringBuilder()
        val w = StringBuilder()
        fun isW(c: Char) = (c in 'a'..'z') || (c in 'A'..'Z') || c.isDigit() || c == '\''
        for ((i, c) in text.withIndex()) {
            if (isW(c) && !(c == '\'' && w.isEmpty())) {
                w.append(c)
            } else {
                if (w.isNotEmpty()) {
                    sb.append(f2aWord(w.toString().trimEnd('\'')))
                    w.setLength(0)
                }
                sb.append(
                    when (c) {
                        '?' -> '؟'
                        ',' -> '،'
                        else -> c
                    }
                )
            }
        }
        if (w.isNotEmpty()) sb.append(f2aWord(w.toString().trimEnd('\'')))
        return sb.toString()
    }

    private fun openF2A() {
        val t = (systemClipText() ?: "").trim()
        f2aSrc = t
        f2aOut = if (t.isEmpty()) "" else francoToArabic(t)
        layer = L_F2A
        resetWord()
        render()
    }

    private fun buildF2A(c: LinearLayout) {
        val head = newRow()
        head.addView(key(abcLabel(), 1.2f, C_FUNC, textSize = 14f) { go(baseLayer) })
        val title = TextView(this)
        title.text = "فرانكو ← عربي"
        title.setTextColor(Color.WHITE)
        title.textSize = 16f
        title.gravity = Gravity.CENTER
        title.layoutParams = LinearLayout.LayoutParams(0, kh(), 3f)
        head.addView(title)
        head.addView(key("🔄 من الحافظة", 1.6f, C_FUNC, textSize = 12f) { openF2A() })
        c.addView(head)

        val scroll = ScrollView(this)
        scroll.layoutParams = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            dp(150)
        )
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(10), dp(4), dp(10), dp(4))
        if (f2aSrc.isEmpty()) {
            val empty = TextView(this)
            empty.text = "انسخ الرسالة الفرانكو، وبعدين دوس \"من الحافظة\""
            empty.setTextColor(Color.parseColor("#B0B0B8"))
            empty.textSize = 15f
            empty.gravity = Gravity.CENTER
            empty.setPadding(dp(8), dp(40), dp(8), dp(8))
            box.addView(empty)
        } else {
            val src = TextView(this)
            src.text = f2aSrc
            src.setTextColor(Color.parseColor("#B0B0B8"))
            src.textSize = 13f
            src.maxLines = 3
            src.ellipsize = TextUtils.TruncateAt.END
            src.setPadding(0, 0, 0, dp(6))
            box.addView(src)
            val res = TextView(this)
            res.text = f2aOut
            res.setTextColor(Color.WHITE)
            res.textSize = 20f
            res.textDirection = View.TEXT_DIRECTION_RTL
            res.gravity = Gravity.START
            box.addView(res)
        }
        scroll.addView(box)
        c.addView(scroll)

        val btns = newRow()
        btns.addView(key("إدراج ✓", 1f, C_GREEN, textSize = 15f) {
            val ic = currentInputConnection
            if (ic != null && f2aOut.isNotEmpty()) {
                resetWord()
                ic.commitText(f2aOut, 1)
                go(baseLayer)
            }
        })
        btns.addView(key("نسخ", 1f, C_FUNC, textSize = 15f) {
            if (f2aOut.isNotEmpty()) {
                try {
                    val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                    cm.setPrimaryClip(android.content.ClipData.newPlainText("franco", f2aOut))
                    toast("اتنسخ")
                } catch (e: Exception) {
                    // مش مهم
                }
            }
        })
        c.addView(btns)
    }

    private fun panelRow(a: View, b: View): LinearLayout {
        val r = newRow()
        r.addView(a)
        r.addView(b)
        return r
    }

    private fun buildPanel(c: LinearLayout) {
        val onl = prefs?.getBoolean("online", true) ?: true
        c.addView(
            panelRow(
                key("📋 الحافظة", 1f, C_FUNC, textSize = 15f) {
                    layer = L_CLIP
                    resetWord()
                    grabClip()
                    render()
                },
                key(if (francoOn) "فرانكو ✓" else "عربي", 1f, if (francoOn) C_GREEN else C_FUNC, textSize = 15f) {
                    francoOn = !francoOn
                    saveFrancoApp()
                    resetWord()
                    render()
                }
            )
        )
        c.addView(
            panelRow(
                key(if (autoOn) "تصحيح ✓" else "تصحيح ✗", 1f, if (autoOn) C_GREEN else C_FUNC, textSize = 15f) {
                    autoOn = !autoOn
                    prefs?.edit()?.putBoolean("autocorrect", autoOn)?.apply()
                    resetWord()
                    render()
                },
                key(if (onl) "أونلاين ✓" else "أونلاين ✗", 1f, if (onl) C_GREEN else C_FUNC, textSize = 15f) {
                    prefs?.edit()?.putBoolean("online", !onl)?.apply()
                    render()
                }
            )
        )
        c.addView(
            panelRow(
                key("حروف أصغر  A−", 1f, C_FUNC, textSize = 15f) { changeLetterSize(-2) },
                key("حروف أكبر  A+", 1f, C_FUNC, textSize = 15f) { changeLetterSize(2) }
            )
        )
        c.addView(
            panelRow(
                key("تغيير الحجم", 1f, C_FUNC, textSize = 15f) {
                    layer = L_AR
                    render()
                    enterResizeMode()
                },
                key("⚙ الإعدادات", 1f, C_FUNC, textSize = 15f) {
                    try {
                        val i = Intent(this, SettingsActivity::class.java)
                        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        startActivity(i)
                    } catch (e: Exception) {
                        // مش مهم
                    }
                }
            )
        )
        (c.getChildAt(0) as? LinearLayout)?.addView(key("🔗 لينك", 1f, C_FUNC, textSize = 14f) { pasteCleanLink() })
        (c.getChildAt(2) as? LinearLayout)?.addView(key("↶ تراجع", 1f, C_FUNC, textSize = 13f) { sendCtrlZ() })
        (c.getChildAt(3) as? LinearLayout)?.addView(key("ترجمة المحدد", 1f, C_FUNC, textSize = 13f) { translateSelection() })
        val aiRow = newRow()
        aiRow.addView(key("📝 لخّص", 1f, C_FUNC, textSize = 14f) {
            go(baseLayer)
            summarizeText()
        })
        c.addView(aiRow)
        val row2 = newRow()
        row2.addView(key("𝓐 زخرفة", 1f, C_FUNC, textSize = 14f) { openDeco() })
        row2.addView(key("🎨 ثيم التطبيق", 1.2f, C_FUNC, textSize = 14f) {
            go(baseLayer)
            cycleAppTheme()
        })
        row2.addView(key(if (prefs?.getBoolean("auto_deco_on", false) == true) "🔡 تلقائي ✓" else "🔡 تلقائي ✗", 1.1f,
            if (prefs?.getBoolean("auto_deco_on", false) == true) C_GREEN else C_FUNC, textSize = 13f) { toggleAutoDeco() })
        c.addView(row2)
        val lastRow = newRow()
        lastRow.addView(key("🌐 ترجمة", 1f, C_FUNC, textSize = 15f) { enterTrans() })
        lastRow.addView(key("فرانكو←عربي", 1.3f, C_FUNC, textSize = 13f) { openF2A() })
        lastRow.addView(key("إخفاء ⌄", 1f, C_FUNC, textSize = 15f) { requestHideSelf(0) })
        lastRow.addView(key(if (baseLayer == L_AR) "أبج  رجوع" else "ABC  رجوع", 1f, C_FUNC, textSize = 15f) { go(baseLayer) })
        c.addView(lastRow)
    }
}

// حاوية الكيبورد: بتقيس الكيبورد (بالعرض المحدد) وبعدين الخلفية والقوائم
// طبقات: 0 لون، 1 صورة، 2 تغميق، 3 الكيبورد، 4 القوائم (على الشاشة كلها)، 5 تغيير الحجم
private class KbFrame(c: Context) : FrameLayout(c) {
    private var leftFrac = 0f
    private var rightFrac = 1f
    private var colLeft = 0
    private var colW = 0

    fun setBounds(l: Float, r: Float) {
        leftFrac = l
        rightFrac = r
        requestLayout()
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val wm = View.MeasureSpec.getMode(widthMeasureSpec)
        val fw = if (wm == View.MeasureSpec.UNSPECIFIED) {
            resources.displayMetrics.widthPixels
        } else {
            View.MeasureSpec.getSize(widthMeasureSpec)
        }
        colW = ((rightFrac - leftFrac) * fw).toInt()
        colLeft = (leftFrac * fw).toInt()
        val hm = View.MeasureSpec.getMode(heightMeasureSpec)
        val hs0 = if (hm == View.MeasureSpec.UNSPECIFIED) {
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
        } else {
            View.MeasureSpec.makeMeasureSpec(
                View.MeasureSpec.getSize(heightMeasureSpec),
                View.MeasureSpec.AT_MOST
            )
        }
        val col = getChildAt(3)
        col.measure(View.MeasureSpec.makeMeasureSpec(colW, View.MeasureSpec.EXACTLY), hs0)
        val h = col.measuredHeight
        setMeasuredDimension(fw, h)
        val cw = View.MeasureSpec.makeMeasureSpec(colW, View.MeasureSpec.EXACTLY)
        val fwS = View.MeasureSpec.makeMeasureSpec(fw, View.MeasureSpec.EXACTLY)
        val hs = View.MeasureSpec.makeMeasureSpec(h, View.MeasureSpec.EXACTLY)
        for (i in 0 until childCount) {
            if (i == 3) continue
            getChildAt(i).measure(if (i == 4) fwS else cw, hs)
        }
    }

    override fun onLayout(changed: Boolean, l: Int, t: Int, r: Int, b: Int) {
        val w = r - l
        val h = b - t
        for (i in 0 until childCount) {
            val v = getChildAt(i)
            if (i == 4) {
                v.layout(0, 0, w, h)
            } else {
                v.layout(colLeft, 0, colLeft + colW, h)
            }
        }
    }
}


// فيديو الخلفية: بيتكرر من غير توقف، من غير صوت، وبيملى المساحة (crop)
private class LoopVideoView(c: Context) : TextureView(c), TextureView.SurfaceTextureListener {
    private var mp: MediaPlayer? = null
    private var path: String? = null
    private var stamp = 0L
    private var surface: Surface? = null
    private var vw = 0
    private var vh = 0
    private var wantPlay = false

    init {
        surfaceTextureListener = this
    }

    fun play(p: String, st: Long) {
        wantPlay = true
        if (p == path && st == stamp && mp != null) {
            try {
                mp?.start()
            } catch (e: Exception) {
                // مش مهم
            }
            return
        }
        path = p
        stamp = st
        release()
        if (surface != null) start()
    }

    fun pause() {
        wantPlay = false
        try {
            mp?.pause()
        } catch (e: Exception) {
            // مش مهم
        }
    }

    fun stop() {
        wantPlay = false
        path = null
        release()
    }

    private fun start() {
        val sf = surface ?: return
        val p = path ?: return
        try {
            val m = MediaPlayer()
            mp = m
            m.setDataSource(p)
            m.setSurface(sf)
            m.isLooping = true
            m.setVolume(0f, 0f)
            m.setOnVideoSizeChangedListener { _, w, h ->
                vw = w
                vh = h
                fit()
            }
            m.setOnPreparedListener { if (wantPlay) it.start() }
            m.setOnErrorListener { _, _, _ ->
                release()
                true
            }
            m.prepareAsync()
        } catch (e: Exception) {
            release()
        }
    }

    private fun release() {
        try {
            mp?.release()
        } catch (e: Exception) {
            // مش مهم
        }
        mp = null
    }

    private fun fit() {
        if (vw == 0 || vh == 0 || width == 0 || height == 0) return
        val sc = Math.max(width.toFloat() / vw, height.toFloat() / vh)
        val m = Matrix()
        m.setScale(vw * sc / width, vh * sc / height, width / 2f, height / 2f)
        setTransform(m)
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        fit()
    }

    override fun onSurfaceTextureAvailable(st: SurfaceTexture, w: Int, h: Int) {
        surface = Surface(st)
        if (path != null && mp == null) start()
    }

    override fun onSurfaceTextureSizeChanged(st: SurfaceTexture, w: Int, h: Int) {
        fit()
    }

    override fun onSurfaceTextureDestroyed(st: SurfaceTexture): Boolean {
        release()
        try {
            surface?.release()
        } catch (e: Exception) {
            // مش مهم
        }
        surface = null
        return true
    }

    override fun onSurfaceTextureUpdated(st: SurfaceTexture) {}
}
