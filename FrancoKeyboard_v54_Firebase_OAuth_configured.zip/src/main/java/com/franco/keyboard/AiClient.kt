package com.franco.keyboard

// فاضي: كان فيه وضع AI واتشال
