# مؤجل: السيرفر ده مش مستخدم في النسخة 6.4
النسخة دي بتخلي كل مستخدم يحط مفتاح Gemini بتاعه. السيرفر ده للمستقبل لما تربط Blaze (راجع README-AR.md تحت).

# تشغيل السيرفر (عدّاد الأسئلة)

مرة واحدة بس، من الكمبيوتر (أو Termux / Cloud Shell على الموبايل):

1. فعّل خطة **Blaze** للمشروع franco-keyboard (Firebase Console ← Upgrade). حط Budget Alert صغير.
2. Firebase Console ← **Firestore Database** ← Create database (Production mode).
3. هات مفتاح من https://aistudio.google.com/apikey (للمشروع franco-keyboard).
4. في فولدر backend:
   ```
   npm i -g firebase-tools
   firebase login
   firebase functions:secrets:set GEMINI_API_KEY     # الصق المفتاح
   cd functions && npm install && cd ..
   firebase deploy --only functions,firestore:rules
   ```
5. ابني التطبيق (v63) وجرب.

## تغيير الحدود
في `functions/index.js`: `FREE_LIMIT` (10) و `WINDOW_MS` (12 ساعة) و `MODEL`.

## الاشتراك لاحقاً
أي مستخدم عنده custom claim اسمه `premium=true` ملوش حد. لما تضيف Google Play Billing (أو RevenueCat) خلي الـ webhook بتاعه ينفذ:
`admin.auth().setCustomUserClaims(uid, { premium: true })`

## App Check
بعد ما تسجل التطبيق (Play Integrity) وتتأكد إن الـ Verified عالي، غيّر `enforceAppCheck` لـ true وأعد deploy.
