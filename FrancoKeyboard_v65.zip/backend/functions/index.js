// Cloud Function: بتحدد عدد الأسئلة لكل مستخدم (10 كل 12 ساعة) وبعدين بتكلّم Gemini.
// المشتركين (custom claim: premium=true) ملهمش حد.
const { onCall, HttpsError } = require("firebase-functions/v2/https");
const { defineSecret } = require("firebase-functions/params");
const admin = require("firebase-admin");

admin.initializeApp();
const db = admin.firestore();
const GEMINI_KEY = defineSecret("GEMINI_API_KEY");

// ===== إعدادات تقدر تغيرها =====
const MODEL = "gemini-3.8-flash";
const FREE_LIMIT = 10;                 // عدد الأسئلة المجانية
const WINDOW_MS = 12 * 60 * 60 * 1000; // 12 ساعة
const MAX_QUESTION_CHARS = 2000;
const MAX_HISTORY = 12;
// ================================

const SYSTEM =
  "إنت مساعد ذكي جوه كيبورد موبايل. رد بنفس لغة ولهجة المستخدم " +
  "(لو كتب مصري أو فرانكو رد بالمصري بحروف عربي). خليك مختصر ومباشر " +
  "(غالباً 2 إلى 6 جمل) إلا لو طلب تفصيل. لو بعت صورة حللها وجاوب على سؤاله عنها. " +
  "من غير عناوين ماركداون ولا جداول، ومن غير رموز زيادة، لأن الرد ممكن يتقرا بصوت عالي.";

function waitText(ms) {
  const mins = Math.max(1, Math.ceil(ms / 60000));
  const h = Math.floor(mins / 60);
  const m = mins % 60;
  if (h > 0) return `${h} ساعة${m ? " و" + m + " دقيقة" : ""}`;
  return `${m} دقيقة`;
}

// بيحجز سؤال من رصيد المستخدم (داخل transaction عشان محدش يتحايل بطلبات متوازية)
async function reserve(uid) {
  const ref = db.collection("usage").doc(uid);
  const now = Date.now();
  return db.runTransaction(async (tx) => {
    const snap = await tx.get(ref);
    let count = 0;
    let start = now;
    if (snap.exists) {
      const d = snap.data();
      if (now - d.windowStart < WINDOW_MS) {
        count = d.count;
        start = d.windowStart;
      }
    }
    if (count >= FREE_LIMIT) {
      const left = start + WINDOW_MS - now;
      throw new HttpsError(
        "resource-exhausted",
        `خلصت ${FREE_LIMIT} أسئلة. هيتفتحوا تاني بعد ${waitText(left)}، أو اشترك عشان تسأل من غير حد.`
      );
    }
    tx.set(ref, { count: count + 1, windowStart: start });
    return { used: count + 1, windowStart: start };
  });
}

// لو Gemini فشل، بنرجّع السؤال للمستخدم
async function refund(uid) {
  const ref = db.collection("usage").doc(uid);
  await db.runTransaction(async (tx) => {
    const snap = await tx.get(ref);
    if (snap.exists && snap.data().count > 0) {
      tx.update(ref, { count: snap.data().count - 1 });
    }
  });
}

exports.askAi = onCall(
  {
    region: "us-central1",
    secrets: [GEMINI_KEY],
    timeoutSeconds: 60,
    memory: "256MiB",
    maxInstances: 20,
    // بعد ما تسجل التطبيق في App Check غيّرها لـ true
    enforceAppCheck: false,
  },
  async (request) => {
    if (!request.auth) {
      throw new HttpsError("unauthenticated", "سجّل دخول بحساب جوجل الأول");
    }
    const uid = request.auth.uid;
    const premium = request.auth.token.premium === true;

    const question = String((request.data && request.data.question) || "").trim();
    if (!question) throw new HttpsError("invalid-argument", "اكتب سؤال الأول");
    if (question.length > MAX_QUESTION_CHARS) {
      throw new HttpsError("invalid-argument", "السؤال طويل أوي، اختصره شوية");
    }

    let reserved = null;
    if (!premium) reserved = await reserve(uid);

    try {
      const history = Array.isArray(request.data.history) ? request.data.history.slice(-MAX_HISTORY) : [];
      const contents = history
        .filter((h) => h && typeof h.text === "string" && (h.role === "user" || h.role === "model"))
        .map((h) => ({ role: h.role, parts: [{ text: h.text.slice(0, 4000) }] }));

      const parts = [];
      const img = request.data.image;
      if (typeof img === "string" && img.length > 0 && img.length < 4_000_000) {
        parts.push({ inlineData: { mimeType: "image/jpeg", data: img } });
      }
      parts.push({ text: question });
      contents.push({ role: "user", parts });

      const resp = await fetch(
        `https://generativelanguage.googleapis.com/v1beta/models/${MODEL}:generateContent`,
        {
          method: "POST",
          headers: { "Content-Type": "application/json", "x-goog-api-key": GEMINI_KEY.value() },
          body: JSON.stringify({
            systemInstruction: { parts: [{ text: SYSTEM }] },
            contents,
          }),
        }
      );

      if (!resp.ok) {
        const body = await resp.text();
        console.error("Gemini error", resp.status, body);
        if (resp.status === 429) {
          throw new HttpsError("unavailable", "الـ AI مشغول دلوقتي (حد المشروع)، جرب بعد شوية");
        }
        throw new HttpsError("internal", `Gemini ${resp.status}: ${body.slice(0, 200)}`);
      }

      const json = await resp.json();
      const text = ((json.candidates && json.candidates[0] && json.candidates[0].content &&
        json.candidates[0].content.parts) || [])
        .map((p) => p.text || "")
        .join("")
        .trim();

      if (!text) {
        throw new HttpsError("failed-precondition", "الرد اتحجب أو فاضي، جرب صياغة تانية");
      }

      return {
        text,
        remaining: premium ? -1 : FREE_LIMIT - reserved.used,
        resetAt: premium ? 0 : reserved.windowStart + WINDOW_MS,
      };
    } catch (e) {
      if (!premium) await refund(uid).catch(() => {});
      if (e instanceof HttpsError) throw e;
      console.error(e);
      throw new HttpsError("internal", String(e.message || e).slice(0, 200));
    }
  }
);
