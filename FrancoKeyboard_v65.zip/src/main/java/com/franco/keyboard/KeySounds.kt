package com.franco.keyboard

import android.content.Context
import android.media.AudioAttributes
import android.media.SoundPool
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.sin

// أصوات الضغط: بتتولّد في الكود (من غير ملفات صوت) وبتتشغل بـ SoundPool
class KeySounds(private val ctx: Context) {
    private val rate = 22050
    private var pool: SoundPool? = null
    private val ids = HashMap<Int, IntArray>()
    private val ready = HashSet<Int>()
    private val loading = HashSet<Int>()
    private val sidToStyle = HashMap<Int, Int>()
    private val loaded = HashMap<Int, Int>()

    companion object {
        // 1 رنة، 2 ألحان (نغمة لكل مكان)، 3 قطرة، 4 ميكانيكي
        val NAMES = listOf("نقرة عادية", "رنة", "ألحان", "قطرة", "ميكانيكي")
        private val SCALE = doubleArrayOf(523.25, 587.33, 659.25, 783.99, 880.0, 1046.5, 1174.66, 1318.5, 1568.0, 1760.0)
    }

    private fun wav(samples: ShortArray): ByteArray {
        val data = samples.size * 2
        val b = ByteArrayOutputStream()
        fun i32(v: Int) {
            b.write(v and 255); b.write((v shr 8) and 255); b.write((v shr 16) and 255); b.write((v shr 24) and 255)
        }
        fun i16(v: Int) {
            b.write(v and 255); b.write((v shr 8) and 255)
        }
        b.write("RIFF".toByteArray()); i32(36 + data)
        b.write("WAVE".toByteArray()); b.write("fmt ".toByteArray())
        i32(16); i16(1); i16(1); i32(rate); i32(rate * 2); i16(2); i16(16)
        b.write("data".toByteArray()); i32(data)
        for (s in samples) i16(s.toInt())
        return b.toByteArray()
    }

    private fun bell(f: Double, dur: Double, decay: Double, amp: Double): ShortArray {
        val n = (rate * dur).toInt()
        val out = ShortArray(n)
        for (i in 0 until n) {
            val t = i.toDouble() / rate
            val env = exp(-t * decay) * (if (t < 0.004) t / 0.004 else 1.0)
            val v = sin(2 * PI * f * t) + 0.35 * sin(2 * PI * f * 2.0 * t) + 0.12 * sin(2 * PI * f * 3.01 * t)
            out[i] = (v * env * amp * 9000).toInt().coerceIn(-32000, 32000).toShort()
        }
        return out
    }

    private fun drop(): ShortArray {
        val n = (rate * 0.14).toInt()
        val out = ShortArray(n)
        var ph = 0.0
        for (i in 0 until n) {
            val t = i.toDouble() / rate
            val f = 700 + 1800 * t / 0.14
            ph += 2 * PI * f / rate
            out[i] = (sin(ph) * exp(-t * 28) * 12000).toInt().toShort()
        }
        return out
    }

    private fun mech(variant: Int): ShortArray {
        val n = (rate * 0.06).toInt()
        val out = ShortArray(n)
        val rnd = java.util.Random(7L + variant)
        for (i in 0 until n) {
            val t = i.toDouble() / rate
            val noise = (rnd.nextDouble() * 2 - 1) * exp(-t * 180)
            val thump = sin(2 * PI * (140 + variant * 15) * t) * exp(-t * 70)
            out[i] = ((noise * 0.7 + thump * 0.8) * 14000).toInt().coerceIn(-32000, 32000).toShort()
        }
        return out
    }

    private fun make(style: Int): List<ShortArray> = when (style) {
        1 -> listOf(bell(1318.5, 0.5, 6.0, 1.0))
        2 -> SCALE.map { bell(it, 0.45, 7.0, 0.9) }
        3 -> listOf(drop())
        4 -> listOf(mech(0), mech(1), mech(2))
        else -> emptyList()
    }

    private fun ensurePool(): SoundPool {
        pool?.let { return it }
        val attrs = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
            .build()
        val p = SoundPool.Builder().setMaxStreams(6).setAudioAttributes(attrs).build()
        p.setOnLoadCompleteListener { _, sid, status ->
            if (status == 0) synchronized(this) {
                val st = sidToStyle[sid]
                if (st != null) loaded[st] = (loaded[st] ?: 0) + 1
            }
        }
        pool = p
        return p
    }

    // تجهيز الصوت في الخلفية (أول مرة بس)
    fun prepare(style: Int) {
        if (style <= 0) return
        synchronized(this) {
            if (loading.contains(style) || ids.containsKey(style)) return
            loading.add(style)
        }
        Thread {
            try {
                val p = ensurePool()
                val list = make(style)
                val arr = IntArray(list.size)
                for ((i, s) in list.withIndex()) {
                    val f = File(ctx.cacheDir, "snd_${style}_$i.wav")
                    FileOutputStream(f).use { it.write(wav(s)) }
                    val sid = p.load(f.path, 1)
                    synchronized(this) { sidToStyle[sid] = style }
                    arr[i] = sid
                }
                synchronized(this) {
                    ids[style] = arr
                    ready.add(style)
                }
            } catch (e: Throwable) {
                synchronized(this) { loading.remove(style) }
            }
        }.start()
    }

    // pos: مكان الضغطة من 0 لـ 1 (للألحان)
    fun play(style: Int, vol: Float, pos: Float) {
        if (style <= 0) return
        val arr: IntArray = synchronized(this) {
            if (!ready.contains(style)) {
                prepare(style)
                return
            }
            ids[style]
        } ?: return
        val p = pool ?: return
        val sid = if (style == 2) arr[(pos.coerceIn(0f, 0.999f) * arr.size).toInt()]
        else if (style == 4) arr[Math.abs((System.nanoTime() / 1000L % arr.size).toInt())]
        else arr[0]
        try {
            p.play(sid, vol, vol, 1, 0, 1f)
        } catch (e: Throwable) {
            // مش مهم
        }
    }

    fun release() {
        try {
            pool?.release()
        } catch (e: Throwable) {
            // مش مهم
        }
        pool = null
        synchronized(this) {
            ids.clear()
            ready.clear()
            loading.clear()
            sidToStyle.clear()
            loaded.clear()
        }
    }
}
