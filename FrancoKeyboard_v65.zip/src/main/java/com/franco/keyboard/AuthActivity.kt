package com.franco.keyboard

import android.app.Activity
import android.app.AlertDialog
import android.os.Bundle
import android.os.CancellationSignal
import android.widget.Toast
import androidx.credentials.CredentialManager
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import androidx.credentials.GetCredentialResponse
import androidx.credentials.exceptions.GetCredentialException
import com.google.android.libraries.identity.googleid.GetSignInWithGoogleOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.GoogleAuthProvider

// شاشة شفافة: لو مش مسجل بتفتح تسجيل الدخول بجوجل، ولو مسجل بتعرض الحساب وزرار خروج
class AuthActivity : Activity() {

    private val signal = CancellationSignal()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val user = try {
            FirebaseAuth.getInstance().currentUser
        } catch (e: Exception) {
            toast("Firebase مش شغال: " + (e.message ?: ""))
            finish()
            return
        }
        if (user != null) showAccount() else startSignIn()
    }

    private fun showAccount() {
        val u = FirebaseAuth.getInstance().currentUser
        if (u == null) {
            finish()
            return
        }
        val name = u.displayName ?: ""
        val mail = u.email ?: ""
        AlertDialog.Builder(this)
            .setTitle("حسابك")
            .setMessage((if (name.isNotEmpty()) name + "\n" else "") + mail)
            .setPositiveButton("تسجيل خروج") { _, _ ->
                FirebaseAuth.getInstance().signOut()
                AuthState.notifyChanged(this)
                toast("تم تسجيل الخروج")
                finish()
            }
            .setNegativeButton("إغلاق") { _, _ -> finish() }
            .setOnCancelListener { finish() }
            .show()
    }

    private fun startSignIn() {
        val webId = try {
            getString(R.string.default_web_client_id)
        } catch (e: Exception) {
            toast("ملف google-services.json ناقص الـ Web client")
            finish()
            return
        }
        val option = GetSignInWithGoogleOption.Builder(webId).build()
        val request = GetCredentialRequest.Builder().addCredentialOption(option).build()
        val cm = CredentialManager.create(this)
        cm.getCredentialAsync(
            this, request, signal, mainExecutor,
            object : androidx.credentials.CredentialManagerCallback<GetCredentialResponse, GetCredentialException> {
                override fun onResult(result: GetCredentialResponse) {
                    handle(result)
                }

                override fun onError(e: GetCredentialException) {
                    toast("تسجيل الدخول لم يكتمل: " + (e.message ?: e.type))
                    finish()
                }
            }
        )
    }

    private fun handle(result: GetCredentialResponse) {
        val c = result.credential
        if (c is CustomCredential &&
            c.type == GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL
        ) {
            try {
                val g = GoogleIdTokenCredential.createFrom(c.data)
                val fc = GoogleAuthProvider.getCredential(g.idToken, null)
                FirebaseAuth.getInstance().signInWithCredential(fc)
                    .addOnCompleteListener(this) { t ->
                        if (t.isSuccessful) {
                            AuthState.notifyChanged(this)
                            toast("أهلاً " + (FirebaseAuth.getInstance().currentUser?.displayName ?: ""))
                        } else {
                            toast("Firebase رفض الدخول: " + (t.exception?.message ?: ""))
                        }
                        finish()
                    }
            } catch (e: Exception) {
                toast("خطأ: " + (e.message ?: ""))
                finish()
            }
        } else {
            toast("نوع حساب غير مدعوم")
            finish()
        }
    }

    private fun toast(m: String) {
        Toast.makeText(applicationContext, m, Toast.LENGTH_LONG).show()
    }

    override fun onDestroy() {
        signal.cancel()
        super.onDestroy()
    }
}
