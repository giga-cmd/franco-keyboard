package com.franco.keyboard

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.SweepGradient
import android.os.SystemClock
import android.view.View
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

// إضاءة RGB: إطار ملوّن حوالين الكيبورد، وتأثير مكان الضغطة
// الـ View ده مبياخدش اللمس (اللمس بيعدّي للكيبورد)
class RgbView(c: Context) : View(c) {
    var border = false
    var press = false
    var borderStyle = 0
    var pressStyle = 0

    private class Pulse(val x: Float, val y: Float, val t0: Long, val hue: Float)

    private val pulses = ArrayList<Pulse>()
    private var counter = 0
    private val d = resources.displayMetrics.density
    private val strokeP = Paint(Paint.ANTI_ALIAS_FLAG)
    private val fillP = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()
    private val mtx = Matrix()
    private var rainbow: SweepGradient? = null
    private var comet: SweepGradient? = null
    private var neon: SweepGradient? = null
    private var sw = 0
    private var sh = 0
    private val hsv = FloatArray(3)

    init {
        strokeP.style = Paint.Style.STROKE
        fillP.style = Paint.Style.FILL
    }

    fun pulse(rawX: Float, rawY: Float) {
        if (!press || rawX < 0f) return
        val loc = IntArray(2)
        getLocationOnScreen(loc)
        val now = SystemClock.uptimeMillis()
        counter++
        val hue = ((now / 6L) % 360L).toFloat() + counter * 37f
        pulses.add(Pulse(rawX - loc[0], rawY - loc[1], now, hue % 360f))
        if (pulses.size > 12) pulses.removeAt(0)
        postInvalidateOnAnimation()
    }

    private fun hueColor(h: Float, a: Int): Int {
        hsv[0] = ((h % 360f) + 360f) % 360f
        hsv[1] = 1f
        hsv[2] = 1f
        return Color.HSVToColor(a, hsv)
    }

    private fun buildShaders() {
        val cx = width / 2f
        val cy = height / 2f
        val cols = IntArray(8) { Color.HSVToColor(floatArrayOf(it * 45f, 1f, 1f)) }
        cols[7] = cols[0]
        rainbow = SweepGradient(cx, cy, cols, FloatArray(8) { it / 7f })
        comet = SweepGradient(
            cx, cy,
            intArrayOf(0x0000E5FF, 0x0000E5FF, 0x8800E5FF.toInt(), 0xFFFF2BD6.toInt(), 0xFFFFFFFF.toInt()),
            floatArrayOf(0f, 0.55f, 0.8f, 0.96f, 1f)
        )
        neon = SweepGradient(
            cx, cy,
            intArrayOf(0xFF00E5FF.toInt(), 0xFFFF2BD6.toInt(), 0xFF7C4DFF.toInt(), 0xFF00E5FF.toInt()),
            floatArrayOf(0f, 0.4f, 0.75f, 1f)
        )
    }

    private fun drawBorder(canvas: Canvas, sh0: Shader?, color: Int, a1: Int, a2: Int, w1: Float, w2: Float) {
        val r = 14f * d
        if (sh0 != null) strokeP.shader = sh0 else {
            strokeP.shader = null
            strokeP.color = color
        }
        rect.set(0f, 0f, width.toFloat(), height.toFloat())
        rect.inset(w1 / 2f, w1 / 2f)
        strokeP.alpha = a1
        strokeP.strokeWidth = w1
        canvas.drawRoundRect(rect, r, r, strokeP)
        rect.set(0f, 0f, width.toFloat(), height.toFloat())
        rect.inset(w1 / 2f + (w1 - w2) / 2f, w1 / 2f + (w1 - w2) / 2f)
        strokeP.alpha = a2
        strokeP.strokeWidth = w2
        canvas.drawRoundRect(rect, r, r, strokeP)
        strokeP.shader = null
    }

    override fun onDraw(canvas: Canvas) {
        val now = SystemClock.uptimeMillis()
        var again = false
        if (border && width > 0 && height > 0) {
            if (rainbow == null || sw != width || sh != height) {
                sw = width
                sh = height
                buildShaders()
            }
            val cx = width / 2f
            val cy = height / 2f
            when (borderStyle) {
                1 -> {
                    // تنفّس: لون واحد بيتغيّر ويلمع بالراحة
                    val k = (sin(now / 2000.0 * 2 * PI) * 0.5 + 0.5).toFloat()
                    val col = hueColor((now / 25L % 360L).toFloat(), 255)
                    drawBorder(canvas, null, col, (40 + 70 * k).toInt(), (120 + 135 * k).toInt(), 7f * d, 2.5f * d)
                }
                2 -> {
                    mtx.setRotate((now % 1800L) / 1800f * 360f, cx, cy)
                    comet?.setLocalMatrix(mtx)
                    drawBorder(canvas, comet, 0, 150, 255, 7f * d, 3f * d)
                }
                3 -> {
                    mtx.setRotate((now % 7000L) / 7000f * 360f, cx, cy)
                    neon?.setLocalMatrix(mtx)
                    val k = (sin(now / 1500.0 * 2 * PI) * 0.5 + 0.5).toFloat()
                    drawBorder(canvas, neon, 0, (60 + 60 * k).toInt(), (190 + 65 * k).toInt(), 8f * d, 2.5f * d)
                }
                else -> {
                    mtx.setRotate((now % 3000L) / 3000f * 360f, cx, cy)
                    rainbow?.setLocalMatrix(mtx)
                    drawBorder(canvas, rainbow, 0, 70, 255, 7f * d, 2.5f * d)
                }
            }
            again = true
        }
        if (pulses.isNotEmpty()) {
            val dur = if (pressStyle == 1) 650f else 520f
            val itr = pulses.iterator()
            while (itr.hasNext()) {
                val p = itr.next()
                val t = (now - p.t0) / dur
                if (t >= 1f) {
                    itr.remove()
                    continue
                }
                val a = ((1f - t) * 255).toInt()
                when (pressStyle) {
                    1 -> {
                        // شرارات
                        val dist = (8f + 58f * t) * d
                        val rad = (3.5f * (1f - t) + 0.8f) * d
                        for (k in 0 until 10) {
                            val ang = (k * 36.0 + p.hue) * PI / 180.0
                            fillP.shader = null
                            fillP.color = hueColor(p.hue + k * 36f, a)
                            canvas.drawCircle(
                                p.x + (cos(ang) * dist).toFloat(),
                                p.y + (sin(ang) * dist).toFloat(), rad, fillP
                            )
                        }
                    }
                    2 -> {
                        // توهج ناعم
                        val rad = (26f + 40f * t) * d
                        fillP.shader = RadialGradient(
                            p.x, p.y, rad,
                            hueColor(p.hue, (a * 0.9f).toInt()), hueColor(p.hue, 0), Shader.TileMode.CLAMP
                        )
                        canvas.drawCircle(p.x, p.y, rad, fillP)
                        fillP.shader = null
                    }
                    else -> {
                        // موجة
                        val rad = (10f + 62f * t) * d
                        fillP.shader = null
                        fillP.color = hueColor(p.hue, (a * 0.28f).toInt())
                        canvas.drawCircle(p.x, p.y, rad, fillP)
                        strokeP.shader = null
                        strokeP.strokeWidth = 3f * d
                        strokeP.color = hueColor(p.hue + t * 60f, a)
                        canvas.drawCircle(p.x, p.y, rad, strokeP)
                    }
                }
                again = true
            }
        }
        if (again) postInvalidateOnAnimation()
    }

    fun applyState(b: Boolean, p: Boolean, bs: Int, ps: Int) {
        border = b
        press = p
        borderStyle = bs
        pressStyle = ps
        if (!p) pulses.clear()
        visibility = if (b || p) VISIBLE else GONE
        invalidate()
    }
}
