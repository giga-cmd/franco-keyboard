package com.franco.keyboard

import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.ExifInterface
import android.os.Bundle
import android.widget.Toast
import java.io.File
import java.io.FileOutputStream

// شاشة شفافة: بتخلي المستخدم يختار صورة من المعرض وتبعتها للكيبورد (وضع الـ AI)
class AiPickActivity : Activity() {

    companion object {
        const val ACTION = "com.franco.keyboard.AI_IMAGE"
        const val FILE = "ai_pick.jpg"
        private const val REQ = 41
        private const val MAX_SIDE = 1280
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        try {
            val i = Intent(Intent.ACTION_GET_CONTENT)
            i.type = "image/*"
            i.addCategory(Intent.CATEGORY_OPENABLE)
            startActivityForResult(Intent.createChooser(i, "اختار صورة"), REQ)
        } catch (e: Exception) {
            Toast.makeText(applicationContext, "مفيش تطبيق معرض صور", Toast.LENGTH_SHORT).show()
            finish()
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        val uri = data?.data
        if (requestCode != REQ || resultCode != RESULT_OK || uri == null) {
            finish()
            return
        }
        Thread {
            var ok = false
            try {
                val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
                var sample = 1
                while (bounds.outWidth / sample > MAX_SIDE * 2 || bounds.outHeight / sample > MAX_SIDE * 2) sample *= 2
                val opts = BitmapFactory.Options().apply { inSampleSize = sample }
                var bmp = contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
                if (bmp != null) {
                    val rot = try {
                        contentResolver.openInputStream(uri)?.use {
                            when (ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, 1)) {
                                ExifInterface.ORIENTATION_ROTATE_90 -> 90f
                                ExifInterface.ORIENTATION_ROTATE_180 -> 180f
                                ExifInterface.ORIENTATION_ROTATE_270 -> 270f
                                else -> 0f
                            }
                        } ?: 0f
                    } catch (e: Exception) {
                        0f
                    }
                    val scale = MAX_SIDE.toFloat() / maxOf(bmp.width, bmp.height)
                    val m = Matrix()
                    if (scale < 1f) m.postScale(scale, scale)
                    if (rot != 0f) m.postRotate(rot)
                    if (!m.isIdentity) {
                        bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
                    }
                    FileOutputStream(File(cacheDir, FILE)).use { bmp!!.compress(Bitmap.CompressFormat.JPEG, 85, it) }
                    ok = true
                }
            } catch (e: Exception) {
                ok = false
            }
            runOnUiThread {
                if (ok) {
                    sendBroadcast(Intent(ACTION).setPackage(packageName))
                } else {
                    Toast.makeText(applicationContext, "مقدرتش أقرا الصورة", Toast.LENGTH_SHORT).show()
                }
                finish()
            }
        }.start()
    }
}
