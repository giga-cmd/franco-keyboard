package com.franco.keyboard

import android.content.Context
import com.google.firebase.auth.FirebaseAuth

object AuthState {
    const val ACTION = "com.franco.keyboard.AUTH_CHANGED"

    fun user() = try {
        FirebaseAuth.getInstance().currentUser
    } catch (e: Exception) {
        null
    }

    fun label(): String {
        val u = user() ?: return "👤"
        val n = (u.displayName ?: u.email ?: "").trim()
        return if (n.isNotEmpty()) n.substring(0, 1).uppercase() else "✓"
    }

    fun notifyChanged(c: Context) {
        c.sendBroadcast(android.content.Intent(ACTION).setPackage(c.packageName))
    }
}
