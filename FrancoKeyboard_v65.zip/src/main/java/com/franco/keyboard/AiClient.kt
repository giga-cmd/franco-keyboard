package com.franco.keyboard

import android.content.Context
import android.graphics.Bitmap
import android.os.Handler
import android.os.Looper
import android.util.Base64
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.ByteArrayOutputStream
import java.io.IOException
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL

// محادثة بسيطة: بنحتفظ بالتاريخ ونبعته مع كل سؤال
class AiChat {
    val history = ArrayList<Pair<String, String>>() // (user|model, text)
}

class AiHttpException(val code: Int, val status: String, msg: String) : IOException(msg)

// الاتصال بـ Gemini مباشرة بمفتاح المستخدم نفسه (من الإعدادات).
// كل مستخدم بيستهلك من الحصة المجانية بتاعة مفتاحه، فمفيش تكلفة على صاحب التطبيق.
object AiClient {

    const val DEFAULT_MODEL = "gemini-3.8-flash"

    private const val SYSTEM =
        "إنت مساعد بحث جوه كيبورد موبايل. دوّر في جوجل لأي سؤال محتاج معلومة حديثة أو حقيقية " +
            "(أسعار، أخبار، نتايج، مواعيد، أماكن) وجاوب من نتايج البحث. رد بنفس لغة ولهجة المستخدم " +
            "(لو كتب مصري أو فرانكو رد بالمصري بحروف عربي). خليك مختصر ومباشر " +
            "(غالباً 2 إلى 5 جمل) إلا لو طلب تفصيل. لو بعت صورة حللها وجاوب على سؤاله عنها. " +
            "من غير عناوين ماركداون ولا جداول، ومن غير رموز زيادة، لأن الرد ممكن يتقرا بصوت عالي."

    private val main = Handler(Looper.getMainLooper())

    private fun prefs(c: Context) = c.getSharedPreferences("franco", Context.MODE_PRIVATE)

    fun key(c: Context): String = prefs(c).getString("gemini_key", "")?.trim().orEmpty()

    fun model(c: Context): String =
        prefs(c).getString("gemini_model", "")?.trim().orEmpty().ifEmpty { DEFAULT_MODEL }

    fun newChat(): AiChat = AiChat()

    private fun encode(img: Bitmap): String {
        val max = 1024
        val s = minOf(1f, max.toFloat() / maxOf(img.width, img.height))
        val b = if (s < 1f) Bitmap.createScaledBitmap(img, (img.width * s).toInt(), (img.height * s).toInt(), true) else img
        val out = ByteArrayOutputStream()
        b.compress(Bitmap.CompressFormat.JPEG, 80, out)
        return Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)
    }

    private fun textPart(t: String) = JSONObject().put("text", t)

    suspend fun ask(
        ctx: Context,
        chat: AiChat,
        question: String,
        img: Bitmap?,
        onPartial: (String) -> Unit
    ): String = withContext(Dispatchers.IO) {
        val apiKey = key(ctx)
        val model = model(ctx)

        val contents = JSONArray()
        for ((role, text) in chat.history.takeLast(12)) {
            contents.put(
                JSONObject().put("role", role).put("parts", JSONArray().put(textPart(text)))
            )
        }
        val parts = JSONArray()
        if (img != null) {
            parts.put(
                JSONObject().put(
                    "inlineData",
                    JSONObject().put("mimeType", "image/jpeg").put("data", encode(img))
                )
            )
        }
        parts.put(textPart(question))
        contents.put(JSONObject().put("role", "user").put("parts", parts))

        val body = JSONObject()
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(textPart(SYSTEM))))
            .put("contents", contents)
            .put("tools", JSONArray().put(JSONObject().put("google_search", JSONObject())))
            .toString()

        val url = URL("https://generativelanguage.googleapis.com/v1beta/models/$model:streamGenerateContent?alt=sse")
        val conn = url.openConnection() as HttpURLConnection
        try {
            conn.requestMethod = "POST"
            conn.connectTimeout = 15000
            conn.readTimeout = 60000
            conn.doOutput = true
            conn.setRequestProperty("Content-Type", "application/json; charset=utf-8")
            conn.setRequestProperty("x-goog-api-key", apiKey)
            conn.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }

            val code = conn.responseCode
            if (code != 200) {
                val err = try {
                    conn.errorStream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
                } catch (e: Exception) {
                    ""
                }
                var status = ""
                var msg = err.take(300)
                try {
                    val eo = JSONObject(err).optJSONObject("error")
                    if (eo != null) {
                        status = eo.optString("status")
                        msg = eo.optString("message", msg)
                    }
                } catch (e: Exception) {
                }
                throw AiHttpException(code, status, msg)
            }

            val sb = StringBuilder()
            val sources = LinkedHashSet<String>()
            var blocked = ""
            BufferedReader(InputStreamReader(conn.inputStream, Charsets.UTF_8)).use { r ->
                while (true) {
                    ensureActive()
                    val line = r.readLine() ?: break
                    if (!line.startsWith("data:")) continue
                    val js = line.substring(5).trim()
                    if (js.isEmpty()) continue
                    val o = try { JSONObject(js) } catch (e: Exception) { continue }
                    val br = o.optJSONObject("promptFeedback")?.optString("blockReason").orEmpty()
                    if (br.isNotEmpty()) blocked = br
                    val cands = o.optJSONArray("candidates") ?: continue
                    val gch = cands.optJSONObject(0)?.optJSONObject("groundingMetadata")?.optJSONArray("groundingChunks")
                    if (gch != null) {
                        for (i in 0 until gch.length()) {
                            val t = gch.optJSONObject(i)?.optJSONObject("web")?.optString("title").orEmpty()
                            if (t.isNotEmpty() && sources.size < 3) sources.add(t)
                        }
                    }
                    val ps = cands.optJSONObject(0)?.optJSONObject("content")?.optJSONArray("parts") ?: continue
                    var added = false
                    for (i in 0 until ps.length()) {
                        val t = ps.optJSONObject(i)?.optString("text").orEmpty()
                        if (t.isNotEmpty()) { sb.append(t); added = true }
                    }
                    if (added) {
                        val snap = sb.toString()
                        main.post { onPartial(snap) }
                    }
                }
            }
            if (sb.isEmpty() && blocked.isNotEmpty()) {
                throw AiHttpException(0, "BLOCKED", "الرد اتحجب لأسباب الأمان، جرب صياغة تانية")
            }
            val text = sb.toString().trim()
            if (sources.isNotEmpty() && text.isNotEmpty()) {
                val withSrc = text + "\n\n🔎 " + sources.joinToString(" • ")
                main.post { onPartial(withSrc) }
            }
            chat.history.add("user" to question)
            chat.history.add("model" to text)
            text
        } finally {
            conn.disconnect()
        }
    }

    fun friendlyError(e: Throwable): String {
        if (e is CancellationException) return "اتلغى"
        if (e is AiHttpException) {
            val l = (e.status + " " + (e.message ?: "")).lowercase()
            return when {
                e.status == "BLOCKED" -> e.message ?: "الرد اتحجب"
                l.contains("api key not valid") || l.contains("api_key_invalid") || l.contains("api key expired") ->
                    "المفتاح غلط أو منتهي. راجعه في إعدادات الكيبورد ← بيانات"
                e.code == 429 || l.contains("resource_exhausted") || l.contains("quota") ->
                    "خلصت الحصة المجانية بتاعة مفتاحك. استنى شوية وجرب تاني، أو غيّر الموديل من الإعدادات"
                e.code == 403 || l.contains("permission_denied") ->
                    "المفتاح مش مسموح له يستخدم الموديل ده. اعمل مفتاح جديد من aistudio.google.com/apikey"
                e.code == 404 || l.contains("no longer available") || l.contains("not found") ->
                    "الموديل مش متاح. غيّره من الإعدادات. التفاصيل: " + (e.message ?: "").take(160)
                e.code in 500..599 -> "سيرفر جوجل مشغول، جرب تاني بعد شوية"
                else -> ("(" + e.code + ") " + (e.message ?: "")).take(300)
            }
        }
        val m = (e.message ?: e.javaClass.simpleName)
        val l = m.lowercase()
        return when {
            e is IOException || l.contains("unable to resolve") || l.contains("timeout") ->
                "مفيش إنترنت أو الاتصال ضعيف"
            else -> m.take(300)
        }
    }
}
