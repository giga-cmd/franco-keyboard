package com.franco.keyboard

import android.app.Application
import android.content.pm.ApplicationInfo
import com.google.firebase.FirebaseApp
import com.google.firebase.appcheck.FirebaseAppCheck
import com.google.firebase.appcheck.debug.DebugAppCheckProviderFactory
import com.google.firebase.appcheck.playintegrity.PlayIntegrityAppCheckProviderFactory

// بيشغّل App Check: بيثبت إن الطلبات جاية من تطبيقك فعلاً (شرط Firebase AI Logic)
class FrancoApp : Application() {
    override fun onCreate() {
        super.onCreate()
        try {
            FirebaseApp.initializeApp(this)
            val debuggable = (applicationInfo.flags and ApplicationInfo.FLAG_DEBUGGABLE) != 0
            val fromPlay = try {
                @Suppress("DEPRECATION")
                packageManager.getInstallerPackageName(packageName) == "com.android.vending"
            } catch (e: Exception) {
                false
            }
            val factory = if (debuggable || !fromPlay) {
                DebugAppCheckProviderFactory.getInstance()
            } else {
                PlayIntegrityAppCheckProviderFactory.getInstance()
            }
            FirebaseAppCheck.getInstance().installAppCheckProviderFactory(factory)
        } catch (e: Exception) {
            // مش مهم: الكيبورد يفضل شغال حتى لو الـ AI مش جاهز
        }
    }
}
