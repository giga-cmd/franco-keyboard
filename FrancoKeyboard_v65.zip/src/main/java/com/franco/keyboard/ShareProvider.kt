package com.franco.keyboard

import android.content.ContentProvider
import android.content.ContentValues
import android.database.Cursor
import android.database.MatrixCursor
import android.net.Uri
import android.os.ParcelFileDescriptor
import android.provider.OpenableColumns
import java.io.File
import java.io.FileNotFoundException

// بيدّي التطبيقات الصورة اللي الكيبورد عملها (النص كصورة) من مجلد مؤقت
class ShareProvider : ContentProvider() {
    companion object {
        const val AUTH = "com.franco.keyboard.share"
    }

    private fun fileFor(uri: Uri): File? {
        val name = uri.lastPathSegment ?: return null
        if (name.contains("/") || name.contains("..")) return null
        val c = context ?: return null
        val f = File(File(c.cacheDir, "share"), name)
        return if (f.exists()) f else null
    }

    override fun onCreate(): Boolean = true

    override fun getType(uri: Uri): String = "image/png"

    override fun openFile(uri: Uri, mode: String): ParcelFileDescriptor? {
        val f = fileFor(uri) ?: throw FileNotFoundException()
        return ParcelFileDescriptor.open(f, ParcelFileDescriptor.MODE_READ_ONLY)
    }

    override fun query(
        uri: Uri, projection: Array<out String>?, selection: String?,
        selectionArgs: Array<out String>?, sortOrder: String?
    ): Cursor? {
        val f = fileFor(uri) ?: return null
        val cols: Array<String> = if (projection == null) arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE)
        else Array(projection.size) { projection[it] }
        val cur = MatrixCursor(cols)
        val row = arrayOfNulls<Any>(cols.size)
        for ((i, c) in cols.withIndex()) {
            row[i] = when (c) {
                OpenableColumns.DISPLAY_NAME -> f.name
                OpenableColumns.SIZE -> f.length()
                else -> null
            }
        }
        cur.addRow(row)
        return cur
    }

    override fun insert(uri: Uri, values: ContentValues?): Uri? = null
    override fun delete(uri: Uri, selection: String?, selectionArgs: Array<out String>?): Int = 0
    override fun update(uri: Uri, values: ContentValues?, selection: String?, selectionArgs: Array<out String>?): Int = 0
}
