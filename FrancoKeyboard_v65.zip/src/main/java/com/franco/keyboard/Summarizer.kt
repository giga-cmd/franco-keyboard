package com.franco.keyboard

import kotlin.math.ceil
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow

// تلخيص من غير نت: بيختار أهم الجمل ويربطهم بكلمات ربط بسيطة
object Summarizer {

    private val stopAr = hashSetOf(
        "في", "من", "على", "علي", "الى", "إلى", "عن", "مع", "هذا", "هذه", "هذي", "ذلك", "تلك", "هو", "هي", "هم",
        "انا", "انت", "نحن", "كان", "كانت", "يكون", "التي", "الذي", "الذين", "ان", "أن", "إن", "او", "أو", "ثم",
        "قد", "لا", "ما", "لم", "لن", "كل", "بعد", "قبل", "حتى", "عند", "اللي", "ده", "دي", "دا", "بس", "كمان",
        "فى", "ايه", "إيه", "لما", "لو", "يا", "هل", "كده", "كدا", "ليه", "عشان", "علشان", "برضه", "بعض", "غير",
        "the", "and", "for", "with", "that", "this", "are", "was", "you", "your", "have", "has", "not", "but",
        "from", "they", "will", "can", "all", "its", "their", "which", "would", "there", "been", "were"
    )

    private val startsLinked = listOf(
        "لكن", "ولكن", "بس", "لذلك", "علشان", "عشان", "كمان", "وكمان", "ثم", "وبعد", "وبعدين", "بعدين", "ايضا", "أيضا",
        "however", "but", "also", "then", "so", "and", "because"
    )

    private fun isAr(c: Char) = c in 'ء'..'ي'

    private fun norm(w: String): String {
        var x = w.lowercase()
        x = x.replace(Regex("[ً-ْـ]"), "")
        x = x.replace('أ', 'ا').replace('إ', 'ا').replace('آ', 'ا').replace('ى', 'ي').replace('ة', 'ه')
        if (x.length > 4 && x.startsWith("ال")) x = x.substring(2)
        return x
    }

    private fun words(s: String): List<String> {
        val out = ArrayList<String>()
        for (m in Regex("[ء-يA-Za-z]+").findAll(s)) {
            val n = norm(m.value)
            if (n.length >= 3 && !stopAr.contains(n)) out.add(n)
        }
        return out
    }

    private fun splitSentences(t: String): List<String> {
        val res = ArrayList<String>()
        val sb = StringBuilder()
        for (ch in t) {
            if (ch == '.' || ch == '!' || ch == '?' || ch == '؟' || ch == '…' || ch == '\n') {
                val s = sb.toString().trim()
                if (s.length >= 12) res.add(s)
                sb.setLength(0)
            } else {
                sb.append(ch)
            }
        }
        val last = sb.toString().trim()
        if (last.length >= 12) res.add(last)
        return res
    }

    // بيرجّع null لو النص قصير
    fun summarize(text: String): String? {
        val t = text.trim()
        if (t.length < 150) return null
        val sents = splitSentences(t)
        if (sents.size < 3) return null
        var arN = 0
        var letters = 0
        for (c in t) {
            if (c.isLetter()) letters++
            if (isAr(c)) arN++
        }
        val ar = letters > 0 && arN * 2 >= letters

        val freq = HashMap<String, Int>()
        val sw = sents.map { words(it) }
        for (ws in sw) for (w in ws) freq[w] = (freq[w] ?: 0) + 1
        val scores = DoubleArray(sents.size)
        for (i in sents.indices) {
            val ws = sw[i]
            if (ws.isEmpty()) continue
            var sc = 0.0
            for (w in ws.distinct()) {
                val f = freq[w] ?: 0
                if (f > 1) sc += f.toDouble()
            }
            sc /= ws.size.toDouble().pow(0.6)
            if (i == 0) sc *= 1.35
            if (i == sents.size - 1) sc *= 1.1
            if (sents[i].length > 260) sc *= 0.7
            scores[i] = sc
        }
        val k = max(2, min(6, ceil(sents.size * 0.3).toInt()))
        val picked = sents.indices.sortedByDescending { scores[it] }.take(k).sorted()

        val ar2 = arrayOf("كمان", "وبعد كده", "ومن ناحية تانية", "وكمان", "وفوق ده")
        val en2 = arrayOf("Also,", "Then,", "On top of that,", "Additionally,", "Moreover,")
        val sb = StringBuilder()
        for ((idx, i) in picked.withIndex()) {
            var s = sents[i].trim().trimEnd(',', '،', ';', '؛', ':')
            if (idx > 0) {
                val lower = s.lowercase()
                val linked = startsLinked.any { lower == it || lower.startsWith("$it ") }
                val isLast = idx == picked.size - 1
                if (!linked) {
                    val adjacent = i - picked[idx - 1] == 1
                    val c = when {
                        isLast && picked.size > 2 -> if (ar) "وفي الآخر" else "Finally,"
                        adjacent -> if (ar) "و" else "And"
                        else -> if (ar) ar2[(idx - 1) % ar2.size] else en2[(idx - 1) % en2.size]
                    }
                    s = if (c == "و") "و$s" else "$c $s"
                }
            }
            if (sb.isNotEmpty()) sb.append(" ")
            sb.append(s).append(if (ar) "." else ".")
        }
        val out = sb.toString()
        return if (out.length >= t.length * 0.9) null else out
    }
}
