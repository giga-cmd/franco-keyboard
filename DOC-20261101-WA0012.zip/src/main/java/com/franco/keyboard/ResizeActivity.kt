package com.franco.keyboard

import android.app.Activity
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView

// شاشة بسيطة فيها خانة كتابة عشان الكيبورد يظهر ويدخل في وضع تغيير الحجم
class ResizeActivity : Activity() {

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        getSharedPreferences("franco", MODE_PRIVATE)
            .edit().putBoolean("resize_pending", true).apply()
        window.setSoftInputMode(
            WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE or
                WindowManager.LayoutParams.SOFT_INPUT_ADJUST_NOTHING
        )
        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.BLACK
        window.decorView.systemUiVisibility =
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN

        val root = FrameLayout(this)
        val bg = ImageView(this)
        bg.setImageResource(R.drawable.bg)
        bg.scaleType = ImageView.ScaleType.CENTER_CROP
        root.addView(bg, FrameLayout.LayoutParams(-1, -1))
        val sc = View(this)
        sc.setBackgroundColor(Color.parseColor("#99000000"))
        root.addView(sc, FrameLayout.LayoutParams(-1, -1))

        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(24), dp(56), dp(24), dp(24))

        val title = TextView(this)
        title.text = "تغيير حجم الكيبورد"
        title.setTextColor(Color.WHITE)
        title.textSize = 24f
        title.gravity = Gravity.CENTER
        title.setPadding(0, 0, 0, dp(12))
        col.addView(title)

        val info = TextView(this)
        info.text = "الكيبورد هيظهر بإطار أزرق.\n" +
            "• اسحب المقبض اللي فوق لتغيير الارتفاع.\n" +
            "• اسحب مقبض الشمال أو اليمين لتغيير العرض.\n" +
            "• اسحب علامة ✥ في النص لتحريكه يمين أو شمال.\n" +
            "• دوس تم لما تخلص، أو إعادة ضبط للرجوع للحجم الأصلي."
        info.setTextColor(Color.WHITE)
        info.textSize = 15f
        info.setLineSpacing(0f, 1.25f)
        info.setPadding(0, 0, 0, dp(16))
        col.addView(info)

        val edit = EditText(this)
        edit.hint = "اضغط هنا لو الكيبورد ماظهرش"
        edit.setTextColor(Color.WHITE)
        edit.setHintTextColor(Color.parseColor("#99FFFFFF"))
        val g = GradientDrawable()
        g.cornerRadius = dp(16).toFloat()
        g.setColor(Color.parseColor("#55000000"))
        g.setStroke(dp(1), Color.parseColor("#80FFFFFF"))
        edit.background = g
        edit.setPadding(dp(16), dp(12), dp(16), dp(12))
        col.addView(
            edit,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(56))
        )

        val back = TextView(this)
        back.text = "رجوع"
        back.setTextColor(Color.WHITE)
        back.textSize = 17f
        back.gravity = Gravity.CENTER
        val bgd = GradientDrawable()
        bgd.cornerRadius = dp(28).toFloat()
        bgd.setColor(Color.parseColor("#B33F51B5"))
        bgd.setStroke(dp(1), Color.parseColor("#80FFFFFF"))
        back.background = bgd
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(52))
        lp.setMargins(0, dp(16), 0, 0)
        back.layoutParams = lp
        back.setOnClickListener { finish() }
        col.addView(back)

        root.addView(col, FrameLayout.LayoutParams(-1, -2, Gravity.TOP))
        setContentView(root)
        edit.requestFocus()
    }
}
