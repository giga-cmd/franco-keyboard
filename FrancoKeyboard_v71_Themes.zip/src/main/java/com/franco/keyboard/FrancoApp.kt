package com.franco.keyboard

import android.app.Application
import com.google.firebase.FirebaseApp

// Firebase مستخدم لتسجيل الدخول بجوجل بس
class FrancoApp : Application() {
    override fun onCreate() {
        super.onCreate()
        try {
            FirebaseApp.initializeApp(this)
        } catch (e: Exception) {
            // مش مهم: الكيبورد يفضل شغال
        }
    }
}
