package com.franco.keyboard

import android.content.Context
import com.google.firebase.auth.FirebaseAuth

object AuthState {
    const val ACTION = "com.franco.keyboard.AUTH_CHANGED"

    fun user() = try {
        FirebaseAuth.getInstance().currentUser
    } catch (e: Exception) {
        null
    }

    fun label(): String {
        val u = user() ?: return "👤"
        val n = (u.displayName ?: u.email ?: "").trim()
        return if (n.isNotEmpty()) n.substring(0, 1).uppercase() else "✓"
    }

    // صورة حساب جوجل (دايرة). بتتحمّل مرة وبتتخزّن، والـ cb بيتنده على الـ UI thread
    fun loadAvatar(c: Context, sizePx: Int, cb: (android.graphics.Bitmap?) -> Unit) {
        val u = user()
        val url = u?.photoUrl?.toString()
        if (u == null || url == null) {
            cb(null)
            return
        }
        val app = c.applicationContext
        val file = java.io.File(app.filesDir, "avatar_" + u.uid + ".png")
        val main = android.os.Handler(android.os.Looper.getMainLooper())
        Thread {
            var bmp: android.graphics.Bitmap? = null
            try {
                if (file.exists()) {
                    bmp = android.graphics.BitmapFactory.decodeFile(file.absolutePath)
                }
                if (bmp == null) {
                    val big = url.replace(Regex("=s\\d+(-c)?$"), "") + "=s256-c"
                    val con = java.net.URL(big).openConnection() as java.net.HttpURLConnection
                    con.connectTimeout = 8000
                    con.readTimeout = 8000
                    con.inputStream.use { ins ->
                        val data = ins.readBytes()
                        file.writeBytes(data)
                        bmp = android.graphics.BitmapFactory.decodeByteArray(data, 0, data.size)
                    }
                }
            } catch (e: Exception) {
                bmp = null
            }
            val src = bmp
            val out = if (src != null) circle(src, sizePx) else null
            main.post { cb(out) }
        }.start()
    }

    private fun circle(src: android.graphics.Bitmap, size: Int): android.graphics.Bitmap {
        val out = android.graphics.Bitmap.createBitmap(size, size, android.graphics.Bitmap.Config.ARGB_8888)
        val cv = android.graphics.Canvas(out)
        val p = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG)
        val scaled = android.graphics.Bitmap.createScaledBitmap(src, size, size, true)
        p.shader = android.graphics.BitmapShader(
            scaled, android.graphics.Shader.TileMode.CLAMP, android.graphics.Shader.TileMode.CLAMP
        )
        cv.drawCircle(size / 2f, size / 2f, size / 2f, p)
        return out
    }

    fun notifyChanged(c: Context) {
        c.sendBroadcast(android.content.Intent(ACTION).setPackage(c.packageName))
    }
}
