package com.franco.keyboard

import android.content.Context
import android.content.SharedPreferences
import com.google.firebase.firestore.FirebaseFirestore
import org.json.JSONObject

// مزامنة الحساب: النسخ الاحتياطي التلقائي + ثيمات الحساب + كود مشاركة الثيم
object CloudSync {
    private const val WEEK = 7L * 24 * 3600 * 1000

    // مفاتيح الشكل (من غير الصور والخطوط لأنها ملفات على الموبايل)
    val APPEARANCE = listOf(
        "theme", "bg_dim", "key_alpha", "key_text", "key_box", "key_box_size", "hints",
        "txt_color", "txt_custom", "txt_hue", "txt_sat", "txt_val", "font_weight",
        "rgb_border", "rgb_press", "rgb_style", "rgb_press_style", "snd_style",
        "theme_auto", "app_theme_on"
    )

    // مفاتيح مش بتتنسخ مع النسخة الاحتياطية
    val SKIP = setOf(
        "uni", "bi", "pins", "clips", "clip_ignored", "shot_asked", "device_id",
        "stat_words", "stat_chars", "last_backup", "auto_backup", "bg_type"
    )

    fun toJson(sp: SharedPreferences, only: Collection<String>?): JSONObject {
        val j = JSONObject()
        for ((k, v) in sp.all) {
            if (v == null) continue
            if (only != null) {
                if (k !in only) continue
            } else if (k in SKIP) continue
            val o = JSONObject()
            when (v) {
                is Boolean -> o.put("t", "b").put("v", v)
                is Int -> o.put("t", "i").put("v", v)
                is Long -> o.put("t", "l").put("v", v)
                is Float -> o.put("t", "f").put("v", v.toDouble())
                is String -> o.put("t", "s").put("v", v)
                else -> continue
            }
            j.put(k, o)
        }
        return j
    }

    // بيرجّع عدد الإعدادات اللي اتطبّقت
    fun applyJson(sp: SharedPreferences, s: String, only: Collection<String>?): Int {
        val j = JSONObject(s)
        val e = sp.edit()
        var n = 0
        for (k in j.keys()) {
            if (k in SKIP) continue
            if (only != null && k !in only) continue
            val o = j.getJSONObject(k)
            when (o.getString("t")) {
                "b" -> e.putBoolean(k, o.getBoolean("v"))
                "i" -> e.putInt(k, o.getInt("v"))
                "l" -> e.putLong(k, o.getLong("v"))
                "f" -> e.putFloat(k, o.getDouble("v").toFloat())
                "s" -> e.putString(k, o.getString("v"))
                else -> continue
            }
            n++
        }
        e.apply()
        return n
    }

    private fun userDoc(name: String) = FirebaseFirestore.getInstance()
        .collection("users").document(AuthState.user()!!.uid).collection("data").document(name)

    fun backupNow(ctx: Context, cb: (Int, Exception?) -> Unit) {
        val sp = ctx.getSharedPreferences("franco", Context.MODE_PRIVATE)
        val j = toJson(sp, null)
        val m = hashMapOf<String, Any>("json" to j.toString(), "ts" to System.currentTimeMillis())
        userDoc("prefs").set(m)
            .addOnSuccessListener {
                sp.edit().putLong("last_backup", System.currentTimeMillis()).apply()
                cb(j.length(), null)
            }
            .addOnFailureListener { cb(0, it) }
    }

    // بيتنده من الكيبورد: لو مسجّل والنسخ التلقائي شغال وعدّى أسبوع، بيرفع نسخة
    fun autoBackupIfDue(ctx: Context) {
        try {
            if (AuthState.user() == null) return
            val sp = ctx.getSharedPreferences("franco", Context.MODE_PRIVATE)
            if (!sp.getBoolean("auto_backup", true)) return
            val last = sp.getLong("last_backup", 0L)
            val now = System.currentTimeMillis()
            if (now - last < WEEK) return
            // نأجّل المحاولة الجاية يوم لو فشلت (مفيش نت مثلاً)
            sp.edit().putLong("last_backup", now - WEEK + 24L * 3600 * 1000).apply()
            backupNow(ctx) { _, _ -> }
        } catch (e: Exception) {
            // مش مهم
        }
    }

    // ---- ثيمات الحساب ----

    fun saveTheme(ctx: Context, name: String, cb: (Exception?) -> Unit) {
        val sp = ctx.getSharedPreferences("franco", Context.MODE_PRIVATE)
        val m = hashMapOf<String, Any>(
            "name" to name,
            "json" to toJson(sp, APPEARANCE).toString(),
            "ts" to System.currentTimeMillis()
        )
        FirebaseFirestore.getInstance().collection("users").document(AuthState.user()!!.uid)
            .collection("themes").document(name).set(m)
            .addOnSuccessListener { cb(null) }
            .addOnFailureListener { cb(it) }
    }

    fun listThemes(cb: (List<Pair<String, String>>?, Exception?) -> Unit) {
        FirebaseFirestore.getInstance().collection("users").document(AuthState.user()!!.uid)
            .collection("themes").get()
            .addOnSuccessListener { qs ->
                val l = ArrayList<Pair<String, String>>()
                for (d in qs.documents) {
                    val n = d.getString("name") ?: d.id
                    val j = d.getString("json") ?: continue
                    l.add(Pair(n, j))
                }
                cb(l.sortedBy { it.first }, null)
            }
            .addOnFailureListener { cb(null, it) }
    }

    fun deleteTheme(name: String, cb: (Exception?) -> Unit) {
        FirebaseFirestore.getInstance().collection("users").document(AuthState.user()!!.uid)
            .collection("themes").document(name).delete()
            .addOnSuccessListener { cb(null) }
            .addOnFailureListener { cb(it) }
    }

    // ---- كود المشاركة ----

    private const val ALPHA = "ABCDEFGHJKMNPQRSTUVWXYZ23456789"

    fun shareCurrent(ctx: Context, cb: (String?, Exception?) -> Unit) {
        val sp = ctx.getSharedPreferences("franco", Context.MODE_PRIVATE)
        val rnd = java.security.SecureRandom()
        val code = (1..6).map { ALPHA[rnd.nextInt(ALPHA.length)] }.joinToString("")
        val m = hashMapOf<String, Any>(
            "json" to toJson(sp, APPEARANCE).toString(),
            "owner" to AuthState.user()!!.uid,
            "ts" to System.currentTimeMillis()
        )
        FirebaseFirestore.getInstance().collection("shared_themes").document(code).set(m)
            .addOnSuccessListener { cb(code, null) }
            .addOnFailureListener { cb(null, it) }
    }

    fun fetchShared(code: String, cb: (String?, Exception?) -> Unit) {
        FirebaseFirestore.getInstance().collection("shared_themes").document(code.trim().uppercase()).get()
            .addOnSuccessListener { cb(it.getString("json"), null) }
            .addOnFailureListener { cb(null, it) }
    }
}
