package com.franco.keyboard

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import com.google.firebase.firestore.FirebaseFirestore
import org.json.JSONObject
import java.util.UUID

// ميزات الحساب (لازم تسجيل دخول جوجل): نسخ احتياطي للإعدادات، مزامنة الكلمات والحافظة المثبتة، إحصائيات الكتابة
class AccountActivity : Activity() {

    private lateinit var info: TextView
    private lateinit var out: TextView
    private lateinit var col: LinearLayout

    private fun sp() = getSharedPreferences("franco", Context.MODE_PRIVATE)
    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    // مفاتيح مش بتتنسخ مع الإعدادات (بتتزامن لوحدها أو خاصة بالجهاز)
    private val skip = setOf("uni", "bi", "pins", "clips", "clip_ignored", "shot_asked", "device_id", "stat_words", "stat_chars")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.parseColor("#101018")
        window.navigationBarColor = Color.parseColor("#101018")
        val sv = ScrollView(this)
        sv.setBackgroundColor(Color.parseColor("#101018"))
        col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(20), dp(40), dp(20), dp(24))
        sv.addView(col)
        setContentView(sv)
        build()
    }

    override fun onResume() {
        super.onResume()
        build()
    }

    private fun text(t: String, size: Float, color: String = "#FFFFFF"): TextView {
        val v = TextView(this)
        v.text = t
        v.textSize = size
        v.setTextColor(Color.parseColor(color))
        v.textDirection = View.TEXT_DIRECTION_RTL
        v.setPadding(0, dp(6), 0, dp(6))
        return v
    }

    private fun button(t: String, sub: String, action: () -> Unit): LinearLayout {
        val b = LinearLayout(this)
        b.orientation = LinearLayout.VERTICAL
        val g = GradientDrawable()
        g.cornerRadius = dp(14).toFloat()
        g.setColor(Color.parseColor("#2A2A36"))
        b.background = g
        b.setPadding(dp(16), dp(12), dp(16), dp(12))
        val a = text(t, 17f)
        val c = text(sub, 13f, "#B0B0B8")
        b.addView(a)
        b.addView(c)
        val lp = LinearLayout.LayoutParams(-1, -2)
        lp.setMargins(0, dp(6), 0, dp(6))
        b.layoutParams = lp
        b.setOnClickListener { action() }
        return b
    }

    private fun build() {
        col.removeAllViews()
        val u = AuthState.user()
        col.addView(text("☁ حسابي", 24f))
        if (u == null) {
            col.addView(text("الميزات دي بتشتغل بعد تسجيل الدخول بجوجل بس:\n• نسخ احتياطي لإعداداتك واسترجاعها\n• مزامنة الكلمات اللي الكيبورد اتعلمها\n• حافظة مثبّتة على حسابك\n• إحصائيات الكتابة", 15f, "#D0D0D8"))
            col.addView(button("تسجيل الدخول بجوجل", "دوس هنا") {
                startActivity(Intent(this, AuthActivity::class.java))
            })
            return
        }
        col.addView(text((u.displayName ?: "") + "\n" + (u.email ?: ""), 15f, "#B0B0B8"))
        info = text("", 14f, "#8FE388")
        out = text("", 14f, "#D0D0D8")
        col.addView(info)
        col.addView(button("⬆ نسخ احتياطي للإعدادات", "يرفع إعداداتك وثيماتك على حسابك") { backupPrefs() })
        col.addView(button("⬇ استرجاع الإعدادات", "يجيب آخر نسخة من حسابك على الموبايل ده") { restorePrefs() })
        col.addView(button("🔄 مزامنة الكلمات والحافظة", "يدمج كلماتك المتعلّمة والنصوص المثبّتة مع حسابك وبين موبايلاتك") { syncWords() })
        col.addView(button("📊 إحصائيات الكتابة", "كام كلمة كتبت وأكتر كلماتك استخدامًا") { showStats() })
        col.addView(out)
        showStats()
    }

    private fun db(name: String) = FirebaseFirestore.getInstance()
        .collection("users").document(AuthState.user()!!.uid).collection("data").document(name)

    private fun say(t: String) {
        info.text = t
    }

    private fun fail(e: Exception?) {
        val m = e?.message ?: ""
        say("⚠ " + when {
            m.contains("PERMISSION_DENIED", true) -> "Firestore مش متفعّل أو القواعد (Rules) مش مظبوطة"
            m.contains("UNAVAILABLE", true) || m.contains("offline", true) -> "مفيش إنترنت"
            else -> m.take(120)
        })
    }

    private fun deviceId(): String {
        val p = sp()
        var d = p.getString("device_id", null)
        if (d == null) {
            d = UUID.randomUUID().toString().substring(0, 8)
            p.edit().putString("device_id", d).apply()
        }
        return d
    }

    // ---- الإعدادات ----

    private fun backupPrefs() {
        say("جاري الرفع…")
        val j = JSONObject()
        for ((k, v) in sp().all) {
            if (k in skip || v == null) continue
            val o = JSONObject()
            when (v) {
                is Boolean -> o.put("t", "b").put("v", v)
                is Int -> o.put("t", "i").put("v", v)
                is Long -> o.put("t", "l").put("v", v)
                is Float -> o.put("t", "f").put("v", v.toDouble())
                is String -> o.put("t", "s").put("v", v)
                else -> continue
            }
            j.put(k, o)
        }
        val m = hashMapOf<String, Any>("json" to j.toString(), "ts" to System.currentTimeMillis())
        db("prefs").set(m)
            .addOnSuccessListener { say("✅ اتعمل نسخ احتياطي (" + j.length() + " إعداد)") }
            .addOnFailureListener { fail(it) }
    }

    private fun restorePrefs() {
        say("جاري الاسترجاع…")
        db("prefs").get().addOnSuccessListener { d ->
            val s = d.getString("json")
            if (s == null) {
                say("مفيش نسخة محفوظة على الحساب ده")
                return@addOnSuccessListener
            }
            try {
                val j = JSONObject(s)
                val e = sp().edit()
                var n = 0
                for (k in j.keys()) {
                    if (k in skip) continue
                    val o = j.getJSONObject(k)
                    when (o.getString("t")) {
                        "b" -> e.putBoolean(k, o.getBoolean("v"))
                        "i" -> e.putInt(k, o.getInt("v"))
                        "l" -> e.putLong(k, o.getLong("v"))
                        "f" -> e.putFloat(k, o.getDouble("v").toFloat())
                        "s" -> e.putString(k, o.getString("v"))
                        else -> continue
                    }
                    n++
                }
                e.apply()
                AuthState.notifyChanged(this)
                say("✅ اتسترجع " + n + " إعداد. اقفل الكيبورد وافتحه عشان يتطبّق")
            } catch (ex: Exception) {
                say("⚠ النسخة تالفة")
            }
        }.addOnFailureListener { fail(it) }
    }

    // ---- الكلمات + الحافظة المثبتة ----

    private fun decode(str: String): HashMap<String, Int> {
        val m = HashMap<String, Int>()
        if (str.isEmpty()) return m
        for (p in str.split("\u0001")) {
            val i = p.lastIndexOf('\u0002')
            if (i > 0) m[p.substring(0, i)] = p.substring(i + 1).toIntOrNull() ?: continue
        }
        return m
    }

    private fun encode(m: Map<String, Int>): String {
        val sb = StringBuilder()
        for ((k, v) in m) {
            if (sb.isNotEmpty()) sb.append('\u0001')
            sb.append(k).append('\u0002').append(v)
        }
        return sb.toString()
    }

    private fun mergeMax(a: HashMap<String, Int>, b: Map<String, Int>, limit: Int) {
        for ((k, v) in b) {
            val o = a[k]
            if (o == null || v > o) a[k] = v
        }
        if (a.size > limit) {
            val top = a.entries.sortedByDescending { it.value }.take(limit)
            a.clear()
            for (e in top) a[e.key] = e.value
        }
    }

    private fun syncWords() {
        say("جاري المزامنة…")
        val p = sp()
        val uni = decode(p.getString("uni", "") ?: "")
        val bi = decode(p.getString("bi", "") ?: "")
        val pins = LinkedHashSet<String>()
        for (x in (p.getString("pins", "") ?: "").split("\u0001")) if (x.isNotEmpty()) pins.add(x)
        db("words").get().addOnSuccessListener { d ->
            mergeMax(uni, decode(d.getString("uni") ?: ""), 3000)
            mergeMax(bi, decode(d.getString("bi") ?: ""), 6000)
            db("pins").get().addOnSuccessListener { pd ->
                @Suppress("UNCHECKED_CAST")
                val remote = (pd.get("items") as? List<String>) ?: emptyList()
                for (x in remote) if (x.isNotEmpty()) pins.add(x)
                val pl = pins.toList().takeLast(100)
                p.edit()
                    .putString("uni", encode(uni))
                    .putString("bi", encode(bi))
                    .putString("pins", pl.joinToString("\u0001"))
                    .apply()
                val wm = hashMapOf<String, Any>("uni" to encode(uni), "bi" to encode(bi), "ts" to System.currentTimeMillis())
                db("words").set(wm).addOnSuccessListener {
                    db("pins").set(hashMapOf<String, Any>("items" to pl)).addOnSuccessListener {
                        AuthState.notifyChanged(this)
                        say("✅ اتزامنت " + uni.size + " كلمة و" + pl.size + " نص مثبّت")
                    }.addOnFailureListener { fail(it) }
                }.addOnFailureListener { fail(it) }
            }.addOnFailureListener { fail(it) }
        }.addOnFailureListener { fail(it) }
    }

    // ---- الإحصائيات ----

    private fun showStats() {
        val p = sp()
        val words = p.getLong("stat_words", 0L)
        val chars = p.getLong("stat_chars", 0L)
        val uni = decode(p.getString("uni", "") ?: "")
        val top = uni.entries.sortedByDescending { it.value }.take(10)
        val sb = StringBuilder()
        sb.append("📊 على الموبايل ده:\nكلمات اتكتبت: ").append(words).append("\nحروف: ").append(chars)
        sb.append("\nكلمات متعلّمة: ").append(uni.size)
        if (top.isNotEmpty()) {
            sb.append("\n\nأكتر كلماتك استخدامًا:")
            for ((i, e) in top.withIndex()) sb.append("\n").append(i + 1).append(". ").append(e.key).append("  (").append(e.value).append(")")
        }
        out.text = sb.toString()
        try {
            val m = hashMapOf<String, Any>("words" to words, "chars" to chars, "ts" to System.currentTimeMillis())
            FirebaseFirestore.getInstance().collection("users").document(AuthState.user()!!.uid)
                .collection("stats").document(deviceId()).set(m)
                .addOnSuccessListener {
                    FirebaseFirestore.getInstance().collection("users").document(AuthState.user()!!.uid)
                        .collection("stats").get().addOnSuccessListener { qs ->
                            var tw = 0L
                            var tc = 0L
                            for (d in qs.documents) {
                                tw += d.getLong("words") ?: 0L
                                tc += d.getLong("chars") ?: 0L
                            }
                            if (qs.size() > 1) {
                                out.text = out.text.toString() + "\n\n📱 كل موبايلاتك (" + qs.size() + "):\nكلمات: " + tw + "  ·  حروف: " + tc
                            }
                        }
                }
        } catch (e: Exception) {
            // مش مهم
        }
    }
}
