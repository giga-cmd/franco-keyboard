package com.franco.keyboard

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (24 * resources.displayMetrics.density).toInt()

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(pad, pad, pad, pad)

        val info = TextView(this)
        info.textSize = 18f
        info.text = "كيبورد فرانكو\n\nاكتب بالعربي والكيبورد يطلّعها فرانكو على طول.\n\nالخطوات:\n1) فعّل الكيبورد من الزرار الأول\n2) اختاره من الزرار التاني (أو من أيقونة الكيبورد وانت بتكتب)"
        root.addView(info)

        val b1 = Button(this)
        b1.text = "1) فعّل الكيبورد"
        b1.setOnClickListener {
            startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS))
        }
        root.addView(b1)

        val b2 = Button(this)
        b2.text = "2) اختار الكيبورد"
        b2.setOnClickListener {
            val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
            imm.showInputMethodPicker()
        }
        root.addView(b2)

        setContentView(root)
    }
}
