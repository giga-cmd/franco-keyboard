package com.franco.keyboard

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.widget.Toast

// بيفتح معرض الصور لحظة، وبيرجّع الصورة لوضع الـ AI في الكيبورد
class AiPickActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (savedInstanceState != null) return
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.type = "image/*"
        try {
            startActivityForResult(i, 91)
        } catch (e: Exception) {
            Toast.makeText(this, "مفيش تطبيق ملفات", Toast.LENGTH_SHORT).show()
            finish()
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        val uri = data?.data
        if (resultCode == RESULT_OK && uri != null) {
            val app = applicationContext
            Thread {
                val b64 = AiClient.encodeImage(app, uri)
                val cb = AiClient.onImage
                if (b64 != null && cb != null) cb(b64)
            }.start()
        }
        finish()
    }
}
