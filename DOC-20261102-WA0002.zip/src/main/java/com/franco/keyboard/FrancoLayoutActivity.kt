package com.franco.keyboard

import android.app.Activity
import android.content.Context
import android.content.SharedPreferences
import android.graphics.Color
import android.os.Bundle
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

// تخصيص حروف لوحة فرانكو: كل حرف عربي له حرف أساسي وبدائل بالضغط الطويل
class FrancoLayoutActivity : Activity() {
    private lateinit var prefs: SharedPreferences
    private val raw = HashMap<Char, Pair<String, String>>()
    private var resetAsk = 0L

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun txt(s: String, size: Float, color: String, bold: Boolean = false): TextView {
        val t = TextView(this)
        t.text = s
        t.textSize = size
        t.setTextColor(Color.parseColor(color))
        if (bold) t.setTypeface(t.typeface, android.graphics.Typeface.BOLD)
        return t
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("franco", Context.MODE_PRIVATE)
        raw.clear()
        raw.putAll(FrDefaults.loadRaw(prefs))

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(14), dp(18), dp(14), dp(24))
        root.layoutDirection = View.LAYOUT_DIRECTION_LTR

        val title = txt("تخصيص حروف لوحة فرانكو", 20f, "#FFFFFF", true)
        title.gravity = Gravity.CENTER
        root.addView(title)
        val note = txt("اكتب الحرف اللي عايزه مكان الحرف العربي. الحروف التانية بتظهر بالضغط الطويل (افصل بينها بمسافة).", 13f, "#B0FFFFFF")
        note.gravity = Gravity.CENTER
        note.setPadding(0, dp(6), 0, dp(10))
        root.addView(note)

        val head = LinearLayout(this)
        head.orientation = LinearLayout.HORIZONTAL
        val h1 = txt("الحرف", 13f, "#80CBC4")
        val h2 = txt("الأساسي", 13f, "#80CBC4")
        val h3 = txt("بالضغط الطويل", 13f, "#80CBC4")
        h1.gravity = Gravity.CENTER
        h2.gravity = Gravity.CENTER
        h3.gravity = Gravity.CENTER
        head.addView(h1, LinearLayout.LayoutParams(dp(56), ViewGroup.LayoutParams.WRAP_CONTENT))
        head.addView(h2, LinearLayout.LayoutParams(dp(92), ViewGroup.LayoutParams.WRAP_CONTENT))
        head.addView(h3, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        root.addView(head)

        for (ch in FrDefaults.LETTERS) {
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            val l = txt(ch.toString(), 24f, "#FFFFFF", true)
            l.gravity = Gravity.CENTER
            row.addView(l, LinearLayout.LayoutParams(dp(56), ViewGroup.LayoutParams.WRAP_CONTENT))
            val cur = raw[ch] ?: Pair(FrDefaults.defMain(ch), FrDefaults.defAlts(ch))
            val m = field(cur.first, false) { v ->
                val o = raw[ch] ?: Pair("", "")
                raw[ch] = Pair(v, o.second)
                FrDefaults.saveRaw(prefs, raw)
            }
            row.addView(m, LinearLayout.LayoutParams(dp(92), ViewGroup.LayoutParams.WRAP_CONTENT))
            val a = field(cur.second, true) { v ->
                val o = raw[ch] ?: Pair("", "")
                raw[ch] = Pair(o.first, v)
                FrDefaults.saveRaw(prefs, raw)
            }
            row.addView(a, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            root.addView(row)
        }

        val reset = txt("رجوع للأصل", 16f, "#FFFFFF", true)
        reset.gravity = Gravity.CENTER
        reset.setPadding(0, dp(14), 0, dp(14))
        reset.setBackgroundColor(Color.parseColor("#3F51B5"))
        reset.setOnClickListener {
            val now = System.currentTimeMillis()
            if (now - resetAsk > 3500) {
                resetAsk = now
                Toast.makeText(this, "دوس تاني للتأكيد", Toast.LENGTH_SHORT).show()
            } else {
                prefs.edit().remove("fr_map").apply()
                Toast.makeText(this, "اترجعت الحروف", Toast.LENGTH_SHORT).show()
                recreate()
            }
        }
        val rl = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        rl.setMargins(0, dp(18), 0, 0)
        root.addView(reset, rl)
        val foot = txt("التغييرات بتظهر أول ما تفتح الكيبورد تاني.", 12f, "#B0FFFFFF")
        foot.gravity = Gravity.CENTER
        foot.setPadding(0, dp(10), 0, 0)
        root.addView(foot)

        val sv = ScrollView(this)
        sv.setBackgroundColor(Color.parseColor("#17171C"))
        sv.addView(root)
        setContentView(sv)
    }

    private fun field(init: String, wide: Boolean, onChange: (String) -> Unit): EditText {
        val e = EditText(this)
        e.setText(init)
        e.setTextColor(Color.WHITE)
        e.setHintTextColor(Color.parseColor("#55FFFFFF"))
        e.textSize = 16f
        e.setSingleLine(true)
        e.gravity = Gravity.CENTER
        e.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
        e.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {
                onChange(s?.toString() ?: "")
            }

            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
        })
        return e
    }
}
