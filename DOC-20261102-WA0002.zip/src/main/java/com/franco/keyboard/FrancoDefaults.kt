package com.franco.keyboard

import android.content.SharedPreferences

// لوحة فرانكو: الحرف العربي ← الحرف اللاتيني الأساسي + بدائل بالضغط الطويل
object FrDefaults {
    const val LETTERS = "ضصثقفغعهخحجشسيبلاتنمكطذءؤرىةوزظد"

    private val defs: Map<Char, Pair<String, String>> = mapOf(
        'ض' to Pair("d", "9' D"),
        'ص' to Pair("s", "9 S"),
        'ث' to Pair("th", "s t"),
        'ق' to Pair("2", "q 8 g 9"),
        'ف' to Pair("f", "v"),
        'غ' to Pair("gh", "3' 8 g"),
        'ع' to Pair("3", "a e"),
        'ه' to Pair("h", ""),
        'خ' to Pair("5", "kh 7' x"),
        'ح' to Pair("7", "h"),
        'ج' to Pair("g", "j ch"),
        'ش' to Pair("sh", "ch"),
        'س' to Pair("s", "c"),
        'ي' to Pair("y", "i e"),
        'ب' to Pair("b", "p"),
        'ل' to Pair("l", ""),
        'ا' to Pair("a", "e i o"),
        'ت' to Pair("t", ""),
        'ن' to Pair("n", ""),
        'م' to Pair("m", ""),
        'ك' to Pair("k", "c g"),
        'ط' to Pair("6", "t 6'"),
        'ذ' to Pair("z", "dh th d"),
        'ء' to Pair("2", "' a e"),
        'ؤ' to Pair("o", "2o w"),
        'ر' to Pair("r", ""),
        'ى' to Pair("a", "y e"),
        'ة' to Pair("a", "t h ah"),
        'و' to Pair("w", "o u oo"),
        'ز' to Pair("z", "s"),
        'ظ' to Pair("6'", "z dh"),
        'د' to Pair("d", "dh")
    )

    fun defMain(c: Char): String = defs[c]?.first ?: ""
    fun defAlts(c: Char): String = defs[c]?.second ?: ""

    // الحرف ← (الأساسي، البدائل كنص مفصول بمسافات)
    fun loadRaw(p: SharedPreferences?): HashMap<Char, Pair<String, String>> {
        val saved = HashMap<Char, Pair<String, String>>()
        val raw = p?.getString("fr_map", "") ?: ""
        for (line in raw.split("\n")) {
            if (line.length < 2 || line[1] != '=') continue
            val rest = line.substring(2)
            val i = rest.indexOf('|')
            val m = if (i >= 0) rest.substring(0, i) else rest
            val a = if (i >= 0) rest.substring(i + 1) else ""
            saved[line[0]] = Pair(m, a)
        }
        val out = HashMap<Char, Pair<String, String>>()
        for (c in LETTERS) {
            val s = saved[c]
            val m = if (s != null && s.first.isNotEmpty()) s.first else defMain(c)
            val a = if (s != null) s.second else defAlts(c)
            out[c] = Pair(m, a)
        }
        return out
    }

    fun toList(raw: Map<Char, Pair<String, String>>): Map<Char, Pair<String, List<String>>> {
        val out = HashMap<Char, Pair<String, List<String>>>()
        for ((k, v) in raw) {
            out[k] = Pair(v.first, v.second.split(" ").filter { it.isNotEmpty() })
        }
        return out
    }

    fun clean(s: String): String = s.replace("=", "").replace("|", "").replace("\n", " ").trim()

    fun saveRaw(p: SharedPreferences, raw: Map<Char, Pair<String, String>>) {
        val sb = StringBuilder()
        for (c in LETTERS) {
            val v = raw[c] ?: continue
            if (sb.isNotEmpty()) sb.append('\n')
            sb.append(c).append('=').append(clean(v.first)).append('|').append(clean(v.second))
        }
        p.edit().putString("fr_map", sb.toString()).apply()
    }
}
