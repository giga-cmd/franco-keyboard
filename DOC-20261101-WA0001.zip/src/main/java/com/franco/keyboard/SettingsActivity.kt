package com.franco.keyboard

import android.app.Activity
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Outline
import android.graphics.drawable.GradientDrawable
import android.media.ExifInterface
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import java.io.File
import java.io.FileOutputStream

class SettingsActivity : Activity() {

    private lateinit var prefs: SharedPreferences
    private lateinit var previewImg: ImageView
    private lateinit var previewScrim: View
    private val sampleKeys = ArrayList<TextView>()
    private val reqPick = 41

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun button(text: String, action: () -> Unit): TextView {
        val b = TextView(this)
        b.text = text
        b.setTextColor(Color.WHITE)
        b.textSize = 17f
        b.gravity = Gravity.CENTER
        val g = GradientDrawable()
        g.cornerRadius = dp(28).toFloat()
        g.setColor(Color.parseColor("#B33F51B5"))
        g.setStroke(dp(1), Color.parseColor("#80FFFFFF"))
        b.background = g
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(52))
        lp.setMargins(0, dp(8), 0, dp(8))
        b.layoutParams = lp
        b.setOnClickListener { action() }
        return b
    }

    private fun label(text: String): TextView {
        val t = TextView(this)
        t.text = text
        t.setTextColor(Color.WHITE)
        t.textSize = 15f
        t.setShadowLayer(6f, 0f, 0f, Color.BLACK)
        t.setPadding(0, dp(14), 0, dp(2))
        return t
    }

    private fun slider(
        title: String,
        key: String,
        min: Int,
        max: Int,
        def: Int,
        col: LinearLayout
    ) {
        col.addView(label(title))
        val sb = SeekBar(this)
        sb.max = max - min
        sb.progress = prefs.getInt(key, def) - min
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                prefs.edit().putInt(key, p + min).apply()
                updatePreviewLook()
            }

            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        col.addView(
            sb,
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
        )
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("franco", MODE_PRIVATE)
        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.BLACK
        window.decorView.systemUiVisibility =
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN

        val root = FrameLayout(this)
        val bg = ImageView(this)
        bg.setImageResource(R.drawable.bg)
        bg.scaleType = ImageView.ScaleType.CENTER_CROP
        root.addView(bg, FrameLayout.LayoutParams(-1, -1))
        val sc = View(this)
        sc.setBackgroundColor(Color.parseColor("#80000000"))
        root.addView(sc, FrameLayout.LayoutParams(-1, -1))

        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(24), dp(56), dp(24), dp(32))

        val title = TextView(this)
        title.text = "إعدادات الكيبورد"
        title.setTextColor(Color.WHITE)
        title.textSize = 24f
        title.gravity = Gravity.CENTER
        title.setShadowLayer(8f, 0f, 0f, Color.BLACK)
        title.setPadding(0, 0, 0, dp(16))
        col.addView(title)

        // معاينة
        val prev = FrameLayout(this)
        prev.setBackgroundColor(Color.parseColor("#1B1B1F"))
        prev.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                outline.setRoundRect(0, 0, view.width, view.height, dp(16).toFloat())
            }
        }
        prev.clipToOutline = true
        previewImg = ImageView(this)
        previewImg.scaleType = ImageView.ScaleType.CENTER_CROP
        prev.addView(previewImg, FrameLayout.LayoutParams(-1, -1))
        previewScrim = View(this)
        prev.addView(previewScrim, FrameLayout.LayoutParams(-1, -1))
        val keys = LinearLayout(this)
        keys.orientation = LinearLayout.HORIZONTAL
        keys.layoutDirection = View.LAYOUT_DIRECTION_LTR
        keys.setPadding(dp(6), 0, dp(6), 0)
        for (ch in listOf("ج", "ح", "خ", "ه", "ع", "غ")) {
            val t = TextView(this)
            t.text = ch
            t.setTextColor(Color.WHITE)
            t.textSize = 20f
            t.gravity = Gravity.CENTER
            val g = GradientDrawable()
            g.cornerRadius = dp(8).toFloat()
            g.setColor(Color.parseColor("#3C3C45"))
            t.background = g
            val lp = LinearLayout.LayoutParams(0, dp(46), 1f)
            lp.setMargins(dp(2), 0, dp(2), 0)
            t.layoutParams = lp
            keys.addView(t)
            sampleKeys.add(t)
        }
        prev.addView(keys, FrameLayout.LayoutParams(-1, -2, Gravity.CENTER))
        col.addView(prev, LinearLayout.LayoutParams(-1, dp(170)))

        col.addView(button("اختيار صورة للكيبورد") { pickImage() })
        col.addView(button("تغيير حجم الكيبورد") {
            startActivity(Intent(this, ResizeActivity::class.java))
        })
        val onlineBtn = button("") { }
        fun refreshOnline() {
            val on = prefs.getBoolean("online", true)
            onlineBtn.text = if (on) "التصحيح الأونلاين: شغال ✓" else "التصحيح الأونلاين: مقفول"
        }
        onlineBtn.setOnClickListener {
            prefs.edit().putBoolean("online", !prefs.getBoolean("online", true)).apply()
            refreshOnline()
        }
        refreshOnline()
        col.addView(onlineBtn)
        slider("تغميق الصورة", "bg_dim", 0, 90, 35, col)
        slider("شفافية الزراير", "key_alpha", 20, 100, 60, col)
        slider("حجم حروف الكيبورد", "key_text", 12, 28, 18, col)
        col.addView(button("رجوع للخلفية الأصلية") {
            File(filesDir, "kb_bg.jpg").delete()
            loadPreviewImage()
            updatePreviewLook()
            Toast.makeText(this, "تم", Toast.LENGTH_SHORT).show()
        })

        val note = TextView(this)
        note.text = "التغيير بيظهر أول ما تفتح الكيبورد تاني."
        note.setTextColor(Color.parseColor("#CCFFFFFF"))
        note.textSize = 13f
        note.gravity = Gravity.CENTER
        note.setPadding(0, dp(12), 0, 0)
        col.addView(note)

        val scroll = ScrollView(this)
        scroll.addView(col)
        root.addView(scroll, FrameLayout.LayoutParams(-1, -1))
        setContentView(root)

        loadPreviewImage()
        updatePreviewLook()
    }

    private fun loadPreviewImage() {
        val f = File(filesDir, "kb_bg.jpg")
        if (f.exists()) {
            try {
                previewImg.setImageBitmap(BitmapFactory.decodeFile(f.path))
            } catch (e: Throwable) {
                previewImg.setImageDrawable(null)
            }
        } else {
            previewImg.setImageDrawable(null)
        }
    }

    private fun updatePreviewLook() {
        val has = File(filesDir, "kb_bg.jpg").exists()
        val dim = prefs.getInt("bg_dim", 35)
        previewScrim.setBackgroundColor(Color.argb(if (has) dim * 255 / 100 else 0, 0, 0, 0))
        val a = if (has) prefs.getInt("key_alpha", 60) * 255 / 100 else 255
        for (t in sampleKeys) {
            (t.background as GradientDrawable).setColor(Color.argb(a, 0x3C, 0x3C, 0x45))
        }
    }

    private fun pickImage() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.type = "image/*"
        try {
            startActivityForResult(i, reqPick)
        } catch (e: Exception) {
            Toast.makeText(this, "مفيش تطبيق معرض صور", Toast.LENGTH_SHORT).show()
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != reqPick || resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        Thread {
            val ok = saveImage(uri)
            runOnUiThread {
                if (ok) {
                    loadPreviewImage()
                    updatePreviewLook()
                    Toast.makeText(this, "تم حفظ الخلفية", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(this, "الصورة دي ماتفتحتش", Toast.LENGTH_SHORT).show()
                }
            }
        }.start()
    }

    private fun saveImage(uri: Uri): Boolean {
        try {
            val bounds = BitmapFactory.Options()
            bounds.inJustDecodeBounds = true
            contentResolver.openInputStream(uri)?.use {
                BitmapFactory.decodeStream(it, null, bounds)
            }
            var sample = 1
            while (bounds.outWidth / sample > 1800 || bounds.outHeight / sample > 1800) {
                sample *= 2
            }
            val opts = BitmapFactory.Options()
            opts.inSampleSize = sample
            var bmp: Bitmap = contentResolver.openInputStream(uri)?.use {
                BitmapFactory.decodeStream(it, null, opts)
            } ?: return false

            var rot = 0
            try {
                contentResolver.openInputStream(uri)?.use {
                    val ex = ExifInterface(it)
                    val o = ex.getAttributeInt(
                        ExifInterface.TAG_ORIENTATION,
                        ExifInterface.ORIENTATION_NORMAL
                    )
                    if (o == ExifInterface.ORIENTATION_ROTATE_90) rot = 90
                    if (o == ExifInterface.ORIENTATION_ROTATE_180) rot = 180
                    if (o == ExifInterface.ORIENTATION_ROTATE_270) rot = 270
                }
            } catch (e: Throwable) {
                rot = 0
            }
            if (rot != 0) {
                val m = Matrix()
                m.postRotate(rot.toFloat())
                bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
            }

            val f = File(filesDir, "kb_bg.jpg")
            FileOutputStream(f).use {
                bmp.compress(Bitmap.CompressFormat.JPEG, 88, it)
            }
            f.setLastModified(System.currentTimeMillis())
            return true
        } catch (e: Throwable) {
            return false
        }
    }
}
