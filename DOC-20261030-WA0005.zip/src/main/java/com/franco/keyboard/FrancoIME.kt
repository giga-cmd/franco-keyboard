package com.franco.keyboard

import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.inputmethodservice.InputMethodService
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.text.TextUtils
import android.util.TypedValue
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputConnection
import android.view.inputmethod.InputMethodManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ImageView
import android.widget.ScrollView
import android.widget.TextView
import java.io.File

class FrancoIME : InputMethodService() {

    companion object {
        const val L_AR = 0
        const val L_EN = 1
        const val L_SYM1 = 2
        const val L_SYM2 = 3
        const val L_NUM = 4
        const val L_CLIP = 5

        const val C_BG = "#1B1B1F"
        const val C_KEY = "#3C3C45"
        const val C_FUNC = "#55555F"
        const val C_PRESS = "#7A7A88"
        const val C_ACCENT = "#3F51B5"
        const val C_GREEN = "#2E7D32"
    }

    private var layer = L_AR
    private var shift = 0
    private var lastShiftTap = 0L
    private var francoOn = true

    private val handler = Handler(Looper.getMainLooper())
    private var content: LinearLayout? = null
    private var toggleBtn: TextView? = null
    private var overlay: FrameLayout? = null
    private var pill: LinearLayout? = null
    private var bgImage: ImageView? = null
    private var bgScrim: View? = null
    private var bgOn = false
    private var keyAlpha = 255
    private var bgStamp = -1L
    private val popupViews = ArrayList<TextView>()
    private var repeatTask: Runnable? = null

    // الكلمة الحالية: بالعربي وبالإنجليزي اللي اتكتب لحد دلوقتي
    private val wordAr = StringBuilder()
    private var wordFr = ""

    // قاموس الكلمات والأسماء
    private val dict = HashMap<String, String>()

    // الحافظة
    private val clips = ArrayList<String>()
    private var prefs: SharedPreferences? = null
    private val clipListener = ClipboardManager.OnPrimaryClipChangedListener { grabClip() }

    // حروف الفرانكو للكلمات اللي مش في القاموس (عدّل فيها زي ما تحب)
    private val consonants: Map<Char, String> = mapOf(
        'ب' to "b", 'ت' to "t", 'ث' to "th", 'ج' to "g",
        'ح' to "7", 'خ' to "5", 'د' to "d", 'ذ' to "z",
        'ر' to "r", 'ز' to "z", 'س' to "s", 'ش' to "sh",
        'ص' to "9", 'ض' to "d", 'ط' to "6", 'ظ' to "z",
        'ع' to "3", 'غ' to "gh", 'ف' to "f", 'ق' to "2",
        'ك' to "k", 'ل' to "l", 'م' to "m", 'ن' to "n",
        'ه' to "h", 'ء' to "2", 'ؤ' to "2", 'ئ' to "2"
    )

    // نهايات الكلمات (ضمائر) وطريقة كتابتها
    private val suffixes: List<Pair<String, String>> = listOf(
        Pair("كم", "kom"), Pair("هم", "hom"), Pair("ها", "ha"),
        Pair("ني", "ni"), Pair("نا", "na"), Pair("ك", "ak"), Pair("ه", "o")
    )

    // قائمة الضغط المطوّل على النقطة: تشكيل + علامات ترقيم
    private val dotOpts: List<String> = listOf(
        "َ", "ُ", "ِ", "ً", "ٌ", "ٍ",
        "ّ", "ْ", "ـ", "؟", "!", "؛",
        ":", "\"", "'", "-", "(", ")"
    )

    // ------------------------------------------------------------------
    // دورة حياة الخدمة
    // ------------------------------------------------------------------

    override fun onCreate() {
        super.onCreate()
        loadDict("words_default.txt")
        loadDict("words_user.txt")
        prefs = getSharedPreferences("franco", Context.MODE_PRIVATE)
        loadClips()
        try {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.addPrimaryClipChangedListener(clipListener)
        } catch (e: Exception) {
            // مش مهم
        }
    }

    override fun onDestroy() {
        try {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.removePrimaryClipChangedListener(clipListener)
        } catch (e: Exception) {
            // مش مهم
        }
        super.onDestroy()
    }

    override fun onEvaluateFullscreenMode(): Boolean = false

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        resetWord()
        applyBackground()
        val cls = (info?.inputType ?: 0) and InputType.TYPE_MASK_CLASS
        if (cls == InputType.TYPE_CLASS_NUMBER || cls == InputType.TYPE_CLASS_PHONE) {
            layer = L_NUM
        } else if (layer == L_NUM || layer == L_CLIP) {
            layer = L_AR
        }
        render()
    }

    override fun onFinishInputView(finishingInput: Boolean) {
        dismissPopup()
        super.onFinishInputView(finishingInput)
    }

    // ------------------------------------------------------------------
    // القاموس والتحويل لفرانكو
    // ------------------------------------------------------------------

    private fun loadDict(name: String) {
        try {
            assets.open(name).bufferedReader(Charsets.UTF_8).useLines { lines ->
                for (line in lines) {
                    val t = line.trim()
                    if (t.isEmpty() || t.startsWith("#")) continue
                    val idx = t.indexOf('=')
                    if (idx <= 0) continue
                    val key = normalize(t.substring(0, idx).trim())
                    val value = t.substring(idx + 1).trim()
                    if (key.isNotEmpty() && value.isNotEmpty()) dict[key] = value
                }
            }
        } catch (e: Exception) {
            // الملف مش موجود: عادي
        }
    }

    private fun normalize(s: String): String {
        val sb = StringBuilder()
        for (c in s) {
            when (c) {
                'أ', 'إ', 'آ' -> sb.append('ا')
                'ى' -> sb.append('ي')
                'ة' -> sb.append('ه')
                else -> sb.append(c)
            }
        }
        return sb.toString()
    }

    private fun isMark(c: Char): Boolean = c in '\u064B'..'\u0652'

    private fun hasMarks(w: String): Boolean {
        for (c in w) {
            if (isMark(c)) return true
        }
        return false
    }

    private fun convertWord(word: String): String {
        if (hasMarks(word)) return explicit(word)
        val hit = dict[normalize(word)]
        return hit ?: fallback(word)
    }

    // كلمة فيها تشكيل: نكتبها بالحركات اللي انت حطيتها بالظبط
    private fun explicit(word: String): String {
        val sb = StringBuilder()
        var lastCons = ""
        var prev = ' '
        for ((i, c) in word.withIndex()) {
            when (c) {
                '\u064E' -> sb.append("a")
                '\u064F' -> sb.append("o")
                '\u0650' -> sb.append("e")
                '\u064B' -> sb.append("an")
                '\u064C' -> sb.append("on")
                '\u064D' -> sb.append("en")
                '\u0651' -> {
                    if (lastCons.isNotEmpty()) {
                        if (sb.endsWith(lastCons)) {
                            sb.append(lastCons)
                        } else if (sb.length > lastCons.length &&
                            sb.substring(sb.length - 1 - lastCons.length, sb.length - 1) == lastCons
                        ) {
                            sb.insert(sb.length - 1, lastCons)
                        }
                    }
                }
                '\u0652' -> {
                    // سكون: مفيش حركة
                }
                'ا', 'أ', 'إ', 'آ' -> {
                    if (!sb.endsWith("a")) sb.append("a")
                }
                'ى', 'ة' -> sb.append("a")
                'و' -> {
                    if (prev == '\u064F') {
                        // واو مدّ بعد ضمة: بتتكتب مرة واحدة
                    } else if (i == 0 || prev == '\u064E') {
                        sb.append("w")
                    } else {
                        sb.append("o")
                    }
                }
                'ي' -> {
                    if (prev == '\u0650') {
                        // ياء مدّ بعد كسرة: بتتكتب مرة واحدة
                    } else if (i == 0 || prev == '\u064E') {
                        sb.append("y")
                    } else {
                        sb.append("i")
                    }
                }
                else -> {
                    val l = consonants[c] ?: c.toString()
                    sb.append(l)
                    lastCons = l
                }
            }
            prev = c
        }
        return sb.toString()
    }

    // كلمة مش في القاموس: نفصل ال والنهايات، ونحط الحركات بالتخمين
    private fun fallback(word: String): String {
        if (word.length > 3 && word.startsWith("ال")) {
            return "el" + convertWord(word.substring(2))
        }
        for (s in suffixes) {
            val minStem = if (s.first.length == 1) 3 else 2
            if (word.length >= s.first.length + minStem && word.endsWith(s.first)) {
                val stemWord = word.substring(0, word.length - s.first.length)
                val st = dict[normalize(stemWord)] ?: stem(stemWord)
                return st + s.second
            }
        }
        return stem(word)
    }

    private fun stem(word: String): String {
        val units = ArrayList<String>()
        val isCons = ArrayList<Boolean>()
        for ((i, c) in word.withIndex()) {
            when (c) {
                'ا', 'أ', 'إ', 'آ', 'ى', 'ة' -> {
                    units.add("a")
                    isCons.add(false)
                }
                'و' -> {
                    units.add(if (i == 0) "w" else "o")
                    isCons.add(i == 0)
                }
                'ي' -> {
                    units.add(if (i == 0) "y" else "i")
                    isCons.add(i == 0)
                }
                else -> {
                    units.add(consonants[c] ?: c.toString())
                    isCons.add(true)
                }
            }
        }
        var nC = 0
        var nV = 0
        for (k in units.indices) {
            if (isCons[k]) {
                nC++
            } else if (!(k == units.size - 1 && (word[k] == 'ة' || word[k] == 'ى'))) {
                nV++
            }
        }
        val sb = StringBuilder()
        var ci = 0
        for (k in units.indices) {
            sb.append(units[k])
            if (isCons[k]) {
                val nextIsCons = (k + 1 < units.size) && isCons[k + 1]
                if (nextIsCons) {
                    if (nC == 4 && nV == 0) {
                        if (ci == 0 || ci == 2) sb.append("a")
                    } else {
                        sb.append(if (ci == 0) "a" else "e")
                    }
                }
                ci++
            }
        }
        return sb.toString()
    }

    private fun resetWord() {
        wordAr.setLength(0)
        wordFr = ""
    }

    private fun replaceWord(ic: InputConnection) {
        val newFr = convertWord(wordAr.toString())
        ic.beginBatchEdit()
        if (wordFr.isNotEmpty()) ic.deleteSurroundingText(wordFr.length, 0)
        ic.commitText(newFr, 1)
        ic.endBatchEdit()
        wordFr = newFr
    }

    // ------------------------------------------------------------------
    // الكتابة
    // ------------------------------------------------------------------

    // أي حاجة مش حرف عربي (مسافة، رقم، رمز): تنهي الكلمة الحالية
    private fun commitOther(text: String) {
        resetWord()
        currentInputConnection?.commitText(text, 1)
    }

    private fun typeLetter(ch: Char) {
        val ic = currentInputConnection ?: return
        if (!francoOn) {
            resetWord()
            ic.commitText(ch.toString(), 1)
            return
        }
        if (wordFr.isNotEmpty()) {
            val before = ic.getTextBeforeCursor(wordFr.length, 0)?.toString() ?: ""
            if (before != wordFr) resetWord()
        }
        wordAr.append(ch)
        replaceWord(ic)
    }

    // رموز الضغط المطوّل: التشكيل في وضع العربي بيتكتب زي ما هو،
    // وفي وضع فرانكو بيتحوّل لحركات (فتحة a، ضمة o، كسرة e، شدة تضاعف الحرف)
    private fun typeSymbol(s: String) {
        val c = s[0]
        if (isMark(c) || c == '\u0640') {
            if (francoOn) {
                if (c != '\u0640' && wordAr.isNotEmpty()) typeLetter(c)
                return
            }
            currentInputConnection?.commitText(s, 1)
            return
        }
        commitOther(s)
    }

    private fun doDelete() {
        val ic = currentInputConnection ?: return
        val selected = ic.getSelectedText(0)
        if (selected != null && selected.isNotEmpty()) {
            ic.commitText("", 1)
            resetWord()
            return
        }
        if (francoOn && layer == L_AR && wordAr.isNotEmpty() && wordFr.isNotEmpty()) {
            val before = ic.getTextBeforeCursor(wordFr.length, 0)?.toString() ?: ""
            if (before == wordFr) {
                wordAr.setLength(wordAr.length - 1)
                if (wordAr.isEmpty()) {
                    ic.deleteSurroundingText(wordFr.length, 0)
                    wordFr = ""
                } else {
                    replaceWord(ic)
                }
                return
            }
        }
        resetWord()
        ic.deleteSurroundingText(1, 0)
    }

    private fun doEnter() {
        resetWord()
        val ic = currentInputConnection ?: return
        val options = currentInputEditorInfo?.imeOptions ?: 0
        val action = options and EditorInfo.IME_MASK_ACTION
        val noEnterAction = (options and EditorInfo.IME_FLAG_NO_ENTER_ACTION) != 0
        if (!noEnterAction &&
            action != EditorInfo.IME_ACTION_NONE &&
            action != EditorInfo.IME_ACTION_UNSPECIFIED
        ) {
            ic.performEditorAction(action)
        } else {
            sendDownUpKeyEvents(KeyEvent.KEYCODE_ENTER)
        }
    }

    private fun showPicker() {
        val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
        imm.showInputMethodPicker()
    }

    private fun go(target: Int) {
        layer = target
        resetWord()
        render()
    }

    // ------------------------------------------------------------------
    // الحافظة
    // ------------------------------------------------------------------

    private fun loadClips() {
        clips.clear()
        val s = prefs?.getString("clips", "") ?: ""
        if (s.isNotEmpty()) {
            for (p in s.split("\u0001")) {
                if (p.isNotEmpty()) clips.add(p)
            }
        }
    }

    private fun saveClips() {
        prefs?.edit()?.putString("clips", clips.joinToString("\u0001"))?.apply()
    }

    private fun addClip(t: String) {
        val s = t.trim()
        if (s.isEmpty() || s.length > 3000) return
        clips.remove(s)
        clips.add(0, s)
        while (clips.size > 30) clips.removeAt(clips.size - 1)
        saveClips()
    }

    private fun grabClip() {
        try {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            val clip = cm.primaryClip ?: return
            if (clip.itemCount > 0) {
                val t = clip.getItemAt(0).coerceToText(this)?.toString()
                if (t != null) addClip(t)
            }
        } catch (e: Exception) {
            // مش مهم
        }
    }

    // ------------------------------------------------------------------
    // أدوات الرسم
    // ------------------------------------------------------------------

    private fun dp(v: Int): Int =
        TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP, v.toFloat(), resources.displayMetrics
        ).toInt()

    private fun roundBg(color: String): GradientDrawable {
        val bg = GradientDrawable()
        bg.cornerRadius = dp(8).toFloat()
        bg.setColor(Color.parseColor(color))
        return bg
    }

    private fun newRow(): LinearLayout {
        val r = LinearLayout(this)
        r.orientation = LinearLayout.HORIZONTAL
        r.layoutDirection = View.LAYOUT_DIRECTION_LTR
        r.layoutParams = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )
        return r
    }

    private fun spacer(weight: Float): View {
        val v = View(this)
        v.layoutParams = LinearLayout.LayoutParams(0, dp(46), weight)
        return v
    }

    private fun toolButton(label: String, onClick: () -> Unit): TextView {
        val t = TextView(this)
        t.text = label
        t.setTextColor(Color.WHITE)
        t.textSize = 15f
        t.gravity = Gravity.CENTER
        t.setPadding(dp(14), 0, dp(14), 0)
        t.background = roundBg(C_FUNC)
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(32))
        lp.setMargins(dp(4), dp(3), dp(4), dp(3))
        t.layoutParams = lp
        t.setOnClickListener { onClick() }
        return t
    }

    // لون الزرار مع الشفافية (لما يكون في خلفية صورة)
    private fun keyInt(color: String): Int {
        val v = Color.parseColor(color)
        return if (bgOn && (color == C_KEY || color == C_FUNC)) {
            (v and 0x00FFFFFF) or (keyAlpha shl 24)
        } else {
            v
        }
    }

    // زرار عام: ضغطة، ضغط مطوّل (قائمة اختيارات أو حدث)، وتكرار للمسح
    // pre = رقم الاختيار المظلل أول ما القائمة تفتح (-1 = مفيش)
    private fun key(
        label: String,
        weight: Float = 1f,
        color: String = C_KEY,
        hint: String? = null,
        opts: List<String> = emptyList(),
        onOpt: ((String) -> Unit)? = null,
        onLong: (() -> Unit)? = null,
        autoRepeat: Boolean = false,
        pre: Int = -1,
        textSize: Float = 18f,
        onTap: () -> Unit
    ): FrameLayout {
        val fl = FrameLayout(this)
        val lp = LinearLayout.LayoutParams(0, dp(46), weight)
        lp.setMargins(dp(2), dp(3), dp(2), dp(3))
        fl.layoutParams = lp
        val bg = roundBg(color)
        bg.setColor(keyInt(color))
        fl.background = bg

        val tv = TextView(this)
        tv.text = label
        tv.setTextColor(Color.WHITE)
        tv.textSize = textSize
        tv.gravity = Gravity.CENTER
        fl.addView(
            tv,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        )

        if (hint != null) {
            val h = TextView(this)
            h.text = hint
            h.textSize = 10f
            h.setTextColor(Color.parseColor("#C8C8D0"))
            val hp = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
            hp.gravity = Gravity.TOP or Gravity.END
            hp.setMargins(0, dp(2), dp(5), 0)
            fl.addView(h, hp)
        }

        var longHandled = false
        var popupShown = false
        var selected = -1
        var downX = 0f
        var downY = 0f

        val longTask = Runnable {
            if (onLong != null) {
                longHandled = true
                onLong()
            } else if (opts.isNotEmpty()) {
                popupShown = true
                showPopup(fl, opts, pre)
                selected = pre
                highlightPopup(pre)
            }
        }

        fl.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    longHandled = false
                    popupShown = false
                    selected = -1
                    downX = e.rawX
                    downY = e.rawY
                    bg.setColor(Color.parseColor(C_PRESS))
                    if (autoRepeat) {
                        onTap()
                        startRepeat(onTap)
                    } else if (onLong != null || opts.isNotEmpty()) {
                        handler.postDelayed(longTask, 350)
                    }
                }
                MotionEvent.ACTION_MOVE -> {
                    if (popupShown) {
                        val moved = Math.abs(e.rawX - downX) > dp(10) ||
                            Math.abs(e.rawY - downY) > dp(10)
                        if (moved) {
                            val hit = popupHit(e.rawX, e.rawY)
                            if (hit >= 0) {
                                selected = hit
                            } else if (pre < 0) {
                                selected = -1
                            }
                            highlightPopup(selected)
                        }
                    }
                }
                MotionEvent.ACTION_UP -> {
                    handler.removeCallbacks(longTask)
                    stopRepeat()
                    bg.setColor(keyInt(color))
                    if (popupShown) {
                        val idx = selected
                        dismissPopup()
                        if (idx >= 0) {
                            val cb = onOpt
                            if (cb != null) cb(opts[idx])
                        } else {
                            onTap()
                        }
                    } else if (!longHandled && !autoRepeat) {
                        onTap()
                    }
                }
                MotionEvent.ACTION_CANCEL -> {
                    handler.removeCallbacks(longTask)
                    stopRepeat()
                    bg.setColor(keyInt(color))
                    dismissPopup()
                }
            }
            true
        }
        return fl
    }

    private fun startRepeat(action: () -> Unit) {
        stopRepeat()
        val r = object : Runnable {
            override fun run() {
                action()
                handler.postDelayed(this, 55)
            }
        }
        repeatTask = r
        handler.postDelayed(r, 400)
    }

    private fun stopRepeat() {
        val r = repeatTask
        if (r != null) handler.removeCallbacks(r)
        repeatTask = null
    }

    // ------------------------------------------------------------------
    // قائمة الضغط المطوّل
    // ------------------------------------------------------------------

    private fun pillBg(color: String, radiusDp: Int): GradientDrawable {
        val g = GradientDrawable()
        g.cornerRadius = dp(radiusDp).toFloat()
        g.setColor(Color.parseColor(color))
        return g
    }

    // القائمة بتترسم جوه الكيبورد نفسه (طبقة فوق الزراير)
    private fun showPopup(anchor: View, opts: List<String>, pre: Int) {
        dismissPopup()
        val ov = overlay ?: return
        val n = opts.size
        val rows = if (n <= 6) 1 else if (n <= 16) 2 else 3
        val perRow = (n + rows - 1) / rows
        val itemW = dp(40)
        val itemH = dp(44)

        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.layoutDirection = View.LAYOUT_DIRECTION_LTR
        box.background = pillBg("#F2383842", 24)
        box.setPadding(dp(6), dp(5), dp(6), dp(5))
        var r: LinearLayout? = null
        for ((i, o) in opts.withIndex()) {
            if (i % perRow == 0) {
                val nr = LinearLayout(this)
                nr.orientation = LinearLayout.HORIZONTAL
                nr.layoutDirection = View.LAYOUT_DIRECTION_LTR
                box.addView(nr)
                r = nr
            }
            val t = TextView(this)
            val c = o[0]
            t.text = if (c in 'ً'..'ْ') "◌" + o else o
            t.setTextColor(Color.WHITE)
            t.textSize = 20f
            t.gravity = Gravity.CENTER
            t.layoutParams = LinearLayout.LayoutParams(itemW, itemH)
            r?.addView(t)
            popupViews.add(t)
        }
        box.measure(
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED),
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
        )
        val w = box.measuredWidth
        val h = box.measuredHeight

        val a = IntArray(2)
        anchor.getLocationOnScreen(a)
        val o2 = IntArray(2)
        ov.getLocationOnScreen(o2)
        val keyCx = a[0] - o2[0] + anchor.width / 2
        val keyTop = a[1] - o2[1]

        val col = if (pre >= 0) pre % perRow else 0
        var x = keyCx - dp(6) - col * itemW - itemW / 2
        if (x + w > ov.width - dp(2)) x = ov.width - dp(2) - w
        if (x < dp(2)) x = dp(2)
        var y = keyTop - h - dp(4)
        if (y < 0) y = 0

        val lp = FrameLayout.LayoutParams(w, h)
        lp.gravity = Gravity.TOP or Gravity.LEFT
        lp.leftMargin = x
        lp.topMargin = y
        ov.addView(box, lp)
        pill = box
    }

    private fun popupHit(x: Float, y: Float): Int {
        val b = pill ?: return -1
        if (popupViews.isEmpty()) return -1
        val loc = IntArray(2)
        b.getLocationOnScreen(loc)
        val tol = dp(24)
        if (x < loc[0] - tol || x > loc[0] + b.width + tol) return -1
        val itemH = popupViews[0].height
        if (itemH <= 0) return -1
        var ri = ((y - loc[1] - b.paddingTop) / itemH).toInt()
        if (ri < 0) ri = 0
        if (ri >= b.childCount) ri = b.childCount - 1
        val rowV = b.getChildAt(ri) as LinearLayout
        var best = -1
        var bestD = Float.MAX_VALUE
        val l2 = IntArray(2)
        for (k in 0 until rowV.childCount) {
            val v = rowV.getChildAt(k) as TextView
            v.getLocationOnScreen(l2)
            val d = Math.abs(l2[0] + v.width / 2f - x)
            if (d < bestD) {
                bestD = d
                best = popupViews.indexOf(v)
            }
        }
        return best
    }

    private fun highlightPopup(sel: Int) {
        for ((i, v) in popupViews.withIndex()) {
            if (i == sel) v.background = pillBg("#5B8DEF", 22) else v.background = null
        }
    }

    private fun dismissPopup() {
        val p = pill
        if (p != null) {
            try {
                (p.parent as? ViewGroup)?.removeView(p)
            } catch (e: Exception) {
                // مش مهم
            }
        }
        pill = null
        popupViews.clear()
    }

    // ------------------------------------------------------------------
    // الشاشة والطبقات
    // ------------------------------------------------------------------

    override fun onCreateInputView(): View {
        val frame = KbFrame(this)
        frame.layoutDirection = View.LAYOUT_DIRECTION_LTR
        frame.setBackgroundColor(Color.parseColor(C_BG))

        // طبقة 0: صورة الخلفية، طبقة 1: تغميق
        val img = ImageView(this)
        img.scaleType = ImageView.ScaleType.CENTER_CROP
        img.visibility = View.GONE
        frame.addView(img, FrameLayout.LayoutParams(-1, -1))
        bgImage = img
        val scrim = View(this)
        scrim.visibility = View.GONE
        frame.addView(scrim, FrameLayout.LayoutParams(-1, -1))
        bgScrim = scrim

        // طبقة 2: الكيبورد نفسه
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.layoutDirection = View.LAYOUT_DIRECTION_LTR
        root.setPadding(dp(3), dp(2), dp(3), dp(6))

        // الشريط العلوي
        val bar = LinearLayout(this)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.layoutDirection = View.LAYOUT_DIRECTION_LTR
        bar.gravity = Gravity.CENTER_VERTICAL
        bar.layoutParams = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            dp(46)
        )
        bar.addView(toolButton("📋") {
            layer = L_CLIP
            resetWord()
            grabClip()
            render()
        })
        val toggle = toolButton("") {
            francoOn = !francoOn
            resetWord()
            render()
        }
        toggleBtn = toggle
        bar.addView(toggle)
        val fill = View(this)
        fill.layoutParams = LinearLayout.LayoutParams(0, 1, 1f)
        bar.addView(fill)
        bar.addView(toolButton("⚙") {
            try {
                val i = Intent(this, SettingsActivity::class.java)
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                startActivity(i)
            } catch (e: Exception) {
                // مش مهم
            }
        })
        bar.addView(toolButton("⌄") { requestHideSelf(0) })
        root.addView(bar)

        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.layoutDirection = View.LAYOUT_DIRECTION_LTR
        content = c
        root.addView(c)
        frame.addView(root, FrameLayout.LayoutParams(-1, -2))

        // طبقة 3: قوائم الضغط المطوّل
        val ov = FrameLayout(this)
        ov.layoutDirection = View.LAYOUT_DIRECTION_LTR
        frame.addView(ov, FrameLayout.LayoutParams(-1, -1))
        overlay = ov

        applyBackground()
        render()
        return frame
    }

    // قراءة إعدادات الخلفية (صورة + تغميق + شفافية الزراير)
    private fun applyBackground() {
        val p = prefs ?: getSharedPreferences("franco", Context.MODE_PRIVATE)
        val iv = bgImage ?: return
        val sc = bgScrim ?: return
        val f = File(filesDir, "kb_bg.jpg")
        if (f.exists()) {
            if (bgStamp != f.lastModified()) {
                try {
                    val bmp = BitmapFactory.decodeFile(f.path)
                    iv.setImageBitmap(bmp)
                    bgStamp = if (bmp != null) f.lastModified() else -1L
                } catch (e: Throwable) {
                    bgStamp = -1L
                }
            }
        } else {
            iv.setImageDrawable(null)
            bgStamp = -1L
        }
        bgOn = bgStamp >= 0
        iv.visibility = if (bgOn) View.VISIBLE else View.GONE
        val dim = p.getInt("bg_dim", 35)
        sc.setBackgroundColor(Color.argb(dim * 255 / 100, 0, 0, 0))
        sc.visibility = if (bgOn) View.VISIBLE else View.GONE
        keyAlpha = if (bgOn) p.getInt("key_alpha", 60) * 255 / 100 else 255
    }

    private fun refreshToggle() {
        val b = toggleBtn ?: return
        b.text = if (francoOn) "فرانكو ✓" else "عربي"
        b.background = roundBg(if (francoOn) C_GREEN else C_FUNC)
    }

    private fun render() {
        val c = content ?: return
        dismissPopup()
        c.removeAllViews()
        when (layer) {
            L_AR -> buildArabic(c)
            L_EN -> buildEnglish(c)
            L_SYM1 -> buildSym1(c)
            L_SYM2 -> buildSym2(c)
            L_NUM -> buildNumpad(c)
            L_CLIP -> buildClipboard(c)
        }
        refreshToggle()
    }

    private fun variants(ch: Char): List<String> = when (ch) {
        'ا' -> listOf("أ", "إ", "آ", "ء")
        'و' -> listOf("ؤ")
        'ي' -> listOf("ئ", "ى")
        'ه' -> listOf("ة")
        'ب' -> listOf("پ")
        'ج' -> listOf("چ")
        'ف' -> listOf("ڤ")
        'ك' -> listOf("گ")
        'ز' -> listOf("ژ")
        'ل' -> listOf("لا", "لأ", "لإ", "لآ")
        else -> emptyList()
    }

    private val marks: List<String> = listOf(
        "َ", "ُ", "ِ", "ً", "ٌ", "ٍ", "ّ", "ْ"
    )

    // الصف الفوقاني: الرقم (غربي وعربي) أول، وبعده البدايل والتشكيل.
    // باقي الحروف: الحرف نفسه مظلل أول، وبعده البدايل والتشكيل.
    private fun arKey(ch: Char, digit: String?): FrameLayout {
        val opts = ArrayList<String>()
        if (digit != null) {
            opts.add(digit)
            opts.add(arabicIndic(digit[0]))
        } else {
            opts.add(ch.toString())
        }
        opts.addAll(variants(ch))
        opts.addAll(marks)
        return key(ch.toString(), 1f, C_KEY, digit, opts, { o ->
            val c = o[0]
            if (c.isDigit()) {
                commitOther(o)
            } else if (isMark(c)) {
                typeSymbol(o)
            } else {
                for (x in o) typeLetter(x)
            }
        }, pre = 0) {
            typeLetter(ch)
        }
    }

    private fun spaceKey(label: String): FrameLayout =
        key(label, 4f, C_KEY, textSize = 14f) { commitOther(" ") }

    private fun enterKey(): FrameLayout =
        key("⏎", 1.4f, C_ACCENT) { doEnter() }

    private val enDotOpts: List<String> = listOf(
        "?", "!", ",", "'", "\"", "-", ":", ";", "(", ")", "@", "…"
    )

    private fun dotKey(english: Boolean = false): FrameLayout =
        if (english) {
            key(".", 1f, C_KEY, opts = enDotOpts, onOpt = { commitOther(it) }) { commitOther(".") }
        } else {
            key(".", 1f, C_KEY, opts = dotOpts, onOpt = { typeSymbol(it) }) { commitOther(".") }
        }

    private fun backKey(): FrameLayout =
        key("⌫", 1.5f, C_FUNC, autoRepeat = true) { doDelete() }

    // ---------------- عربي ----------------

    private fun buildArabic(c: LinearLayout) {
        val digits = "1234567890"
        val r0 = newRow()
        for ((i, ch) in "ضصثقفغعهخحج".withIndex()) {
            r0.addView(arKey(ch, if (i < 10) digits[i].toString() else null))
        }
        c.addView(r0)

        val r1 = newRow()
        for (ch in "شسيبلاتنمكط") r1.addView(arKey(ch, null))
        c.addView(r1)

        val r2 = newRow()
        for (ch in "ذءؤرىةوزظد") r2.addView(arKey(ch, null))
        r2.addView(backKey())
        c.addView(r2)

        val b = newRow()
        b.addView(key("?١٢٣", 1.4f, C_FUNC, textSize = 14f) { go(L_SYM1) })
        b.addView(key("🌐", 1f, C_FUNC, onLong = { showPicker() }) { go(L_EN) })
        b.addView(
            key("،", 1f, C_KEY, opts = listOf("،", ",", "؛", ":", "!", "؟", "?", "\"", "'", "-", "(", ")", "@"), onOpt = { commitOther(it) }, pre = 0) {
                commitOther("،")
            }
        )
        b.addView(spaceKey(if (francoOn) "فرانكو" else "العربية"))
        b.addView(dotKey())
        b.addView(enterKey())
        c.addView(b)
    }

    // ---------------- إنجليزي ----------------

    private fun enVariants(ch: Char): List<String> = when (ch) {
        'a' -> listOf("à", "á", "â", "ä", "æ", "ã", "å", "ā")
        'c' -> listOf("ç", "ć", "č")
        'd' -> listOf("ð")
        'e' -> listOf("è", "é", "ê", "ë", "ē", "ė", "ę")
        'g' -> listOf("ğ")
        'i' -> listOf("î", "ï", "í", "ī", "į", "ì")
        'l' -> listOf("ł")
        'n' -> listOf("ñ", "ń")
        'o' -> listOf("ô", "ö", "ò", "ó", "œ", "ø", "ō", "õ")
        's' -> listOf("ß", "ś", "š")
        'u' -> listOf("û", "ü", "ù", "ú", "ū")
        'y' -> listOf("ý", "ÿ")
        'z' -> listOf("ž", "ź", "ż")
        else -> emptyList()
    }

    private fun enKey(ch: Char, digit: String?): FrameLayout {
        val shown = if (shift > 0) ch.uppercaseChar().toString() else ch.toString()
        val vs = enVariants(ch)
        val opts = ArrayList<String>()
        if (digit != null) {
            opts.add(digit)
        } else if (vs.isNotEmpty()) {
            opts.add(shown)
        }
        if (opts.isNotEmpty()) {
            for (v in vs) opts.add(if (shift > 0) v.uppercase() else v)
        }
        return key(shown, 1f, C_KEY, digit, opts, { o ->
            commitOther(o)
            if (shift == 1) {
                shift = 0
                render()
            }
        }, pre = if (opts.isNotEmpty()) 0 else -1) {
            commitOther(shown)
            if (shift == 1) {
                shift = 0
                render()
            }
        }
    }

    private fun buildEnglish(c: LinearLayout) {
        val digits = "1234567890"
        val r0 = newRow()
        for ((i, ch) in "qwertyuiop".withIndex()) r0.addView(enKey(ch, digits[i].toString()))
        c.addView(r0)

        val r1 = newRow()
        r1.addView(spacer(0.5f))
        for (ch in "asdfghjkl") r1.addView(enKey(ch, null))
        r1.addView(spacer(0.5f))
        c.addView(r1)

        val r2 = newRow()
        r2.addView(
            key(if (shift == 2) "⇪" else "⇧", 1.5f, if (shift > 0) C_ACCENT else C_FUNC) {
                val now = System.currentTimeMillis()
                shift = if (shift == 1 && now - lastShiftTap < 350) {
                    2
                } else if (shift == 0) {
                    1
                } else {
                    0
                }
                lastShiftTap = now
                render()
            }
        )
        for (ch in "zxcvbnm") r2.addView(enKey(ch, null))
        r2.addView(backKey())
        c.addView(r2)

        val b = newRow()
        b.addView(key("?123", 1.4f, C_FUNC, textSize = 14f) { go(L_SYM1) })
        b.addView(key("🌐", 1f, C_FUNC, onLong = { showPicker() }) { go(L_AR) })
        b.addView(
            key(
                ",", 1f, C_KEY,
                opts = listOf("&", "%", "+", "\"", "-", ":", "'", "@", ";", "/", "(", ")", "#", "!", ",", "?"),
                onOpt = { commitOther(it) }, pre = 14
            ) { commitOther(",") }
        )
        b.addView(spaceKey("English"))
        b.addView(dotKey(true))
        b.addView(enterKey())
        c.addView(b)
    }

    // ---------------- رموز 1 ----------------

    private fun symVariants(ch: Char): List<String> = when (ch) {
        '(' -> listOf("(", "[", "{", "<")
        ')' -> listOf(")", "]", "}", ">")
        '[' -> listOf("[", "(", "{", "<")
        ']' -> listOf("]", ")", "}", ">")
        '-' -> listOf("-", "–", "—", "•")
        '_' -> listOf("_", "—", "–", "·")
        '+' -> listOf("+", "±")
        '/' -> listOf("/", "\\", "|")
        '|' -> listOf("|", "\\", "¦")
        '$' -> listOf("\$", "¢", "£", "€", "¥", "₹", "₽")
        '&' -> listOf("&", "§")
        '#' -> listOf("#", "№")
        '"' -> listOf("\"", "„", "“", "”", "«", "»")
        '\'' -> listOf("'", "‚", "‘", "’", "‹", "›")
        '!' -> listOf("!", "¡")
        '؟' -> listOf("؟", "?")
        ':' -> listOf(":", "…")
        '*' -> listOf("*", "★", "†", "‡")
        '=' -> listOf("=", "≠", "≈", "∞")
        '%' -> listOf("%", "‰")
        '°' -> listOf("°", "′", "″")
        '^' -> listOf("^", "↑", "←", "↓", "→")
        'π' -> listOf("π", "Ω", "µ")
        '•' -> listOf("•", "♪", "♥", "♦", "♣", "♠")
        '~' -> listOf("~", "≈")
        '£' -> listOf("£", "\$", "€")
        '€' -> listOf("€", "\$", "£")
        '¥' -> listOf("¥", "\$", "€")
        '{' -> listOf("{", "[", "(", "<")
        '}' -> listOf("}", "]", ")", ">")
        else -> emptyList()
    }

    private fun symKey(ch: Char): FrameLayout {
        val s = ch.toString()
        val v = symVariants(ch)
        return key(s, 1f, C_KEY, opts = v, onOpt = { commitOther(it) }, pre = if (v.isNotEmpty()) 0 else -1) {
            commitOther(s)
        }
    }

    private fun arabicIndic(d: Char): String =
        ('٠' + (d - '0')).toString()

    private fun digitOpts(d: Char): List<String> = when (d) {
        '0' -> listOf("0", "⁰", "ⁿ", "∅", "°")
        '1' -> listOf("1", "¹", "½", "⅓", "¼", "⅕", "⅙", "⅐", "⅛", "⅑", "⅒")
        '2' -> listOf("2", "²", "⅔", "⅖")
        '3' -> listOf("3", "³", "¾", "⅗", "⅜")
        '4' -> listOf("4", "⁴", "⅘")
        '5' -> listOf("5", "⁵", "⅚", "⅝")
        '6' -> listOf("6", "⁶")
        '7' -> listOf("7", "⁷", "⅞")
        '8' -> listOf("8", "⁸")
        '9' -> listOf("9", "⁹")
        else -> listOf(d.toString())
    }

    private fun digitKey(d: Char): FrameLayout {
        val list = ArrayList<String>(digitOpts(d))
        list.add(arabicIndic(d))
        return key(d.toString(), 1f, C_KEY, opts = list, onOpt = { commitOther(it) }, pre = 0) {
            commitOther(d.toString())
        }
    }

    private fun buildSym1(c: LinearLayout) {
        val r0 = newRow()
        for (d in "1234567890") {
            r0.addView(digitKey(d))
        }
        c.addView(r0)

        val r1 = newRow()
        for (ch in "@#\$_&-+()/") r1.addView(symKey(ch))
        c.addView(r1)

        val r2 = newRow()
        r2.addView(key("=\\<", 1.5f, C_FUNC, textSize = 14f) { go(L_SYM2) })
        for (ch in "*\"':؛!؟") r2.addView(symKey(ch))
        r2.addView(backKey())
        c.addView(r2)

        val b = newRow()
        b.addView(key("أبج", 1.4f, C_FUNC, textSize = 14f) { go(L_AR) })
        b.addView(key("،", 1f) { commitOther("،") })
        b.addView(key("12/34", 1f, C_FUNC, textSize = 12f) { go(L_NUM) })
        b.addView(spaceKey("العربية"))
        b.addView(dotKey())
        b.addView(enterKey())
        c.addView(b)
    }

    // ---------------- رموز 2 ----------------

    private fun buildSym2(c: LinearLayout) {
        val r0 = newRow()
        for (ch in "~`|•√π÷×§∆") r0.addView(symKey(ch))
        c.addView(r0)

        val r1 = newRow()
        for (ch in "£¢€¥^°={}\\") r1.addView(symKey(ch))
        c.addView(r1)

        val r2 = newRow()
        r2.addView(key("?١٢٣", 1.5f, C_FUNC, textSize = 14f) { go(L_SYM1) })
        for (ch in "%©®™✓[]") r2.addView(symKey(ch))
        r2.addView(backKey())
        c.addView(r2)

        val b = newRow()
        b.addView(key("أبج", 1.4f, C_FUNC, textSize = 14f) { go(L_AR) })
        b.addView(key("«", 1f) { commitOther("«") })
        b.addView(key("12/34", 1f, C_FUNC, textSize = 12f) { go(L_NUM) })
        b.addView(spaceKey("العربية"))
        b.addView(key("»", 1f) { commitOther("»") })
        b.addView(enterKey())
        c.addView(b)
    }

    // ---------------- لوحة الأرقام ----------------

    private fun numKey(label: String, weight: Float, color: String = C_KEY): FrameLayout =
        key(label, weight, color, textSize = 22f) { commitOther(label) }

    private fun buildNumpad(c: LinearLayout) {
        val ops = 0.8f
        val num = 1.4f

        val r0 = newRow()
        r0.addView(numKey("+", ops, C_FUNC))
        r0.addView(numKey("1", num))
        r0.addView(numKey("2", num))
        r0.addView(numKey("3", num))
        r0.addView(numKey("%", ops, C_FUNC))
        c.addView(r0)

        val r1 = newRow()
        r1.addView(numKey("-", ops, C_FUNC))
        r1.addView(numKey("4", num))
        r1.addView(numKey("5", num))
        r1.addView(numKey("6", num))
        r1.addView(key("␣", ops, C_FUNC) { commitOther(" ") })
        c.addView(r1)

        val r2 = newRow()
        r2.addView(numKey("*", ops, C_FUNC))
        r2.addView(numKey("7", num))
        r2.addView(numKey("8", num))
        r2.addView(numKey("9", num))
        r2.addView(key("⌫", ops, C_FUNC, autoRepeat = true) { doDelete() })
        c.addView(r2)

        val r3 = newRow()
        r3.addView(key("أبج", 1.2f, C_FUNC, textSize = 14f) { go(L_AR) })
        r3.addView(numKey("،", 0.9f))
        r3.addView(key("!?#", 1f, C_FUNC, textSize = 14f) { go(L_SYM1) })
        r3.addView(numKey("0", num))
        r3.addView(numKey("=", 0.9f))
        r3.addView(numKey(".", 0.9f))
        r3.addView(key("⏎", 1.2f, C_ACCENT) { doEnter() })
        c.addView(r3)
    }

    // ---------------- الحافظة ----------------

    private fun buildClipboard(c: LinearLayout) {
        val head = newRow()
        head.addView(key("أبج", 1.2f, C_FUNC, textSize = 14f) { go(L_AR) })
        val title = TextView(this)
        title.text = "الحافظة"
        title.setTextColor(Color.WHITE)
        title.textSize = 16f
        title.gravity = Gravity.CENTER
        title.layoutParams = LinearLayout.LayoutParams(0, dp(46), 3f)
        head.addView(title)
        head.addView(key("مسح الكل", 1.6f, C_FUNC, textSize = 13f) {
            clips.clear()
            saveClips()
            render()
        })
        c.addView(head)

        val scroll = ScrollView(this)
        scroll.layoutParams = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            dp(190)
        )
        val list = LinearLayout(this)
        list.orientation = LinearLayout.VERTICAL
        if (clips.isEmpty()) {
            val empty = TextView(this)
            empty.text = "انسخ أي نص وهيظهر هنا"
            empty.setTextColor(Color.parseColor("#B0B0B8"))
            empty.textSize = 15f
            empty.gravity = Gravity.CENTER
            empty.setPadding(dp(8), dp(40), dp(8), dp(8))
            list.addView(empty)
        } else {
            for (t in ArrayList(clips)) list.addView(clipItem(t))
        }
        scroll.addView(list)
        c.addView(scroll)
    }

    private fun clipItem(text: String): View {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.background = roundBg(C_KEY)
        val rlp = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )
        rlp.setMargins(dp(2), dp(3), dp(2), dp(3))
        row.layoutParams = rlp

        val tv = TextView(this)
        tv.text = text
        tv.setTextColor(Color.WHITE)
        tv.textSize = 15f
        tv.maxLines = 2
        tv.ellipsize = TextUtils.TruncateAt.END
        tv.setPadding(dp(12), dp(10), dp(12), dp(10))
        tv.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        tv.setOnClickListener {
            commitOther(text)
            go(L_AR)
        }

        val del = TextView(this)
        del.text = "✕"
        del.setTextColor(Color.parseColor("#B0B0B8"))
        del.textSize = 16f
        del.gravity = Gravity.CENTER
        del.setPadding(dp(14), dp(10), dp(14), dp(10))
        del.setOnClickListener {
            clips.remove(text)
            saveClips()
            render()
        }

        row.addView(tv)
        row.addView(del)
        return row
    }
}

// حاوية الكيبورد: بتقيس الكيبورد الأول، وبعدين بتخلي الخلفية والقوائم بنفس حجمه
private class KbFrame(c: Context) : FrameLayout(c) {
    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val col = getChildAt(2)
        measureChild(col, widthMeasureSpec, heightMeasureSpec)
        val w = resolveSize(col.measuredWidth, widthMeasureSpec)
        val h = resolveSize(col.measuredHeight, heightMeasureSpec)
        setMeasuredDimension(w, h)
        val ws = View.MeasureSpec.makeMeasureSpec(w, View.MeasureSpec.EXACTLY)
        val hs = View.MeasureSpec.makeMeasureSpec(h, View.MeasureSpec.EXACTLY)
        for (i in 0 until childCount) {
            if (i != 2) getChildAt(i).measure(ws, hs)
        }
    }
}
