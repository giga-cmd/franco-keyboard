package com.franco.keyboard

import android.app.Activity
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Outline
import android.graphics.drawable.GradientDrawable
import android.media.ExifInterface
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import java.io.File
import java.io.FileOutputStream

class SettingsActivity : Activity() {

    private lateinit var prefs: SharedPreferences
    private lateinit var previewImg: ImageView
    private lateinit var previewScrim: View
    private val sampleKeys = ArrayList<TextView>()
    private val reqPick = 41
    private val reqVideo = 42
    private var resetAsk = 0L
    private var allResetAsk = 0L
    private lateinit var bgStatus: TextView
    private lateinit var content: LinearLayout
    private val tabViews = ArrayList<TextView>()
    private val themeKeys = listOf("#3C3C45", "#2F4A78", "#2F5E3F", "#533A78", "#6E2F36", "#7A3A5E")

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun button(text: String, action: () -> Unit): TextView {
        val b = TextView(this)
        b.text = text
        b.setTextColor(Color.WHITE)
        b.textSize = 16f
        b.gravity = Gravity.CENTER
        val g = GradientDrawable()
        g.cornerRadius = dp(24).toFloat()
        g.setColor(Color.parseColor("#B33F51B5"))
        g.setStroke(dp(1), Color.parseColor("#80FFFFFF"))
        b.background = g
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(48))
        lp.setMargins(0, dp(6), 0, dp(6))
        b.layoutParams = lp
        b.setOnClickListener { action() }
        return b
    }

    private fun label(text: String): TextView {
        val t = TextView(this)
        t.text = text
        t.setTextColor(Color.WHITE)
        t.textSize = 15f
        t.setShadowLayer(6f, 0f, 0f, Color.BLACK)
        t.setPadding(0, dp(12), 0, dp(2))
        return t
    }

    private fun card(): LinearLayout {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        val g = GradientDrawable()
        g.cornerRadius = dp(16).toFloat()
        g.setColor(Color.parseColor("#66000000"))
        c.background = g
        c.setPadding(dp(14), dp(6), dp(14), dp(10))
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.setMargins(0, dp(6), 0, dp(6))
        c.layoutParams = lp
        return c
    }

    private fun slider(
        parent: LinearLayout,
        title: String,
        key: String,
        min: Int,
        max: Int,
        def: Int
    ) {
        parent.addView(label(title))
        val sb = SeekBar(this)
        sb.max = max - min
        sb.progress = prefs.getInt(key, def) - min
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                prefs.edit().putInt(key, p + min).apply()
                updatePreviewLook()
            }

            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        parent.addView(
            sb,
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
        )
    }

    // سطر تشغيل/إيقاف
    private fun switchRow(parent: LinearLayout, title: String, key: String, def: Boolean, sub: String? = null) {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(0, dp(8), 0, dp(8))
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        val t = TextView(this)
        t.text = title
        t.setTextColor(Color.WHITE)
        t.textSize = 16f
        col.addView(t)
        if (sub != null) {
            val s = TextView(this)
            s.text = sub
            s.setTextColor(Color.parseColor("#B0FFFFFF"))
            s.textSize = 12f
            col.addView(s)
        }
        row.addView(col, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val sw = Switch(this)
        sw.isChecked = prefs.getBoolean(key, def)
        sw.setOnCheckedChangeListener { _, on ->
            prefs.edit().putBoolean(key, on).apply()
        }
        row.addView(sw)
        parent.addView(row)
    }

    // اختيار من كام اختيار (أزرار جنب بعض)
    private fun segment(
        parent: LinearLayout,
        title: String,
        labels: List<String>,
        get: () -> Int,
        set: (Int) -> Unit
    ) {
        parent.addView(label(title))
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        val views = ArrayList<TextView>()
        fun paint() {
            for ((i, v) in views.withIndex()) {
                val g = GradientDrawable()
                g.cornerRadius = dp(18).toFloat()
                g.setColor(Color.parseColor(if (i == get()) "#B33F51B5" else "#55FFFFFF"))
                v.background = g
            }
        }
        for ((i, l) in labels.withIndex()) {
            val v = TextView(this)
            v.text = l
            v.setTextColor(Color.WHITE)
            v.textSize = 14f
            v.gravity = Gravity.CENTER
            val lp = LinearLayout.LayoutParams(0, dp(40), 1f)
            lp.setMargins(dp(2), dp(4), dp(2), dp(4))
            v.layoutParams = lp
            v.setOnClickListener {
                set(i)
                paint()
                updatePreviewLook()
            }
            views.add(v)
            row.addView(v)
        }
        paint()
        parent.addView(row)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("franco", MODE_PRIVATE)
        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.BLACK
        window.decorView.systemUiVisibility =
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN

        val root = FrameLayout(this)
        val bg = ImageView(this)
        bg.setImageResource(R.drawable.bg)
        bg.scaleType = ImageView.ScaleType.CENTER_CROP
        root.addView(bg, FrameLayout.LayoutParams(-1, -1))
        val sc = View(this)
        sc.setBackgroundColor(Color.parseColor("#80000000"))
        root.addView(sc, FrameLayout.LayoutParams(-1, -1))

        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(16), dp(48), dp(16), dp(8))

        val title = TextView(this)
        title.text = "إعدادات الكيبورد"
        title.setTextColor(Color.WHITE)
        title.textSize = 22f
        title.gravity = Gravity.CENTER
        title.setShadowLayer(8f, 0f, 0f, Color.BLACK)
        title.setPadding(0, 0, 0, dp(10))
        col.addView(title)

        // التبويبات
        val tabs = LinearLayout(this)
        tabs.orientation = LinearLayout.HORIZONTAL
        tabs.layoutDirection = View.LAYOUT_DIRECTION_RTL
        val names = listOf("المظهر", "الكتابة", "صوت واهتزاز", "بيانات")
        for ((i, n) in names.withIndex()) {
            val t = TextView(this)
            t.text = n
            t.setTextColor(Color.WHITE)
            t.textSize = 14f
            t.gravity = Gravity.CENTER
            val lp = LinearLayout.LayoutParams(0, dp(40), 1f)
            lp.setMargins(dp(2), 0, dp(2), 0)
            t.layoutParams = lp
            t.setOnClickListener { showTab(i) }
            tabViews.add(t)
            tabs.addView(t)
        }
        col.addView(tabs)

        content = LinearLayout(this)
        content.orientation = LinearLayout.VERTICAL
        content.setPadding(0, dp(6), 0, dp(24))
        val scroll = ScrollView(this)
        scroll.addView(content)
        col.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        root.addView(col, FrameLayout.LayoutParams(-1, -1))
        setContentView(root)
        showTab(0)
    }

    private fun showTab(i: Int) {
        for ((k, v) in tabViews.withIndex()) {
            val g = GradientDrawable()
            g.cornerRadius = dp(20).toFloat()
            g.setColor(Color.parseColor(if (k == i) "#B33F51B5" else "#44FFFFFF"))
            v.background = g
        }
        content.removeAllViews()
        when (i) {
            0 -> buildLook(content)
            1 -> buildTyping(content)
            2 -> buildFeel(content)
            else -> buildData(content)
        }
    }

    // ---------------- المظهر ----------------

    private fun buildLook(c: LinearLayout) {
        val prev = FrameLayout(this)
        prev.setBackgroundColor(Color.parseColor("#1B1B1F"))
        prev.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                outline.setRoundRect(0, 0, view.width, view.height, dp(16).toFloat())
            }
        }
        prev.clipToOutline = true
        previewImg = ImageView(this)
        previewImg.scaleType = ImageView.ScaleType.CENTER_CROP
        prev.addView(previewImg, FrameLayout.LayoutParams(-1, -1))
        previewScrim = View(this)
        prev.addView(previewScrim, FrameLayout.LayoutParams(-1, -1))
        val keys = LinearLayout(this)
        keys.orientation = LinearLayout.HORIZONTAL
        keys.layoutDirection = View.LAYOUT_DIRECTION_LTR
        keys.setPadding(dp(6), 0, dp(6), 0)
        sampleKeys.clear()
        for (ch in listOf("ج", "ح", "خ", "ه", "ع", "غ")) {
            val t = TextView(this)
            t.text = ch
            t.setTextColor(Color.WHITE)
            t.textSize = 20f
            t.gravity = Gravity.CENTER
            val g = GradientDrawable()
            g.cornerRadius = dp(8).toFloat()
            g.setColor(Color.parseColor("#3C3C45"))
            t.background = g
            val lp = LinearLayout.LayoutParams(0, dp(46), 1f)
            lp.setMargins(dp(2), 0, dp(2), 0)
            t.layoutParams = lp
            keys.addView(t)
            sampleKeys.add(t)
        }
        prev.addView(keys, FrameLayout.LayoutParams(-1, -2, Gravity.CENTER))
        c.addView(prev, LinearLayout.LayoutParams(-1, dp(150)))

        val bgc = card()
        bgc.addView(button("اختيار صورة للكيبورد") { pickImage() })
        bgc.addView(button("اختيار فيديو للخلفية (لحد 10 ثواني)") { pickVideo() })
        bgStatus = TextView(this)
        bgStatus.setTextColor(Color.parseColor("#CCFFFFFF"))
        bgStatus.textSize = 13f
        bgStatus.gravity = Gravity.CENTER
        bgc.addView(bgStatus)
        bgc.addView(button("مسح الخلفية (صورة أو فيديو)") {
            val now = System.currentTimeMillis()
            if (now - resetAsk > 3500) {
                resetAsk = now
                Toast.makeText(this, "دوس تاني للتأكيد", Toast.LENGTH_SHORT).show()
            } else {
                resetAsk = 0L
                File(filesDir, "kb_bg.jpg").delete()
                File(filesDir, "kb_bg.mp4").delete()
                prefs.edit().putString("bg_type", "image").apply()
                loadPreviewImage()
                updatePreviewLook()
                refreshBgStatus()
                Toast.makeText(this, "اتمسحت", Toast.LENGTH_SHORT).show()
            }
        })
        slider(bgc, "تغميق الخلفية", "bg_dim", 0, 90, 35)
        c.addView(bgc)

        val kc = card()
        segment(
            kc, "لون الزراير",
            listOf("افتراضي", "أزرق", "أخضر", "بنفسجي", "أحمر", "وردي"),
            { prefs.getInt("theme", 0) },
            { prefs.edit().putInt("theme", it).apply() }
        )
        slider(kc, "شفافية الزراير (مع الخلفية)", "key_alpha", 20, 100, 60)
        slider(kc, "حجم حروف الكيبورد", "key_text", 12, 28, 18)
        slider(kc, "حجم مربع الحرف", "key_box_size", 50, 100, 100)
        switchRow(kc, "المربع حوالين الحرف", "key_box", true, "لو قفلته الحرف بيفضل ظاهر من غير مربع")
        switchRow(kc, "الأرقام الصغيرة فوق الحروف", "hints", true)
        kc.addView(button("تغيير حجم الكيبورد") {
            startActivity(Intent(this, ResizeActivity::class.java))
        })
        c.addView(kc)

        loadPreviewImage()
        updatePreviewLook()
        refreshBgStatus()
    }

    // ---------------- الكتابة ----------------

    private fun buildTyping(c: LinearLayout) {
        val a = card()
        switchRow(a, "التصحيح التلقائي", "autocorrect", true)
        switchRow(a, "التصحيح الأونلاين", "online", true, "بيبعت الكلمة نفسها بس لـ LanguageTool، ومبيتبعتش في خانات الباسورد")
        switchRow(a, "اقتراح الكلمات", "sug_on", true)
        switchRow(a, "التعلّم من كلامك", "learn_on", true, "بيحفظ الكلمات اللي بتكتبها كتير على الموبايل بس")
        c.addView(a)

        val b = card()
        switchRow(b, "أول حرف كبير بعد النقطة", "autocap", true, "في الإنجليزي")
        switchRow(b, "مسافتين = نقطة", "dblspace", false)
        switchRow(b, "يبدأ بوضع فرانكو", "franco_start", true, "بيتطبق لما الكيبورد يشتغل من أول وجديد")
        c.addView(b)

        val d = card()
        val langs = listOf("ar-EG", "ar-SA", "en-US")
        segment(
            d, "لغة الكتابة بالصوت (🎤)",
            listOf("مصري", "سعودي", "إنجليزي"),
            { langs.indexOf(prefs.getString("voice_lang", "ar-EG")).coerceAtLeast(0) },
            { prefs.edit().putString("voice_lang", langs[it]).apply() }
        )
        c.addView(d)
        c.addView(noteText("التغييرات بتظهر أول ما تفتح الكيبورد تاني."))
    }

    // ---------------- صوت واهتزاز ----------------

    private fun buildFeel(c: LinearLayout) {
        val a = card()
        switchRow(a, "اهتزاز عند الضغط", "vib", false)
        segment(
            a, "قوة الاهتزاز",
            listOf("خفيف", "متوسط", "قوي"),
            { prefs.getInt("vib_str", 2) - 1 },
            { prefs.edit().putInt("vib_str", it + 1).apply() }
        )
        c.addView(a)

        val b = card()
        switchRow(b, "صوت عند الضغط", "snd", false, "بيتبع صوت الموبايل وإعدادات الصوت فيه")
        slider(b, "مستوى الصوت", "snd_vol", 10, 100, 60)
        c.addView(b)

        val d = card()
        slider(d, "مدة الضغط الطويل (بالملي ثانية)", "lp_ms", 200, 600, 350)
        c.addView(d)
        c.addView(noteText("التغييرات بتظهر أول ما تفتح الكيبورد تاني."))
    }

    // ---------------- بيانات ----------------

    private fun buildData(c: LinearLayout) {
        val a = card()
        switchRow(a, "الحافظة", "clip_on", true, "حفظ اللي بتنسخه وإظهاره في الشريط فوق")
        slider(a, "أقصى عدد للنسخ المحفوظة", "clip_max", 10, 100, 30)
        c.addView(a)

        val b = card()
        b.addView(button("مسح الكلمات اللي الكيبورد اتعلمها") {
            prefs.edit().remove("uni").remove("bi").apply()
            Toast.makeText(this, "اتمسحت", Toast.LENGTH_SHORT).show()
        })
        b.addView(button("إعادة ضبط كل الإعدادات") {
            val now = System.currentTimeMillis()
            if (now - allResetAsk > 3500) {
                allResetAsk = now
                Toast.makeText(this, "دوس تاني للتأكيد", Toast.LENGTH_SHORT).show()
            } else {
                allResetAsk = 0L
                val e = prefs.edit()
                for (k in listOf(
                    "bg_dim", "key_alpha", "key_text", "key_box", "key_box_size", "hints", "theme",
                    "autocorrect", "online", "sug_on", "learn_on", "autocap", "dblspace",
                    "franco_start", "voice_lang", "vib", "vib_str", "snd", "snd_vol", "lp_ms",
                    "clip_on", "clip_max", "kb_h", "kb_l", "kb_r"
                )) e.remove(k)
                e.apply()
                Toast.makeText(this, "اترجعت الإعدادات (الخلفية والحافظة زي ما هي)", Toast.LENGTH_LONG).show()
                showTab(3)
            }
        })
        c.addView(b)

        val about = card()
        val t = TextView(this)
        t.text = "Franco keyboard\nTelegram: @GIGA_UP    Discord: giga_up"
        t.setTextColor(Color.parseColor("#CCFFFFFF"))
        t.textSize = 13f
        t.gravity = Gravity.CENTER
        t.setPadding(0, dp(10), 0, dp(10))
        about.addView(t)
        c.addView(about)
    }

    private fun noteText(s: String): TextView {
        val note = TextView(this)
        note.text = s
        note.setTextColor(Color.parseColor("#CCFFFFFF"))
        note.textSize = 13f
        note.gravity = Gravity.CENTER
        note.setPadding(0, dp(12), 0, 0)
        return note
    }

    private fun loadPreviewImage() {
        val f = File(filesDir, "kb_bg.jpg")
        if (f.exists()) {
            try {
                previewImg.setImageBitmap(BitmapFactory.decodeFile(f.path))
            } catch (e: Throwable) {
                previewImg.setImageDrawable(null)
            }
        } else {
            previewImg.setImageDrawable(null)
        }
    }

    private fun updatePreviewLook() {
        val has = File(filesDir, "kb_bg.jpg").exists() ||
            (prefs.getString("bg_type", "image") == "video" && File(filesDir, "kb_bg.mp4").exists())
        val dim = prefs.getInt("bg_dim", 35)
        previewScrim.setBackgroundColor(Color.argb(if (has) dim * 255 / 100 else 0, 0, 0, 0))
        val a = if (has) prefs.getInt("key_alpha", 60) * 255 / 100 else 255
        for (t in sampleKeys) {
            val tc = Color.parseColor(themeKeys[prefs.getInt("theme", 0).coerceIn(0, themeKeys.size - 1)])
            (t.background as GradientDrawable).setColor(Color.argb(a, Color.red(tc), Color.green(tc), Color.blue(tc)))
        }
    }

    private fun refreshBgStatus() {
        val type = prefs.getString("bg_type", "image")
        val hasV = File(filesDir, "kb_bg.mp4").exists()
        val hasI = File(filesDir, "kb_bg.jpg").exists()
        bgStatus.text = when {
            type == "video" && hasV -> "الخلفية الحالية: فيديو ✓"
            hasI -> "الخلفية الحالية: صورة ✓"
            else -> "الخلفية الحالية: مفيش"
        }
    }

    private fun pickVideo() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.type = "video/*"
        try {
            startActivityForResult(i, reqVideo)
        } catch (e: Exception) {
            Toast.makeText(this, "مفيش تطبيق معرض فيديو", Toast.LENGTH_SHORT).show()
        }
    }

    // نسخ الفيديو لمخزن التطبيق (لحد 10 ثواني و40 ميجا)
    private fun saveVideo(uri: Uri): String? {
        val tmp = File(filesDir, "kb_bg_tmp.mp4")
        try {
            var total = 0L
            contentResolver.openInputStream(uri)?.use { ins ->
                FileOutputStream(tmp).use { out ->
                    val buf = ByteArray(64 * 1024)
                    while (true) {
                        val n = ins.read(buf)
                        if (n <= 0) break
                        total += n
                        if (total > 40L * 1024 * 1024) {
                            tmp.delete()
                            return "الفيديو كبير (أكتر من 40 ميجا)"
                        }
                        out.write(buf, 0, n)
                    }
                }
            } ?: return "الفيديو ماتفتحش"
            val r = MediaMetadataRetriever()
            val ms: Long
            try {
                r.setDataSource(tmp.path)
                ms = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
            } finally {
                try {
                    r.release()
                } catch (e: Throwable) {
                    // مش مهم
                }
            }
            if (ms <= 0L) {
                tmp.delete()
                return "الفيديو ده مش شغال"
            }
            if (ms > 10500L) {
                tmp.delete()
                return "الفيديو أطول من 10 ثواني"
            }
            val f = File(filesDir, "kb_bg.mp4")
            f.delete()
            if (!tmp.renameTo(f)) {
                tmp.delete()
                return "ماقدرتش أحفظ الفيديو"
            }
            f.setLastModified(System.currentTimeMillis())
            prefs.edit().putString("bg_type", "video").apply()
            return null
        } catch (e: Throwable) {
            tmp.delete()
            return "الفيديو ماتفتحش"
        }
    }

    private fun pickImage() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.type = "image/*"
        try {
            startActivityForResult(i, reqPick)
        } catch (e: Exception) {
            Toast.makeText(this, "مفيش تطبيق معرض صور", Toast.LENGTH_SHORT).show()
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        if (requestCode == reqVideo) {
            Toast.makeText(this, "بحفظ الفيديو...", Toast.LENGTH_SHORT).show()
            Thread {
                val err = saveVideo(uri)
                runOnUiThread {
                    if (err == null) {
                        refreshBgStatus()
                        Toast.makeText(this, "تم حفظ فيديو الخلفية", Toast.LENGTH_SHORT).show()
                    } else {
                        Toast.makeText(this, err, Toast.LENGTH_LONG).show()
                    }
                }
            }.start()
            return
        }
        if (requestCode != reqPick) return
        Thread {
            val ok = saveImage(uri)
            runOnUiThread {
                if (ok) {
                    prefs.edit().putString("bg_type", "image").apply()
                    File(filesDir, "kb_bg.mp4").delete()
                    refreshBgStatus()
                    loadPreviewImage()
                    updatePreviewLook()
                    Toast.makeText(this, "تم حفظ الخلفية", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(this, "الصورة دي ماتفتحتش", Toast.LENGTH_SHORT).show()
                }
            }
        }.start()
    }

    private fun saveImage(uri: Uri): Boolean {
        try {
            val bounds = BitmapFactory.Options()
            bounds.inJustDecodeBounds = true
            contentResolver.openInputStream(uri)?.use {
                BitmapFactory.decodeStream(it, null, bounds)
            }
            var sample = 1
            while (bounds.outWidth / sample > 1800 || bounds.outHeight / sample > 1800) {
                sample *= 2
            }
            val opts = BitmapFactory.Options()
            opts.inSampleSize = sample
            var bmp: Bitmap = contentResolver.openInputStream(uri)?.use {
                BitmapFactory.decodeStream(it, null, opts)
            } ?: return false

            var rot = 0
            try {
                contentResolver.openInputStream(uri)?.use {
                    val ex = ExifInterface(it)
                    val o = ex.getAttributeInt(
                        ExifInterface.TAG_ORIENTATION,
                        ExifInterface.ORIENTATION_NORMAL
                    )
                    if (o == ExifInterface.ORIENTATION_ROTATE_90) rot = 90
                    if (o == ExifInterface.ORIENTATION_ROTATE_180) rot = 180
                    if (o == ExifInterface.ORIENTATION_ROTATE_270) rot = 270
                }
            } catch (e: Throwable) {
                rot = 0
            }
            if (rot != 0) {
                val m = Matrix()
                m.postRotate(rot.toFloat())
                bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
            }

            val f = File(filesDir, "kb_bg.jpg")
            FileOutputStream(f).use {
                bmp.compress(Bitmap.CompressFormat.JPEG, 88, it)
            }
            f.setLastModified(System.currentTimeMillis())
            return true
        } catch (e: Throwable) {
            return false
        }
    }
}
