package com.franco.keyboard

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL

// رسالة في المحادثة: role = "user" أو "ai"، والصورة (اختيارية) base64 JPEG
class AiMsg(val role: String, val text: String, val img: String? = null)

class AiResult(val text: String?, val error: String?)

object AiClient {

    const val SYS_SUM = "انت بتلخّص نصوص جوه كيبورد موبايل. لخّص النص اللي هيجيلك في فقرة أو اتنين مترابطين وسلسين (مش نقط ولا عناوين). شيل التكرار والتفاصيل الجانبية واحتفظ بكل الأفكار الأساسية والأسماء والأرقام والتواريخ زي ما هي. مسموح تستخدم كلمات ربط بسيطة من عندك (زي: وبعدين، عشان كده، لكن، في الآخر) عشان الكلام يتسلسل ويبان طبيعي، بس متضيفش أي معلومة أو رأي مش موجود في النص ومتغيّرش المعنى. اكتب بنفس لغة ولهجة النص بالظبط. رجّع الملخص بس من غير أي مقدمة أو تعليق."
    const val SYS_OCR = "اقرا كل الكلام المكتوب في الصورة بالظبط زي ما هو، سطر بسطر، من غير شرح ولا إضافات. لو مفيش كلام اكتب: (مفيش كلام)."

    fun encodeImage(ctx: Context, uri: Uri): String? {
        return try {
            val bo = BitmapFactory.Options()
            bo.inJustDecodeBounds = true
            ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bo) }
            var s = 1
            val big = maxOf(bo.outWidth, bo.outHeight)
            while (big / s > 1600) s *= 2
            val o2 = BitmapFactory.Options()
            o2.inSampleSize = s
            val bmp = ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o2) }
                ?: return null
            val out = ByteArrayOutputStream()
            bmp.compress(Bitmap.CompressFormat.JPEG, 82, out)
            bmp.recycle()
            Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)
        } catch (e: Throwable) {
            null
        }
    }

    fun ask(ctx: Context, msgs: List<AiMsg>, system: String): AiResult {
        val p = ctx.getSharedPreferences("franco", Context.MODE_PRIVATE)
        val key = (p.getString("ai_key", "") ?: "").trim()
        if (key.isEmpty()) return AiResult(null, "حط مفتاح الـ AI في الإعدادات الأول")
        val claude = p.getInt("ai_provider", 0) == 1
        return try {
            if (claude) askClaude(key, p.getString("ai_model", "")?.trim().orEmpty(), msgs, system)
            else askGemini(key, p.getString("ai_model", "")?.trim().orEmpty(), msgs, system)
        } catch (e: Throwable) {
            AiResult(null, "مفيش نت أو السيرفر مردش (" + (e.message ?: e.javaClass.simpleName).take(60) + ")")
        }
    }

    // الصورة بتتبعت مع آخر رسالة فيها صورة بس (عشان الحجم)
    private fun lastImgIndex(msgs: List<AiMsg>): Int {
        for (i in msgs.indices.reversed()) if (msgs[i].img != null) return i
        return -1
    }

    private fun post(url: String, headers: Map<String, String>, body: String): Pair<Int, String> {
        val c = URL(url).openConnection() as HttpURLConnection
        c.requestMethod = "POST"
        c.connectTimeout = 15000
        c.readTimeout = 60000
        c.doOutput = true
        c.setRequestProperty("Content-Type", "application/json; charset=utf-8")
        for ((k, v) in headers) c.setRequestProperty(k, v)
        c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
        val code = c.responseCode
        val stream = if (code in 200..299) c.inputStream else c.errorStream
        val txt = stream?.bufferedReader(Charsets.UTF_8)?.readText() ?: ""
        c.disconnect()
        return Pair(code, txt)
    }

    private fun httpError(code: Int, body: String = ""): String {
        val base = when (code) {
            400 -> "الطلب اترفض (ممكن المفتاح أو الموديل غلط)"
            401, 403 -> "المفتاح غلط أو مش شغال"
            404 -> "اسم الموديل غلط"
            429 -> "عدّيت الحد المسموح، جرب كمان شوية"
            else -> "السيرفر رجّع خطأ ($code)"
        }
        val detail = try {
            JSONObject(body).optJSONObject("error")?.optString("message", "")?.trim().orEmpty()
        } catch (e: Throwable) {
            ""
        }
        return if (detail.isEmpty()) base else base + "\n" + detail.take(120)
    }

    private fun askGemini(key: String, model0: String, msgs: List<AiMsg>, system: String): AiResult {
        val model = if (model0.isEmpty()) "gemini-flash-latest" else model0
        val li = lastImgIndex(msgs)
        val contents = JSONArray()
        for ((i, m) in msgs.withIndex()) {
            val parts = JSONArray()
            if (m.img != null && i == li) {
                parts.put(JSONObject().put("inline_data", JSONObject().put("mime_type", "image/jpeg").put("data", m.img)))
            }
            parts.put(JSONObject().put("text", if (m.text.isEmpty()) "." else m.text))
            contents.put(
                JSONObject().put("role", if (m.role == "ai") "model" else "user").put("parts", parts)
            )
        }
        val body = JSONObject()
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system))))
            .put("contents", contents)
            .toString()
        val r = post(
            "https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent",
            mapOf("x-goog-api-key" to key), body
        )
        if (r.first !in 200..299) return AiResult(null, httpError(r.first, r.second))
        val cands = JSONObject(r.second).optJSONArray("candidates")
        val parts = cands?.optJSONObject(0)?.optJSONObject("content")?.optJSONArray("parts")
        val sb = StringBuilder()
        if (parts != null) for (i in 0 until parts.length()) sb.append(parts.optJSONObject(i)?.optString("text", "") ?: "")
        val out = sb.toString().trim()
        return if (out.isEmpty()) AiResult(null, "مفيش رد (ممكن الرد اتحجب)") else AiResult(out, null)
    }

    private fun askClaude(key: String, model0: String, msgs: List<AiMsg>, system: String): AiResult {
        val model = if (model0.isEmpty()) "claude-haiku-5-5" else model0
        val li = lastImgIndex(msgs)
        val arr = JSONArray()
        for ((i, m) in msgs.withIndex()) {
            val content = JSONArray()
            if (m.img != null && i == li) {
                content.put(
                    JSONObject().put("type", "image").put(
                        "source",
                        JSONObject().put("type", "base64").put("media_type", "image/jpeg").put("data", m.img)
                    )
                )
            }
            content.put(JSONObject().put("type", "text").put("text", if (m.text.isEmpty()) "." else m.text))
            arr.put(JSONObject().put("role", if (m.role == "ai") "assistant" else "user").put("content", content))
        }
        val body = JSONObject()
            .put("model", model)
            .put("max_tokens", 2000)
            .put("system", system)
            .put("messages", arr)
            .toString()
        val r = post(
            "https://api.anthropic.com/v1/messages",
            mapOf("x-api-key" to key, "anthropic-version" to "2023-06-01"), body
        )
        if (r.first !in 200..299) return AiResult(null, httpError(r.first, r.second))
        val cont = JSONObject(r.second).optJSONArray("content")
        val sb = StringBuilder()
        if (cont != null) for (i in 0 until cont.length()) {
            val o = cont.optJSONObject(i) ?: continue
            if (o.optString("type") == "text") sb.append(o.optString("text", ""))
        }
        val out = sb.toString().trim()
        return if (out.isEmpty()) AiResult(null, "مفيش رد") else AiResult(out, null)
    }
}
