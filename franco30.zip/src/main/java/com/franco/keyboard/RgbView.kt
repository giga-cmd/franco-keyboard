package com.franco.keyboard

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.SweepGradient
import android.os.SystemClock
import android.view.View

// إضاءة RGB: إطار ملوّن بيلف حوالين الكيبورد، وموجة ألوان مكان الضغطة
// الـ View ده مبياخدش اللمس (اللمس بيعدّي للكيبورد)
class RgbView(c: Context) : View(c) {
    var border = false
    var press = false

    private class Pulse(val x: Float, val y: Float, val t0: Long, val hue: Float)

    private val pulses = ArrayList<Pulse>()
    private var counter = 0
    private val d = resources.displayMetrics.density
    private val strokeP = Paint(Paint.ANTI_ALIAS_FLAG)
    private val fillP = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()
    private val mtx = Matrix()
    private var sweep: SweepGradient? = null
    private var sw = 0
    private var sh = 0
    private val hsv = FloatArray(3)

    init {
        strokeP.style = Paint.Style.STROKE
        fillP.style = Paint.Style.FILL
    }

    fun pulse(rawX: Float, rawY: Float) {
        if (!press || rawX < 0f) return
        val loc = IntArray(2)
        getLocationOnScreen(loc)
        val now = SystemClock.uptimeMillis()
        counter++
        val hue = ((now / 6L) % 360L).toFloat() + counter * 37f
        pulses.add(Pulse(rawX - loc[0], rawY - loc[1], now, hue % 360f))
        if (pulses.size > 12) pulses.removeAt(0)
        postInvalidateOnAnimation()
    }

    private fun hueColor(h: Float, a: Int): Int {
        hsv[0] = ((h % 360f) + 360f) % 360f
        hsv[1] = 1f
        hsv[2] = 1f
        return Color.HSVToColor(a, hsv)
    }

    override fun onDraw(canvas: Canvas) {
        val now = SystemClock.uptimeMillis()
        var again = false
        if (border && width > 0 && height > 0) {
            if (sweep == null || sw != width || sh != height) {
                sw = width
                sh = height
                val cols = IntArray(8) { Color.HSVToColor(floatArrayOf(it * 45f, 1f, 1f)) }
                cols[7] = cols[0]
                val pos = FloatArray(8) { it / 7f }
                sweep = SweepGradient(width / 2f, height / 2f, cols, pos)
            }
            val ang = (now % 3000L) / 3000f * 360f
            mtx.setRotate(ang, width / 2f, height / 2f)
            sweep?.setLocalMatrix(mtx)
            strokeP.shader = sweep
            rect.set(0f, 0f, width.toFloat(), height.toFloat())
            val r = 14f * d
            strokeP.alpha = 70
            strokeP.strokeWidth = 7f * d
            rect.inset(3.5f * d, 3.5f * d)
            canvas.drawRoundRect(rect, r, r, strokeP)
            strokeP.alpha = 255
            strokeP.strokeWidth = 2.5f * d
            rect.inset(-2.25f * d, -2.25f * d)
            canvas.drawRoundRect(rect, r, r, strokeP)
            strokeP.shader = null
            again = true
        }
        if (pulses.isNotEmpty()) {
            val it = pulses.iterator()
            while (it.hasNext()) {
                val p = it.next()
                val t = (now - p.t0) / 520f
                if (t >= 1f) {
                    it.remove()
                    continue
                }
                val rad = (10f + 62f * t) * d
                val a = ((1f - t) * 255).toInt()
                fillP.color = hueColor(p.hue, (a * 0.28f).toInt())
                canvas.drawCircle(p.x, p.y, rad, fillP)
                strokeP.shader = null
                strokeP.strokeWidth = 3f * d
                strokeP.color = hueColor(p.hue + t * 60f, a)
                canvas.drawCircle(p.x, p.y, rad, strokeP)
                again = true
            }
        }
        if (again) postInvalidateOnAnimation()
    }

    fun applyState(b: Boolean, p: Boolean) {
        border = b
        press = p
        if (!p) pulses.clear()
        visibility = if (b || p) VISIBLE else GONE
        invalidate()
    }
}
