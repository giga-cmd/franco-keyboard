package com.franco.keyboard

import android.app.Activity
import android.content.pm.PackageManager
import android.os.Build
import android.provider.UserDictionary
import android.provider.OpenableColumns
import android.graphics.Typeface
import java.io.BufferedInputStream
import java.io.BufferedReader
import java.io.InputStreamReader
import java.util.zip.ZipInputStream
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Outline
import android.graphics.drawable.GradientDrawable
import android.media.ExifInterface
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import java.io.File
import java.io.FileOutputStream

class SettingsActivity : Activity() {

    private lateinit var prefs: SharedPreferences
    private lateinit var previewImg: ImageView
    private lateinit var previewScrim: View
    private val sampleKeys = ArrayList<TextView>()
    private val reqPick = 41
    private val reqVideo = 42
    private val reqText = 43
    private val reqDict = 51
    private val reqBackup = 71
    private val reqRestore = 72
    private val reqFont = 61
    private var resetAsk = 0L
    private var allResetAsk = 0L
    private lateinit var bgStatus: TextView
    private lateinit var content: LinearLayout
    private val tabViews = ArrayList<TextView>()
    private val themeKeys = listOf("#3C3C45", "#2F4A78", "#2F5E3F", "#533A78", "#6E2F36", "#7A3A5E", "#0E0E10", "#F4F4F6")

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun button(text: String, action: () -> Unit): TextView {
        val b = TextView(this)
        b.text = text
        b.setTextColor(Color.WHITE)
        b.textSize = 16f
        b.gravity = Gravity.CENTER
        val g = GradientDrawable()
        g.cornerRadius = dp(24).toFloat()
        g.setColor(Color.parseColor("#B33F51B5"))
        g.setStroke(dp(1), Color.parseColor("#80FFFFFF"))
        b.background = g
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(48))
        lp.setMargins(0, dp(6), 0, dp(6))
        b.layoutParams = lp
        b.setOnClickListener { action() }
        return b
    }

    private fun subText(s: String): TextView {
        val v = TextView(this)
        v.text = s
        v.setTextColor(Color.parseColor("#B0FFFFFF"))
        v.textSize = 12f
        return v
    }

    private fun label(text: String): TextView {
        val t = TextView(this)
        t.text = text
        t.setTextColor(Color.WHITE)
        t.textSize = 15f
        t.setShadowLayer(6f, 0f, 0f, Color.BLACK)
        t.setPadding(0, dp(12), 0, dp(2))
        return t
    }

    private fun card(): LinearLayout {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        val g = GradientDrawable()
        g.cornerRadius = dp(16).toFloat()
        g.setColor(Color.parseColor("#66000000"))
        c.background = g
        c.setPadding(dp(14), dp(6), dp(14), dp(10))
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.setMargins(0, dp(6), 0, dp(6))
        c.layoutParams = lp
        return c
    }

    private fun slider(
        parent: LinearLayout,
        title: String,
        key: String,
        min: Int,
        max: Int,
        def: Int,
        unit: String = "",
        sub: String? = null
    ) {
        val head = LinearLayout(this)
        head.orientation = LinearLayout.HORIZONTAL
        head.addView(label(title), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val vt = label("")
        vt.setTextColor(Color.parseColor("#80CBC4"))
        vt.setPadding(dp(8), dp(12), 0, dp(2))
        head.addView(vt, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        parent.addView(head)
        if (sub != null) parent.addView(subText(sub))
        val sb = SeekBar(this)
        sb.max = max - min
        sb.progress = prefs.getInt(key, def) - min
        vt.text = "" + (sb.progress + min) + unit
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                vt.text = "" + (p + min) + unit
                prefs.edit().putInt(key, p + min).apply()
                updatePreviewLook()
            }

            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        parent.addView(
            sb,
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
        )
    }

    // سطر تشغيل/إيقاف
    private fun switchRow(parent: LinearLayout, title: String, key: String, def: Boolean, sub: String? = null) {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(0, dp(8), 0, dp(8))
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        val t = TextView(this)
        t.text = title
        t.setTextColor(Color.WHITE)
        t.textSize = 16f
        col.addView(t)
        if (sub != null) {
            val s = TextView(this)
            s.text = sub
            s.setTextColor(Color.parseColor("#B0FFFFFF"))
            s.textSize = 12f
            col.addView(s)
        }
        row.addView(col, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val sw = Switch(this)
        sw.isChecked = prefs.getBoolean(key, def)
        sw.setOnCheckedChangeListener { _, on ->
            prefs.edit().putBoolean(key, on).apply()
        }
        row.addView(sw)
        parent.addView(row)
    }

    // اختيار من كام اختيار (أزرار جنب بعض)
    private fun segment(
        parent: LinearLayout,
        title: String,
        labels: List<String>,
        get: () -> Int,
        set: (Int) -> Unit,
        sub: String? = null
    ) {
        parent.addView(label(title))
        if (sub != null) parent.addView(subText(sub))
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        val views = ArrayList<TextView>()
        fun paint() {
            for ((i, v) in views.withIndex()) {
                val g = GradientDrawable()
                g.cornerRadius = dp(18).toFloat()
                g.setColor(Color.parseColor(if (i == get()) "#B33F51B5" else "#55FFFFFF"))
                v.background = g
            }
        }
        for ((i, l) in labels.withIndex()) {
            val v = TextView(this)
            v.text = l
            v.setTextColor(Color.WHITE)
            v.textSize = if (labels.size > 4) 12f else 14f
            v.gravity = Gravity.CENTER
            val lp = LinearLayout.LayoutParams(0, dp(40), 1f)
            lp.setMargins(dp(2), dp(4), dp(2), dp(4))
            v.layoutParams = lp
            v.setOnClickListener {
                set(i)
                paint()
                updatePreviewLook()
            }
            views.add(v)
            row.addView(v)
        }
        paint()
        parent.addView(row)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("franco", MODE_PRIVATE)
        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.BLACK
        window.decorView.systemUiVisibility =
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN

        val root = FrameLayout(this)
        val bg = ImageView(this)
        bg.setImageResource(R.drawable.bg)
        bg.scaleType = ImageView.ScaleType.CENTER_CROP
        root.addView(bg, FrameLayout.LayoutParams(-1, -1))
        val sc = View(this)
        sc.setBackgroundColor(Color.parseColor("#80000000"))
        root.addView(sc, FrameLayout.LayoutParams(-1, -1))

        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(16), dp(48), dp(16), dp(8))

        val title = TextView(this)
        title.text = "إعدادات الكيبورد"
        title.setTextColor(Color.WHITE)
        title.textSize = 22f
        title.gravity = Gravity.CENTER
        title.setShadowLayer(8f, 0f, 0f, Color.BLACK)
        title.setPadding(0, 0, 0, dp(10))
        col.addView(title)

        // التبويبات
        val tabs = LinearLayout(this)
        tabs.orientation = LinearLayout.HORIZONTAL
        tabs.layoutDirection = View.LAYOUT_DIRECTION_RTL
        val names = listOf("المظهر", "الكتابة", "صوت واهتزاز", "بيانات", "الخط")
        for ((i, n) in names.withIndex()) {
            val t = TextView(this)
            t.text = n
            t.setTextColor(Color.WHITE)
            t.textSize = 14f
            t.gravity = Gravity.CENTER
            val lp = LinearLayout.LayoutParams(0, dp(40), 1f)
            lp.setMargins(dp(2), 0, dp(2), 0)
            t.layoutParams = lp
            t.setOnClickListener { showTab(i) }
            tabViews.add(t)
            tabs.addView(t)
        }
        col.addView(tabs)

        content = LinearLayout(this)
        content.orientation = LinearLayout.VERTICAL
        content.setPadding(0, dp(6), 0, dp(24))
        val scroll = ScrollView(this)
        scroll.addView(content)
        col.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        root.addView(col, FrameLayout.LayoutParams(-1, -1))
        setContentView(root)
        showTab(0)
    }

    private fun showTab(i: Int) {
        for ((k, v) in tabViews.withIndex()) {
            val g = GradientDrawable()
            g.cornerRadius = dp(20).toFloat()
            g.setColor(Color.parseColor(if (k == i) "#B33F51B5" else "#44FFFFFF"))
            v.background = g
        }
        content.removeAllViews()
        when (i) {
            0 -> buildLook(content)
            1 -> buildTyping(content)
            2 -> buildFeel(content)
            3 -> buildData(content)
            else -> buildFont(content)
        }
    }

    // ---------------- المظهر ----------------

    private fun buildLook(c: LinearLayout) {
        val prev = FrameLayout(this)
        prev.setBackgroundColor(Color.parseColor("#1B1B1F"))
        prev.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                outline.setRoundRect(0, 0, view.width, view.height, dp(16).toFloat())
            }
        }
        prev.clipToOutline = true
        previewImg = ImageView(this)
        previewImg.scaleType = ImageView.ScaleType.CENTER_CROP
        prev.addView(previewImg, FrameLayout.LayoutParams(-1, -1))
        previewScrim = View(this)
        prev.addView(previewScrim, FrameLayout.LayoutParams(-1, -1))
        val keys = LinearLayout(this)
        keys.orientation = LinearLayout.HORIZONTAL
        keys.layoutDirection = View.LAYOUT_DIRECTION_LTR
        keys.setPadding(dp(6), 0, dp(6), 0)
        sampleKeys.clear()
        for (ch in listOf("ج", "ح", "خ", "ه", "ع", "غ")) {
            val t = TextView(this)
            t.text = ch
            t.setTextColor(Color.WHITE)
            t.textSize = 20f
            t.gravity = Gravity.CENTER
            val g = GradientDrawable()
            g.cornerRadius = dp(8).toFloat()
            g.setColor(Color.parseColor("#3C3C45"))
            t.background = g
            val lp = LinearLayout.LayoutParams(0, dp(46), 1f)
            lp.setMargins(dp(2), 0, dp(2), 0)
            t.layoutParams = lp
            keys.addView(t)
            sampleKeys.add(t)
        }
        prev.addView(keys, FrameLayout.LayoutParams(-1, -2, Gravity.CENTER))
        c.addView(prev, LinearLayout.LayoutParams(-1, dp(150)))

        val bgc = card()
        bgc.addView(button("اختيار صورة للكيبورد") { pickImage() })
        bgc.addView(button("اختيار فيديو للخلفية (لحد 10 ثواني)") { pickVideo() })
        bgStatus = TextView(this)
        bgStatus.setTextColor(Color.parseColor("#CCFFFFFF"))
        bgStatus.textSize = 13f
        bgStatus.gravity = Gravity.CENTER
        bgc.addView(bgStatus)
        bgc.addView(button("مسح الخلفية (صورة أو فيديو)") {
            val now = System.currentTimeMillis()
            if (now - resetAsk > 3500) {
                resetAsk = now
                Toast.makeText(this, "دوس تاني للتأكيد", Toast.LENGTH_SHORT).show()
            } else {
                resetAsk = 0L
                File(filesDir, "kb_bg.jpg").delete()
                File(filesDir, "kb_bg.mp4").delete()
                prefs.edit().putString("bg_type", "image").apply()
                loadPreviewImage()
                updatePreviewLook()
                refreshBgStatus()
                Toast.makeText(this, "اتمسحت", Toast.LENGTH_SHORT).show()
            }
        })
        slider(bgc, "تغميق الخلفية", "bg_dim", 0, 90, 35, "%", "كل ما زاد الرقم، الخلفية بتبقى أغمق")
        c.addView(bgc)

        val kc = card()
        segment(
            kc, "لون الزراير",
            listOf("افتراضي", "أزرق", "أخضر", "بنفسجي", "أحمر", "وردي", "أسود", "أبيض", "من الخلفية"),
            { prefs.getInt("theme", 0) },
            { prefs.edit().putInt("theme", it).apply() },
            "لون الزراير كلها. \"من الخلفية\" بياخد لونه من الصورة اللي حاططها"
        )
        slider(kc, "شفافية الزراير (مع الخلفية)", "key_alpha", 20, 100, 60, "%", "قلّلها عشان الخلفية تظهر أكتر")
        slider(kc, "حجم حروف الكيبورد", "key_text", 12, 28, 18, "", "حجم الحرف على الزرار")
        slider(kc, "حجم مربع الحرف", "key_box_size", 50, 100, 100, "%", "حجم المربع حوالين الحرف")
        switchRow(kc, "المربع حوالين الحرف", "key_box", true, "إخفاؤه بيظهر الحرف بس")
        switchRow(kc, "الأرقام الصغيرة فوق الحروف", "hints", true, "الرقم الصغير اللي فوق كل حرف")
        kc.addView(button("تغيير حجم الكيبورد") {
            startActivity(Intent(this, ResizeActivity::class.java))
        })
        c.addView(kc)

        loadPreviewImage()
        updatePreviewLook()
        refreshBgStatus()
    }

    // ---------------- الكتابة ----------------

    private fun buildTyping(c: LinearLayout) {
        val a = card()
        switchRow(a, "التصحيح التلقائي", "autocorrect", true, "يصلّح الكلمة الغلط أول ما تدوس مسافة")
        switchRow(a, "التصحيح الأونلاين", "online", true, "تصحيح أدق للكلمات (يحتاج إنترنت)")
        switchRow(a, "الترجمة", "trans_on", true, "ترجمة فورية للي بتكتبه (يحتاج إنترنت)")
        switchRow(a, "اقتراح الكلمات", "sug_on", true, "كلمات مقترحة فوق الكيبورد")
        switchRow(a, "التعلّم من كلامك", "learn_on", true, "اقتراحات من كلماتك انت")
        switchRow(a, "الوضع الخفي", "incog", false, "يوقف حفظ الكلمات والحافظة والتصحيح الأونلاين")
        switchRow(a, "الآلة الحاسبة", "calc", true, "اكتب العملية وبعدها = والناتج يتكتب لوحده (مثال: 5*5= يطلع 25). + زائد، - ناقص، * ضرب أو في، / قسمة أو على. ولو مفيش = الناتج بيظهر فوق ودوس عليه ياخد مكان العملية")
        switchRow(a, "يسيب العملية مع الناتج", "calc_keep", true, "شغال: 5*5=25. مقفول: العملية تتمسح ويطلع 25 بس")
        switchRow(a, "تنضيف اللينكات", "link_clean", true, "يشيل الزيادات من اللينك اللي نسخته قبل ما يتلصق")
        switchRow(a, "إنجليزي تلقائي", "auto_en", true, "الكيبورد يفتح إنجليزي في الروابط والإيميل والباسورد")
        switchRow(a, "تصحيح اللغة الغلط", "wrong_layout", true, "لو كتبت hgsghl بدل السلام، بيقترحها صح في الشريط")
        switchRow(a, "إيموجي مقترح", "emoji_sug", true, "تكتب حب أو love يظهر ❤️ في الشريط")
        switchRow(a, "فرانكو لكل تطبيق", "fr_per_app", true, "الكيبورد يفتكر وضع الفرانكو لكل تطبيق لوحده")
        c.addView(a)

        val b = card()
        switchRow(b, "أول حرف كبير", "autocap", true, "أول الجملة وأول الخانة (في الإنجليزي)")
        switchRow(b, "مسافتين = نقطة", "dblspace", false, "دوسة مسافة تانية بتحط نقطة")
        switchRow(b, "i تبقى I", "cap_i", true, "حرف i لوحده في الإنجليزي بيتحول لـ I كبير")
        switchRow(b, "يبدأ بوضع فرانكو", "franco_start", true, "الكيبورد يفتح بالكتابة بالفرانكو")
        c.addView(b)

        val fs = card()
        segment(
            fs, "شكل الفرانكو",
            listOf("أرقام (3 و7 و5)", "حروف (a وh وkh)"),
            { prefs.getInt("fr_style", 0) },
            { prefs.edit().putInt("fr_style", it).apply() },
            "طريقة كتابة ع وح وخ وط في الفرانكو"
        )
        c.addView(fs)

        val fr = card()
        switchRow(fr, "لوحة فرانكو", "fr_layout", true, "لغة تالتة بتظهر لما تدوس 🌐، حروف لاتينية مكان العربي")
        switchRow(fr, "الحرف العربي الصغير", "fr_hint", true, "بيظهر فوق يمين كل زرار في لوحة فرانكو")
        fr.addView(button("تخصيص حروف لوحة فرانكو") {
            startActivity(Intent(this, FrancoLayoutActivity::class.java))
        })
        fr.addView(noteText("غيّر الحرف أو ضيف حروف تانية بالضغط الطويل"))
        c.addView(fr)

        val d = card()
        val langs = listOf("ar-EG", "ar-SA", "en-US")
        segment(
            d, "لغة الكتابة بالصوت (🎤)",
            listOf("مصري", "سعودي", "إنجليزي"),
            { langs.indexOf(prefs.getString("voice_lang", "ar-EG")).coerceAtLeast(0) },
            { prefs.edit().putString("voice_lang", langs[it]).apply() },
            "اللغة اللي بتتكلم بيها في الميكروفون"
        )
        c.addView(d)



        c.addView(noteText("التغييرات بتظهر أول ما تفتح الكيبورد تاني."))
    }

    // ---------------- صوت واهتزاز ----------------

    private fun buildFeel(c: LinearLayout) {
        val a = card()
        switchRow(a, "اهتزاز عند الضغط", "vib", false, "اهتزاز خفيف مع كل زرار")
        segment(
            a, "قوة الاهتزاز",
            listOf("خفيف", "متوسط", "قوي"),
            { prefs.getInt("vib_str", 2) - 1 },
            { prefs.edit().putInt("vib_str", it + 1).apply() }
        )
        c.addView(a)

        val b = card()
        switchRow(b, "صوت عند الضغط", "snd", false, "صوت مع كل زرار")
        segment(
            b, "نوع الصوت",
            KeySounds.NAMES,
            { prefs.getInt("snd_style", 0) },
            { prefs.edit().putInt("snd_style", it).apply() },
            "رنة، أو ألحان (كل زرار نغمة حسب مكانه)، أو قطرة، أو ميكانيكي"
        )
        slider(b, "مستوى الصوت", "snd_vol", 10, 100, 60, "%")
        c.addView(b)

        val rg = card()
        switchRow(rg, "إضاءة RGB حوالين الكيبورد", "rgb_border", false, "إطار ألوان بيلف حوالين الكيبورد")
        switchRow(rg, "إضاءة RGB عند الضغط", "rgb_press", false, "موجة ألوان بتطلع مكان إصبعك مع كل حرف")
        c.addView(rg)

        val d = card()
        slider(d, "سرعة ظهور التشكيل والبدائل (الضغط الطويل)", "lp_ms", 200, 600, 350, " ms", "كل ما قل الرقم، بتظهر أسرع")
        c.addView(d)
        c.addView(noteText("التغييرات بتظهر أول ما تفتح الكيبورد تاني."))
    }

    // ---------------- الخط ----------------

    private fun fontsDir(): File {
        val d = File(filesDir, "fonts")
        if (!d.exists()) d.mkdirs()
        return d
    }

    // الخط بيتحفظ لكل ثيم لوحده (الأقدم: خط واحد للكل)
    private fun fontKey(): String = "font_file_t" + prefs.getInt("theme", 0)

    private fun curFont(): String? {
        val k = fontKey()
        if (prefs.contains(k)) {
            val v = prefs.getString(k, "") ?: ""
            return if (v.isEmpty()) null else v
        }
        return prefs.getString("font_file", null)
    }

    private fun buildFont(c: LinearLayout) {
        val a = card()
        a.addView(label("خط الكيبورد"))
        a.addView(subText("اختار ملف خط (ttf أو otf) من موبايلك، حتى لو فيه إيموجي أيفون مدموج. الخط بيظهر على حروف الكيبورد ولوحة الإيموجي في العربي والإنجليزي والفرانكو. والخط بيتحفظ للثيم اللي مختاره دلوقتي، يعني كل ثيم ليه خطه."))
        val cur = curFont()
        val sample = TextView(this)
        sample.text = "أهلا ahlan  😂❤️🔥👍🥰"
        sample.setTextColor(Color.WHITE)
        sample.textSize = 24f
        sample.gravity = Gravity.CENTER
        sample.setPadding(0, dp(10), 0, dp(10))
        if (cur != null) {
            try {
                val f = File(fontsDir(), cur)
                if (f.exists()) sample.typeface = Typeface.createFromFile(f)
            } catch (e: Exception) {
                // مش مهم
            }
        }
        a.addView(sample)
        a.addView(button("➕ إضافة خط من الموبايل") { pickFont() })
        c.addView(a)

        val b = card()
        b.addView(label("الخطوط المضافة"))
        val def = button(if (cur == null) "✓ الخط الأصلي" else "الخط الأصلي") {
            prefs.edit().putString(fontKey(), "").apply()
            showTab(4)
        }
        b.addView(def)
        val files = fontsDir().listFiles()?.filter { it.isFile }?.sortedBy { it.name } ?: emptyList()
        for (f in files) {
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            val sel = button((if (f.name == cur) "✓ " else "") + f.name) {
                prefs.edit().putString(fontKey(), f.name).apply()
                showTab(4)
            }
            row.addView(sel, LinearLayout.LayoutParams(0, dp(48), 1f))
            val del = TextView(this)
            del.text = "حذف"
            del.setTextColor(Color.WHITE)
            del.gravity = Gravity.CENTER
            val g = GradientDrawable()
            g.cornerRadius = dp(24).toFloat()
            g.setColor(Color.parseColor("#B3C62828"))
            del.background = g
            val dlp = LinearLayout.LayoutParams(dp(70), dp(48))
            dlp.setMargins(dp(6), dp(6), 0, dp(6))
            row.addView(del, dlp)
            del.setOnClickListener {
                if (f.name == cur) prefs.edit().putString(fontKey(), "").apply()
                f.delete()
                showTab(4)
            }
            b.addView(row)
        }
        if (files.isEmpty()) b.addView(subText("لسه مفيش خطوط مضافة."))
        c.addView(b)
        c.addView(noteText("التغيير بيظهر أول ما تفتح الكيبورد تاني. الشكل بيظهر عندك أنت بس، والإيموجي اللي بتبعته بيظهر عند اللي بيستلمه بشكل تطبيقه."))
    }

    private fun pickBackup() {
        val i = Intent(Intent.ACTION_CREATE_DOCUMENT)
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.type = "application/json"
        i.putExtra(Intent.EXTRA_TITLE, "franco-backup.json")
        try {
            startActivityForResult(i, reqBackup)
        } catch (e: Exception) {
            Toast.makeText(this, "مفيش تطبيق ملفات", Toast.LENGTH_SHORT).show()
        }
    }

    private fun pickRestore() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.type = "*/*"
        try {
            startActivityForResult(i, reqRestore)
        } catch (e: Exception) {
            Toast.makeText(this, "مفيش تطبيق ملفات", Toast.LENGTH_SHORT).show()
        }
    }

    private fun doBackup(uri: Uri) {
        Thread {
            var ok = true
            try {
                val o = org.json.JSONObject()
                for ((k, v) in prefs.all) {
                    if (k == "resize_pending" || k == "shot_asked") continue
                    val e = org.json.JSONObject()
                    when (v) {
                        is Boolean -> { e.put("t", "b"); e.put("v", v) }
                        is Int -> { e.put("t", "i"); e.put("v", v) }
                        is Long -> { e.put("t", "l"); e.put("v", v) }
                        is Float -> { e.put("t", "f"); e.put("v", v.toDouble()) }
                        is String -> { e.put("t", "s"); e.put("v", v) }
                        else -> continue
                    }
                    o.put(k, e)
                }
                val out = contentResolver.openOutputStream(uri)
                if (out == null) {
                    ok = false
                } else {
                    out.use { it.write(o.toString().toByteArray(Charsets.UTF_8)) }
                }
            } catch (e: Throwable) {
                ok = false
            }
            runOnUiThread {
                Toast.makeText(this, if (ok) "تم حفظ النسخة" else "ماتحفظتش", Toast.LENGTH_LONG).show()
            }
        }.start()
    }

    private fun doRestore(uri: Uri) {
        Thread {
            var ok = true
            try {
                val txt = contentResolver.openInputStream(uri)?.use { it.readBytes().toString(Charsets.UTF_8) }
                if (txt == null) {
                    ok = false
                } else {
                    val o = org.json.JSONObject(txt)
                    val ed = prefs.edit()
                    ed.clear()
                    val keys = o.keys()
                    var n = 0
                    while (keys.hasNext()) {
                        val k = keys.next()
                        val e = o.optJSONObject(k) ?: continue
                        when (e.optString("t")) {
                            "b" -> ed.putBoolean(k, e.getBoolean("v"))
                            "i" -> ed.putInt(k, e.getInt("v"))
                            "l" -> ed.putLong(k, e.getLong("v"))
                            "f" -> ed.putFloat(k, e.getDouble("v").toFloat())
                            "s" -> ed.putString(k, e.getString("v"))
                            else -> continue
                        }
                        n++
                    }
                    if (n == 0) ok = false else ed.apply()
                }
            } catch (e: Throwable) {
                ok = false
            }
            runOnUiThread {
                Toast.makeText(this, if (ok) "اترجعت النسخة" else "الملف ده مش نسخة صالحة", Toast.LENGTH_LONG).show()
                if (ok) showTab(3)
            }
        }.start()
    }

    private fun pickFont() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.type = "*/*"
        try {
            startActivityForResult(i, reqFont)
        } catch (e: Exception) {
            Toast.makeText(this, "مفيش تطبيق ملفات", Toast.LENGTH_SHORT).show()
        }
    }

    private fun importFont(uri: Uri) {
        Toast.makeText(this, "بحفظ الخط... (الملفات الكبيرة بتاخد وقت)", Toast.LENGTH_LONG).show()
        Thread {
            var err: String? = null
            var saved: String? = null
            try {
                var name = "font.ttf"
                contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
                    if (it.moveToFirst()) it.getString(0)?.let { n -> name = n }
                }
                name = name.replace(Regex("[^A-Za-z0-9._\\-\\u0621-\\u064A ]"), "_")
                val low = name.lowercase()
                if (!low.endsWith(".ttf") && !low.endsWith(".otf")) name += ".ttf"
                val out = File(fontsDir(), name)
                val ins = contentResolver.openInputStream(uri)
                if (ins == null) {
                    err = "الملف ماتفتحش"
                } else {
                    ins.use { i2 ->
                        FileOutputStream(out).use { o -> i2.copyTo(o, 64 * 1024) }
                    }
                    try {
                        Typeface.createFromFile(out)
                        saved = name
                    } catch (e: Exception) {
                        out.delete()
                        err = "الملف ده مش خط صالح (لازم ttf أو otf)"
                    }
                }
            } catch (e: Exception) {
                err = "حصل خطأ في حفظ الخط"
            }
            val savedF = saved
            val errF = err
            runOnUiThread {
                if (savedF != null) {
                    prefs.edit().putString(fontKey(), savedF).apply()
                    Toast.makeText(this, "تم حفظ الخط واختياره", Toast.LENGTH_SHORT).show()
                    showTab(4)
                } else {
                    Toast.makeText(this, errF ?: "فشل", Toast.LENGTH_LONG).show()
                }
            }
        }.start()
    }

    // ---------------- بيانات ----------------

    private fun buildData(c: LinearLayout) {
        val a = card()
        switchRow(a, "الحافظة", "clip_on", true, "يحفظ اللي بتنسخه")
        slider(a, "أقصى عدد للنسخ المحفوظة", "clip_max", 10, 100, 30, " نسخة", "عدد الكلمات والجمل اللي يفضل محفوظ")
        val savedN = (prefs.getString("clips", "") ?: "").let { if (it.isEmpty()) 0 else it.split("\u0001").size }
        a.addView(noteText("المحفوظ دلوقتي: " + savedN))
        c.addView(a)

        val b = card()
        b.addView(button("مسح الكلمات اللي الكيبورد اتعلمها") {
            prefs.edit().remove("uni").remove("bi").apply()
            Toast.makeText(this, "اتمسحت", Toast.LENGTH_SHORT).show()
        })
        b.addView(noteText("الاقتراحات بترجع من الأول"))
        b.addView(button("إعادة ضبط كل الإعدادات") {
            val now = System.currentTimeMillis()
            if (now - allResetAsk > 3500) {
                allResetAsk = now
                Toast.makeText(this, "دوس تاني للتأكيد", Toast.LENGTH_SHORT).show()
            } else {
                allResetAsk = 0L
                val e = prefs.edit()
                for (k in listOf(
                    "bg_dim", "key_alpha", "key_text", "key_box", "key_box_size", "hints", "theme",
                    "autocorrect", "online", "sug_on", "learn_on", "autocap", "dblspace",
                    "franco_start", "voice_lang", "vib", "vib_str", "snd", "snd_vol", "lp_ms",
                    "clip_on", "clip_max", "trans_on", "kb_h", "kb_l", "kb_r",
                    "incog",
                    "calc", "link_clean", "auto_en",
                    "cap_i", "fr_layout", "fr_hint",
                    "calc_keep", "wrong_layout", "emoji_sug", "fr_per_app", "fr_style", "snd_style", "rgb_border", "rgb_press"
                )) e.remove(k)
                for (k2 in prefs.all.keys.toList()) if (k2.startsWith("fa_")) e.remove(k2)
                e.apply()
                Toast.makeText(this, "اترجعت الإعدادات (الخلفية والحافظة زي ما هي)", Toast.LENGTH_LONG).show()
                showTab(3)
            }
        })
        c.addView(b)

        val bk = card()
        bk.addView(button("حفظ نسخة احتياطية") { pickBackup() })
        bk.addView(noteText("الإعدادات والكلمات وحروف فرانكو في ملف (من غير الخلفية)"))
        bk.addView(button("استرجاع نسخة") { pickRestore() })
        bk.addView(noteText("بيرجّع كل ده من ملف حفظته قبل كده"))
        c.addView(bk)

        val imp = card()
        imp.addView(button("نقل كلمات من Gboard") { importDictionary() })
        imp.addView(noteText("الكلمات اللي ضفتها بإيدك في القاموس الشخصي"))
        imp.addView(button("تعلّم من ملف محادثة أو نص") { pickText() })
        imp.addView(noteText("ملف txt أو zip من تصدير واتساب"))
        c.addView(imp)

        val about = card()
        val t = TextView(this)
        t.text = "Franco keyboard\nTelegram: @GIGA_UP    Discord: giga_up"
        t.setTextColor(Color.parseColor("#CCFFFFFF"))
        t.textSize = 13f
        t.gravity = Gravity.CENTER
        t.setPadding(0, dp(10), 0, dp(10))
        about.addView(t)
        c.addView(about)
    }

    // ---------------- نقل الكلمات من برا ----------------

    private fun decodeMap(str: String): HashMap<String, Int> {
        val m = HashMap<String, Int>()
        if (str.isEmpty()) return m
        for (p in str.split("\u0001")) {
            val i = p.lastIndexOf('\u0002')
            if (i <= 0) continue
            val n = p.substring(i + 1).toIntOrNull() ?: continue
            m[p.substring(0, i)] = n
        }
        return m
    }

    private fun encodeMap(m: Map<String, Int>): String {
        val sb = StringBuilder()
        for ((k, v) in m) {
            if (sb.isNotEmpty()) sb.append('\u0001')
            sb.append(k).append('\u0002').append(v)
        }
        return sb.toString()
    }

    private fun prune(m: HashMap<String, Int>, limit: Int) {
        if (m.size <= limit) return
        val keep = m.entries.sortedByDescending { it.value }.take(limit)
        m.clear()
        for (e in keep) m[e.key] = e.value
    }

    private fun saveLearned(uni: HashMap<String, Int>, bi: HashMap<String, Int>) {
        prune(uni, 6000)
        prune(bi, 12000)
        prefs.edit().putString("uni", encodeMap(uni)).putString("bi", encodeMap(bi)).apply()
    }

    private fun cleanWord(w0: String): String? {
        val w = w0.replace(Regex("[ً-ْـ]"), "")
        if (w.length < 2 || w.length > 20) return null
        val ar = w[0] in 'ء'..'ي'
        for (c in w) {
            val ok = if (ar) c in 'ء'..'ي' else (c in 'a'..'z' || c in 'A'..'Z' || c == '\'')
            if (!ok) return null
        }
        if (Regex("(.)\\1\\1").containsMatchIn(w)) return null
        return if (ar) w else w.lowercase()
    }

    // القاموس الشخصي اللي في الموبايل (الكلمات اللي ضفتها بإيدك)
    private fun importDictionary() {
        val perm = "android.permission.READ_USER_DICTIONARY"
        if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(perm) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(perm), reqDict)
            return
        }
        Toast.makeText(this, "بقرا القاموس...", Toast.LENGTH_SHORT).show()
        Thread {
            var n = 0
            var failed = false
            val uni = decodeMap(prefs.getString("uni", "") ?: "")
            val bi = decodeMap(prefs.getString("bi", "") ?: "")
            try {
                val c = contentResolver.query(
                    UserDictionary.Words.CONTENT_URI,
                    arrayOf(UserDictionary.Words.WORD), null, null, null
                )
                if (c != null) {
                    while (c.moveToNext()) {
                        val w = c.getString(0) ?: continue
                        val k = cleanWord(w.trim()) ?: continue
                        if ((uni[k] ?: 0) < 5) uni[k] = 5
                        n++
                    }
                    c.close()
                }
            } catch (e: Throwable) {
                failed = true
            }
            if (n > 0) saveLearned(uni, bi)
            runOnUiThread {
                val msg = when {
                    n > 0 -> "اتضاف $n كلمة"
                    failed -> "مقدرتش أقرا القاموس الشخصي"
                    else -> "مفيش كلمات في القاموس الشخصي"
                }
                Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
            }
        }.start()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == reqDict) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                importDictionary()
            } else {
                Toast.makeText(this, "الإذن مرفوض", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun pickText() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.type = "*/*"
        try {
            startActivityForResult(i, reqText)
        } catch (e: Exception) {
            Toast.makeText(this, "مفيش تطبيق ملفات", Toast.LENGTH_SHORT).show()
        }
    }

    // قراءة ملف نصي (أو zip فيه txt) وتعلّم الكلمات والكلمة اللي بعدها
    private fun importText(uri: Uri) {
        Toast.makeText(this, "بقرا الملف...", Toast.LENGTH_SHORT).show()
        Thread {
            val uc = HashMap<String, Int>()
            val bc = HashMap<String, Int>()
            val hdr = Regex("^[‎‏]*\\[?[\\d٠-٩]{1,4}[/.\\-][\\d٠-٩]{1,2}[/.\\-][\\d٠-٩]{1,4}")
            val head2 = Regex("(?: - |\\] )(.*?): (.*)$")
            val tok = Regex("[ء-يً-ْـ]+|[A-Za-z']+")
            var chars = 0L
            fun feed(r: BufferedReader) {
                while (chars < 20_000_000L) {
                    val line = r.readLine() ?: break
                    chars += line.length + 1
                    var msg = line
                    if (hdr.containsMatchIn(line)) {
                        val m = head2.find(line) ?: continue
                        msg = m.groupValues[2]
                    }
                    if (msg.contains("الوسائط") || msg.contains("Media omitted") || msg.contains("مشفرة")) continue
                    var prev: String? = null
                    for (tm in tok.findAll(msg)) {
                        val k = cleanWord(tm.value)
                        if (k == null) {
                            prev = null
                            continue
                        }
                        uc[k] = (uc[k] ?: 0) + 1
                        val p = prev
                        if (p != null) {
                            val bk = p + "\u0003" + k
                            bc[bk] = (bc[bk] ?: 0) + 1
                        }
                        prev = k
                    }
                }
            }
            var ok = true
            try {
                contentResolver.openInputStream(uri)?.use { ins0 ->
                    val bis = BufferedInputStream(ins0)
                    bis.mark(4)
                    val b0 = bis.read()
                    val b1 = bis.read()
                    bis.reset()
                    if (b0 == 0x50 && b1 == 0x4B) {
                        val z = ZipInputStream(bis)
                        var e = z.nextEntry
                        while (e != null) {
                            if (e.name.endsWith(".txt", true)) {
                                feed(BufferedReader(InputStreamReader(z, Charsets.UTF_8)))
                            }
                            e = z.nextEntry
                        }
                    } else {
                        feed(BufferedReader(InputStreamReader(bis, Charsets.UTF_8)))
                    }
                } ?: run { ok = false }
            } catch (e: Throwable) {
                ok = false
            }
            var added = 0
            if (ok && uc.isNotEmpty()) {
                val uni = decodeMap(prefs.getString("uni", "") ?: "")
                val bi = decodeMap(prefs.getString("bi", "") ?: "")
                for ((k, v) in uc) {
                    if (v >= 2) {
                        uni[k] = (uni[k] ?: 0) + v
                        added++
                    }
                }
                for ((k, v) in bc) if (v >= 2) bi[k] = (bi[k] ?: 0) + v
                saveLearned(uni, bi)
            }
            runOnUiThread {
                val msg = if (!ok) "الملف ماتفتحش" else if (added == 0) "مفيش كلمات متكررة في الملف" else "اتضاف $added كلمة"
                Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
            }
        }.start()
    }

    private fun noteText(s: String): TextView {
        val note = TextView(this)
        note.text = s
        note.setTextColor(Color.parseColor("#CCFFFFFF"))
        note.textSize = 13f
        note.gravity = Gravity.CENTER
        note.setPadding(0, dp(12), 0, 0)
        return note
    }

    private fun loadPreviewImage() {
        val f = File(filesDir, "kb_bg.jpg")
        if (f.exists()) {
            try {
                previewImg.setImageBitmap(BitmapFactory.decodeFile(f.path))
            } catch (e: Throwable) {
                previewImg.setImageDrawable(null)
            }
        } else {
            previewImg.setImageDrawable(null)
        }
    }

    private fun updatePreviewLook() {
        val has = File(filesDir, "kb_bg.jpg").exists() ||
            (prefs.getString("bg_type", "image") == "video" && File(filesDir, "kb_bg.mp4").exists())
        val dim = prefs.getInt("bg_dim", 35)
        previewScrim.setBackgroundColor(Color.argb(if (has) dim * 255 / 100 else 0, 0, 0, 0))
        val a = if (has) prefs.getInt("key_alpha", 60) * 255 / 100 else 255
        for (t in sampleKeys) {
            val tc = Color.parseColor(themeKeys[prefs.getInt("theme", 0).coerceIn(0, themeKeys.size - 1)])
            (t.background as GradientDrawable).setColor(Color.argb(a, Color.red(tc), Color.green(tc), Color.blue(tc)))
            t.setTextColor(if (prefs.getInt("theme", 0) == 7) Color.parseColor("#1B1B1F") else Color.WHITE)
        }
    }

    private fun refreshBgStatus() {
        val type = prefs.getString("bg_type", "image")
        val hasV = File(filesDir, "kb_bg.mp4").exists()
        val hasI = File(filesDir, "kb_bg.jpg").exists()
        bgStatus.text = when {
            type == "video" && hasV -> "الخلفية الحالية: فيديو ✓"
            hasI -> "الخلفية الحالية: صورة ✓"
            else -> "الخلفية الحالية: مفيش"
        }
    }

    private fun pickVideo() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.type = "video/*"
        try {
            startActivityForResult(i, reqVideo)
        } catch (e: Exception) {
            Toast.makeText(this, "مفيش تطبيق معرض فيديو", Toast.LENGTH_SHORT).show()
        }
    }

    // نسخ الفيديو لمخزن التطبيق (لحد 10 ثواني و40 ميجا)
    private fun saveVideo(uri: Uri): String? {
        val tmp = File(filesDir, "kb_bg_tmp.mp4")
        try {
            var total = 0L
            contentResolver.openInputStream(uri)?.use { ins ->
                FileOutputStream(tmp).use { out ->
                    val buf = ByteArray(64 * 1024)
                    while (true) {
                        val n = ins.read(buf)
                        if (n <= 0) break
                        total += n
                        if (total > 40L * 1024 * 1024) {
                            tmp.delete()
                            return "الفيديو كبير (أكتر من 40 ميجا)"
                        }
                        out.write(buf, 0, n)
                    }
                }
            } ?: return "الفيديو ماتفتحش"
            val r = MediaMetadataRetriever()
            val ms: Long
            try {
                r.setDataSource(tmp.path)
                ms = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
            } finally {
                try {
                    r.release()
                } catch (e: Throwable) {
                    // مش مهم
                }
            }
            if (ms <= 0L) {
                tmp.delete()
                return "الفيديو ده مش شغال"
            }
            if (ms > 10500L) {
                tmp.delete()
                return "الفيديو أطول من 10 ثواني"
            }
            val f = File(filesDir, "kb_bg.mp4")
            f.delete()
            if (!tmp.renameTo(f)) {
                tmp.delete()
                return "ماقدرتش أحفظ الفيديو"
            }
            f.setLastModified(System.currentTimeMillis())
            prefs.edit().putString("bg_type", "video").apply()
            return null
        } catch (e: Throwable) {
            tmp.delete()
            return "الفيديو ماتفتحش"
        }
    }

    private fun pickImage() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.type = "image/*"
        try {
            startActivityForResult(i, reqPick)
        } catch (e: Exception) {
            Toast.makeText(this, "مفيش تطبيق معرض صور", Toast.LENGTH_SHORT).show()
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        if (requestCode == reqVideo) {
            Toast.makeText(this, "بحفظ الفيديو...", Toast.LENGTH_SHORT).show()
            Thread {
                val err = saveVideo(uri)
                runOnUiThread {
                    if (err == null) {
                        refreshBgStatus()
                        Toast.makeText(this, "تم حفظ فيديو الخلفية", Toast.LENGTH_SHORT).show()
                    } else {
                        Toast.makeText(this, err, Toast.LENGTH_LONG).show()
                    }
                }
            }.start()
            return
        }
        if (requestCode == reqText) {
            importText(uri)
            return
        }
        if (requestCode == reqBackup) {
            doBackup(uri)
            return
        }
        if (requestCode == reqRestore) {
            doRestore(uri)
            return
        }
        if (requestCode == reqFont) {
            importFont(uri)
            return
        }
        if (requestCode != reqPick) return
        Thread {
            val ok = saveImage(uri)
            runOnUiThread {
                if (ok) {
                    prefs.edit().putString("bg_type", "image").apply()
                    File(filesDir, "kb_bg.mp4").delete()
                    refreshBgStatus()
                    loadPreviewImage()
                    updatePreviewLook()
                    Toast.makeText(this, "تم حفظ الخلفية", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(this, "الصورة دي ماتفتحتش", Toast.LENGTH_SHORT).show()
                }
            }
        }.start()
    }

    private fun saveImage(uri: Uri): Boolean {
        try {
            val bounds = BitmapFactory.Options()
            bounds.inJustDecodeBounds = true
            contentResolver.openInputStream(uri)?.use {
                BitmapFactory.decodeStream(it, null, bounds)
            }
            var sample = 1
            while (bounds.outWidth / sample > 1800 || bounds.outHeight / sample > 1800) {
                sample *= 2
            }
            val opts = BitmapFactory.Options()
            opts.inSampleSize = sample
            var bmp: Bitmap = contentResolver.openInputStream(uri)?.use {
                BitmapFactory.decodeStream(it, null, opts)
            } ?: return false

            var rot = 0
            try {
                contentResolver.openInputStream(uri)?.use {
                    val ex = ExifInterface(it)
                    val o = ex.getAttributeInt(
                        ExifInterface.TAG_ORIENTATION,
                        ExifInterface.ORIENTATION_NORMAL
                    )
                    if (o == ExifInterface.ORIENTATION_ROTATE_90) rot = 90
                    if (o == ExifInterface.ORIENTATION_ROTATE_180) rot = 180
                    if (o == ExifInterface.ORIENTATION_ROTATE_270) rot = 270
                }
            } catch (e: Throwable) {
                rot = 0
            }
            if (rot != 0) {
                val m = Matrix()
                m.postRotate(rot.toFloat())
                bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
            }

            val f = File(filesDir, "kb_bg.jpg")
            FileOutputStream(f).use {
                bmp.compress(Bitmap.CompressFormat.JPEG, 88, it)
            }
            f.setLastModified(System.currentTimeMillis())
            return true
        } catch (e: Throwable) {
            return false
        }
    }
}
