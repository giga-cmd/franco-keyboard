package com.franco.keyboard

import android.graphics.Bitmap
import com.google.firebase.Firebase
import com.google.firebase.ai.Chat
import com.google.firebase.ai.GenerativeModel
import com.google.firebase.ai.ai
import com.google.firebase.ai.type.GenerativeBackend
import com.google.firebase.ai.type.content
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.IOException

// الاتصال بـ Gemini عن طريق Firebase AI Logic:
// مفيش مفتاح API جوه التطبيق، والتحقق بيتم بحساب Firebase (جوجل) + App Check
object AiClient {

    // لو جوجل شالت الموديل ده، غيّر الاسم هنا بس
    const val MODEL = "gemini-3.8-flash"

    private const val SYSTEM =
        "إنت مساعد ذكي جوه كيبورد موبايل. رد بنفس لغة ولهجة المستخدم " +
            "(لو كتب مصري أو فرانكو رد بالمصري بحروف عربي). خليك مختصر ومباشر " +
            "(غالباً 2 إلى 6 جمل) إلا لو طلب تفصيل. لو بعت صورة حللها وجاوب على سؤاله عنها. " +
            "من غير عناوين ماركداون ولا جداول، ومن غير رموز زيادة، لأن الرد ممكن يتقرا بصوت عالي."

    private var model: GenerativeModel? = null

    private fun model(): GenerativeModel {
        model?.let { return it }
        val m = Firebase.ai(backend = GenerativeBackend.googleAI()).generativeModel(
            modelName = MODEL,
            systemInstruction = content { text(SYSTEM) }
        )
        model = m
        return m
    }

    fun newChat(): Chat = model().startChat()

    // بيبعت السؤال (ومعاه صورة لو موجودة) وبيرجّع الرد على دفعات (streaming)
    suspend fun ask(chat: Chat, question: String, img: Bitmap?, onPartial: (String) -> Unit): String {
        val msg = withContext(Dispatchers.Default) {
            content {
                if (img != null) image(img)
                text(question)
            }
        }
        val sb = StringBuilder()
        chat.sendMessageStream(msg).collect { r ->
            val t = r.text
            if (!t.isNullOrEmpty()) {
                sb.append(t)
                onPartial(sb.toString())
            }
        }
        return sb.toString()
    }

    fun friendlyError(e: Throwable): String {
        if (e is CancellationException) return "اتلغى"
        val m = (e.message ?: e.javaClass.simpleName)
        val l = m.lowercase()
        // ملحوظة: الترتيب مهم. والكلمات لازم تكون دقيقة لأن "generateContent" فيها كلمة "rate"
        return when {
            l.contains("app check") || l.contains("appcheck") || l.contains("attestation") ->
                "حماية App Check رفضت الجهاز. اقفل الـ Enforcement من Firebase Console أو سجّل الـ debug token"
            l.contains("no longer available") || l.contains("not found") || l.contains("404") ->
                "الموديل ($MODEL) مش متاح. التفاصيل: " + m.take(200)
            l.contains("resource_exhausted") || l.contains("quota") || l.contains("429") || l.contains("rate limit") || l.contains("too many requests") ->
                "عدّيت الحد المسموح (Quota). التفاصيل: " + m.take(200)
            l.contains("permission") || l.contains("403") || l.contains("not enabled") || l.contains("has not been used") ->
                "خدمة Firebase AI Logic مش متفعلة للمشروع (فعّلها من Firebase Console). " + m.take(120)
            l.contains("vertex") || l.contains("firebasevertexai") ->
                "فعّل Firebase AI Logic: Firebase Console ← Build ← AI Logic ← Get started ← Gemini Developer API"
            l.contains("safety") || l.contains("blocked") ->
                "الرد اتحجب لأسباب الأمان، جرب صياغة تانية"
            e is IOException || l.contains("unable to resolve") || l.contains("timeout") ->
                "مفيش إنترنت أو الاتصال ضعيف"
            else -> m.take(300)
        }
    }
}
