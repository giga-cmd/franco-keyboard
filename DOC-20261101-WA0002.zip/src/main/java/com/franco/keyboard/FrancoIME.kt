package com.franco.keyboard

import android.Manifest
import android.content.ClipboardManager
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.widget.Toast
import android.os.SystemClock
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import org.json.JSONObject
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.inputmethodservice.InputMethodService
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.text.TextUtils
import android.util.TypedValue
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputConnection
import android.view.inputmethod.InputMethodManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ImageView
import android.widget.ScrollView
import android.widget.TextView
import java.io.File

class FrancoIME : InputMethodService() {

    companion object {
        const val L_AR = 0
        const val L_EN = 1
        const val L_SYM1 = 2
        const val L_SYM2 = 3
        const val L_NUM = 4
        const val L_CLIP = 5
        const val L_EMO = 6
        const val L_PANEL = 7

        const val C_BG = "#1B1B1F"
        const val C_KEY = "#3C3C45"
        const val C_FUNC = "#55555F"
        const val C_PRESS = "#7A7A88"
        const val C_ACCENT = "#3F51B5"
        const val C_GREEN = "#2E7D32"
    }

    private var layer = L_AR
    private var shift = 0
    private var lastShiftTap = 0L
    private var francoOn = true

    private val handler = Handler(Looper.getMainLooper())
    private var content: LinearLayout? = null
    private var toggleBtn: TextView? = null
    private var overlay: FrameLayout? = null
    private var pill: LinearLayout? = null
    private var bgImage: ImageView? = null
    private var bgScrim: View? = null
    private var bgOn = false
    private var keyAlpha = 255
    private var bgStamp = -1L
    private var kbFrame: KbFrame? = null
    private var resizeLayer: FrameLayout? = null
    private var resizeMode = false
    private var hScale = 1f
    private var kbL = 0f
    private var kbR = 1f
    private var chipView: TextView? = null
    private var autoBtn: TextView? = null
    private var emoData: LinkedHashMap<String, List<String>>? = null
    private val emoRecent = ArrayList<String>()
    private var emoCat = "smileys"
    private var prevLayer = L_AR
    private val popupViews = ArrayList<TextView>()
    private var repeatTask: Runnable? = null

    // الكلمة الحالية: بالعربي وبالإنجليزي اللي اتكتب لحد دلوقتي
    private val wordAr = StringBuilder()
    private var wordFr = ""

    // قاموس الكلمات والأسماء
    private val dict = HashMap<String, String>()

    // الحافظة
    private val clips = ArrayList<String>()
    private var prefs: SharedPreferences? = null
    private val clipListener = ClipboardManager.OnPrimaryClipChangedListener { grabClip(true) }

    // نص اتمسح من الحافظة: ما نرجعوش من حافظة النظام غير لما يتنسخ تاني
    private var ignoredClip: String? = null

    // الكتابة بالصوت
    private var recognizer: SpeechRecognizer? = null
    private var listening = false
    private var micBtn: TextView? = null

    // تصحيح أونلاين (LanguageTool): مجاني، بيبعت الكلمة نفسها بس
    private var onlineAllowed = true
    private var onlineBusy = false
    private var onlineLast = 0L
    private val onlineCache = HashMap<String, String?>()

    // حروف الفرانكو للكلمات اللي مش في القاموس (عدّل فيها زي ما تحب)
    private val consonants: Map<Char, String> = mapOf(
        'ب' to "b", 'ت' to "t", 'ث' to "th", 'ج' to "g",
        'ح' to "7", 'خ' to "5", 'د' to "d", 'ذ' to "z",
        'ر' to "r", 'ز' to "z", 'س' to "s", 'ش' to "sh",
        'ص' to "9", 'ض' to "d", 'ط' to "6", 'ظ' to "z",
        'ع' to "3", 'غ' to "gh", 'ف' to "f", 'ق' to "2",
        'ك' to "k", 'ل' to "l", 'م' to "m", 'ن' to "n",
        'ه' to "h", 'ء' to "2", 'ؤ' to "2", 'ئ' to "2"
    )

    // نهايات الكلمات (ضمائر) وطريقة كتابتها
    private val suffixes: List<Pair<String, String>> = listOf(
        Pair("كم", "kom"), Pair("هم", "hom"), Pair("ها", "ha"),
        Pair("ني", "ni"), Pair("نا", "na"), Pair("ك", "ak"), Pair("ه", "o")
    )

    // قائمة الضغط المطوّل على النقطة: تشكيل + علامات ترقيم
    private val dotOpts: List<String> = listOf(
        "َ", "ُ", "ِ", "ً", "ٌ", "ٍ",
        "ّ", "ْ", "ـ", "؟", "!", "؛",
        ":", "\"", "'", "-", "(", ")"
    )

    // ------------------------------------------------------------------
    // دورة حياة الخدمة
    // ------------------------------------------------------------------

    override fun onCreate() {
        super.onCreate()
        loadDict("words_default.txt")
        loadDict("words_user.txt")
        prefs = getSharedPreferences("franco", Context.MODE_PRIVATE)
        loadClips()
        ignoredClip = prefs?.getString("clip_ignored", null)
        loadPins()
        autoOn = prefs?.getBoolean("autocorrect", true) ?: true
        loadNoCorrect()
        buildNear()
        Thread { loadSpell() }.start()
        try {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.addPrimaryClipChangedListener(clipListener)
        } catch (e: Exception) {
            // مش مهم
        }
    }

    override fun onDestroy() {
        try {
            recognizer?.destroy()
        } catch (e: Exception) {
            // مش مهم
        }
        recognizer = null
        try {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.removePrimaryClipChangedListener(clipListener)
        } catch (e: Exception) {
            // مش مهم
        }
        super.onDestroy()
    }

    override fun onEvaluateFullscreenMode(): Boolean = false

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        resetWord()
        applyBackground()
        applyLayoutPrefs()
        val cls = (info?.inputType ?: 0) and InputType.TYPE_MASK_CLASS
        val variation = (info?.inputType ?: 0) and InputType.TYPE_MASK_VARIATION
        onlineAllowed = !(
            (cls == InputType.TYPE_CLASS_TEXT && (
                variation == InputType.TYPE_TEXT_VARIATION_PASSWORD ||
                    variation == InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD ||
                    variation == InputType.TYPE_TEXT_VARIATION_WEB_PASSWORD ||
                    variation == InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS ||
                    variation == InputType.TYPE_TEXT_VARIATION_URI)) ||
                (cls == InputType.TYPE_CLASS_NUMBER && variation == InputType.TYPE_NUMBER_VARIATION_PASSWORD)
            )
        if (cls == InputType.TYPE_CLASS_NUMBER || cls == InputType.TYPE_CLASS_PHONE) {
            layer = L_NUM
        } else if (layer == L_NUM || layer == L_CLIP || layer == L_EMO || layer == L_PANEL) {
            layer = L_AR
        }
        grabClip()
        render()
        val pending = prefs?.getBoolean("resize_pending", false) ?: false
        if (pending) {
            prefs?.edit()?.putBoolean("resize_pending", false)?.apply()
            handler.postDelayed({ enterResizeMode() }, 300)
        }
    }

    override fun onFinishInputView(finishingInput: Boolean) {
        stopVoice()
        exitResizeMode(true)
        dismissPopup()
        super.onFinishInputView(finishingInput)
    }

    // ------------------------------------------------------------------
    // القاموس والتحويل لفرانكو
    // ------------------------------------------------------------------

    private fun loadDict(name: String) {
        try {
            assets.open(name).bufferedReader(Charsets.UTF_8).useLines { lines ->
                for (line in lines) {
                    val t = line.trim()
                    if (t.isEmpty() || t.startsWith("#")) continue
                    val idx = t.indexOf('=')
                    if (idx <= 0) continue
                    val key = normalize(t.substring(0, idx).trim())
                    val value = t.substring(idx + 1).trim()
                    if (key.isNotEmpty() && value.isNotEmpty()) dict[key] = value
                }
            }
        } catch (e: Exception) {
            // الملف مش موجود: عادي
        }
    }

    private fun normalize(s: String): String {
        val sb = StringBuilder()
        for (c in s) {
            when (c) {
                'أ', 'إ', 'آ' -> sb.append('ا')
                'ى' -> sb.append('ي')
                'ة' -> sb.append('ه')
                else -> sb.append(c)
            }
        }
        return sb.toString()
    }

    private fun isMark(c: Char): Boolean = c in '\u064B'..'\u0652'

    private fun hasMarks(w: String): Boolean {
        for (c in w) {
            if (isMark(c)) return true
        }
        return false
    }

    private fun convertWord(word: String): String {
        if (hasMarks(word)) return explicit(word)
        val hit = dict[normalize(word)]
        return hit ?: fallback(word)
    }

    // كلمة فيها تشكيل: نكتبها بالحركات اللي انت حطيتها بالظبط
    private fun explicit(word: String): String {
        val sb = StringBuilder()
        var lastCons = ""
        var prev = ' '
        for ((i, c) in word.withIndex()) {
            when (c) {
                '\u064E' -> sb.append("a")
                '\u064F' -> sb.append("o")
                '\u0650' -> sb.append("e")
                '\u064B' -> sb.append("an")
                '\u064C' -> sb.append("on")
                '\u064D' -> sb.append("en")
                '\u0651' -> {
                    if (lastCons.isNotEmpty()) {
                        if (sb.endsWith(lastCons)) {
                            sb.append(lastCons)
                        } else if (sb.length > lastCons.length &&
                            sb.substring(sb.length - 1 - lastCons.length, sb.length - 1) == lastCons
                        ) {
                            sb.insert(sb.length - 1, lastCons)
                        }
                    }
                }
                '\u0652' -> {
                    // سكون: مفيش حركة
                }
                'ا', 'أ', 'إ', 'آ' -> {
                    if (!sb.endsWith("a")) sb.append("a")
                }
                'ى', 'ة' -> sb.append("a")
                'و' -> {
                    if (prev == '\u064F') {
                        // واو مدّ بعد ضمة: بتتكتب مرة واحدة
                    } else if (i == 0 || prev == '\u064E') {
                        sb.append("w")
                    } else {
                        sb.append("o")
                    }
                }
                'ي' -> {
                    if (prev == '\u0650') {
                        // ياء مدّ بعد كسرة: بتتكتب مرة واحدة
                    } else if (i == 0 || prev == '\u064E') {
                        sb.append("y")
                    } else {
                        sb.append("i")
                    }
                }
                else -> {
                    val l = consonants[c] ?: c.toString()
                    sb.append(l)
                    lastCons = l
                }
            }
            prev = c
        }
        return sb.toString()
    }

    // كلمة مش في القاموس: نفصل ال والنهايات، ونحط الحركات بالتخمين
    private fun fallback(word: String): String {
        if (word.length > 3 && word.startsWith("ال")) {
            return "el" + convertWord(word.substring(2))
        }
        for (s in suffixes) {
            val minStem = if (s.first.length == 1) 3 else 2
            if (word.length >= s.first.length + minStem && word.endsWith(s.first)) {
                val stemWord = word.substring(0, word.length - s.first.length)
                val st = dict[normalize(stemWord)] ?: stem(stemWord)
                return st + s.second
            }
        }
        return stem(word)
    }

    private fun stem(word: String): String {
        val units = ArrayList<String>()
        val isCons = ArrayList<Boolean>()
        for ((i, c) in word.withIndex()) {
            when (c) {
                'ا', 'أ', 'إ', 'آ', 'ى', 'ة' -> {
                    units.add("a")
                    isCons.add(false)
                }
                'و' -> {
                    units.add(if (i == 0) "w" else "o")
                    isCons.add(i == 0)
                }
                'ي' -> {
                    units.add(if (i == 0) "y" else "i")
                    isCons.add(i == 0)
                }
                else -> {
                    units.add(consonants[c] ?: c.toString())
                    isCons.add(true)
                }
            }
        }
        var nC = 0
        var nV = 0
        for (k in units.indices) {
            if (isCons[k]) {
                nC++
            } else if (!(k == units.size - 1 && (word[k] == 'ة' || word[k] == 'ى'))) {
                nV++
            }
        }
        val sb = StringBuilder()
        var ci = 0
        for (k in units.indices) {
            sb.append(units[k])
            if (isCons[k]) {
                val nextIsCons = (k + 1 < units.size) && isCons[k + 1]
                if (nextIsCons) {
                    if (nC == 4 && nV == 0) {
                        if (ci == 0 || ci == 2) sb.append("a")
                    } else {
                        sb.append(if (ci == 0) "a" else "e")
                    }
                }
                ci++
            }
        }
        return sb.toString()
    }

    private fun resetWord() {
        wordAr.setLength(0)
        wordFr = ""
        typed.setLength(0)
        lastFix = null
        scheduleSug()
    }

    private fun replaceWord(ic: InputConnection) {
        val newFr = convertWord(wordAr.toString())
        ic.beginBatchEdit()
        if (wordFr.isNotEmpty()) ic.deleteSurroundingText(wordFr.length, 0)
        ic.commitText(newFr, 1)
        ic.endBatchEdit()
        wordFr = newFr
    }

    // ------------------------------------------------------------------
    // الكتابة
    // ------------------------------------------------------------------

    // أي حاجة مش حرف عربي بيتحول لفرانكو (إنجليزي، رقم، مسافة، رمز)
    private fun commitOther(text: String) {
        val ic = currentInputConnection ?: return
        if (text.length == 1) {
            val ch = text[0]
            val apostrophe = (ch == '\'' || ch == '’') && typed.isNotEmpty()
            if (ch.isLetterOrDigit() || apostrophe) {
                // بيكمل الكلمة الحالية
                lastFix = null
                if (wordAr.isNotEmpty()) {
                    wordAr.setLength(0)
                    wordFr = ""
                }
                typed.append(ch)
                ic.commitText(text, 1)
                scheduleSug()
                return
            }
            // مسافة أو علامة ترقيم: نصحح الكلمة قبلها
            if (tryCorrect(text)) return
        }
        resetWord()
        ic.commitText(text, 1)
    }

    private fun typeLetter(ch: Char) {
        val ic = currentInputConnection ?: return
        lastFix = null
        if (!francoOn) {
            wordAr.setLength(0)
            wordFr = ""
            typed.append(ch)
            ic.commitText(ch.toString(), 1)
            scheduleSug()
            return
        }
        if (wordFr.isNotEmpty()) {
            val before = ic.getTextBeforeCursor(wordFr.length, 0)?.toString() ?: ""
            if (before != wordFr) resetWord()
        }
        wordAr.append(ch)
        replaceWord(ic)
        scheduleSug()
    }

    // رموز الضغط المطوّل: التشكيل في وضع العربي بيتكتب زي ما هو،
    // وفي وضع فرانكو بيتحوّل لحركات (فتحة a، ضمة o، كسرة e، شدة تضاعف الحرف)
    private fun typeSymbol(s: String) {
        val c = s[0]
        if (isMark(c) || c == 'ـ') {
            if (francoOn) {
                if (c != 'ـ' && wordAr.isNotEmpty()) typeLetter(c)
                return
            }
            if (typed.isNotEmpty()) typed.append(c)
            currentInputConnection?.commitText(s, 1)
            return
        }
        commitOther(s)
    }

    private fun doDelete() {
        val ic = currentInputConnection ?: return
        val selected = ic.getSelectedText(0)
        if (selected != null && selected.isNotEmpty()) {
            ic.commitText("", 1)
            resetWord()
            return
        }
        // مسح بعد تصحيح تلقائي: نرجّع الكلمة اللي انت كتبتها
        val fix = lastFix
        if (fix != null) {
            lastFix = null
            val expect = fix.shownNew + fix.boundary
            val before = ic.getTextBeforeCursor(expect.length, 0)?.toString() ?: ""
            if (before == expect) {
                ic.beginBatchEdit()
                ic.deleteSurroundingText(expect.length, 0)
                ic.commitText(fix.shownOld, 1)
                ic.endBatchEdit()
                rememberNoCorrect(fix.raw)
                wordAr.setLength(0)
                typed.setLength(0)
                wordFr = ""
                if (fix.franco) {
                    wordAr.append(fix.raw)
                    wordFr = fix.shownOld
                } else {
                    typed.append(fix.raw)
                }
                return
            }
        }
        if (francoOn && layer == L_AR && wordAr.isNotEmpty() && wordFr.isNotEmpty()) {
            val before = ic.getTextBeforeCursor(wordFr.length, 0)?.toString() ?: ""
            if (before == wordFr) {
                wordAr.setLength(wordAr.length - 1)
                if (wordAr.isEmpty()) {
                    ic.deleteSurroundingText(wordFr.length, 0)
                    wordFr = ""
                } else {
                    replaceWord(ic)
                }
                return
            }
        }
        if (typed.isNotEmpty()) {
            typed.setLength(typed.length - 1)
            ic.deleteSurroundingText(1, 0)
            return
        }
        resetWord()
        ic.deleteSurroundingText(1, 0)
    }

    private fun doEnter() {
        resetWord()
        val ic = currentInputConnection ?: return
        val options = currentInputEditorInfo?.imeOptions ?: 0
        val action = options and EditorInfo.IME_MASK_ACTION
        val noEnterAction = (options and EditorInfo.IME_FLAG_NO_ENTER_ACTION) != 0
        if (!noEnterAction &&
            action != EditorInfo.IME_ACTION_NONE &&
            action != EditorInfo.IME_ACTION_UNSPECIFIED
        ) {
            ic.performEditorAction(action)
        } else {
            sendDownUpKeyEvents(KeyEvent.KEYCODE_ENTER)
        }
    }

    // ------------------------------------------------------------------
    // التصحيح التلقائي (عربي وإنجليزي)
    // ------------------------------------------------------------------

    private class Fix(
        val raw: String,
        val shownOld: String,
        val shownNew: String,
        val boundary: String,
        val franco: Boolean
    )

    private val typed = StringBuilder()
    private var lastFix: Fix? = null
    private var autoOn = true
    @Volatile
    private var spellReady = false
    private val arRank = HashMap<String, Int>()
    private val enRank = HashMap<String, Int>()
    private val arWords = ArrayList<String>()
    private val arNorm = ArrayList<String>()
    private val enWords = ArrayList<String>()
    private val pins = ArrayList<String>()
    private var sugViews: List<TextView> = emptyList()
    private val sugRun = Runnable { updateSuggestions() }
    private val shortAr = setOf(
        "صح", "مش", "لا", "ده", "دي", "ايه", "ليه", "فين", "كده", "اوي", "يلا", "بس", "مع",
        "في", "من", "على", "عن", "انا", "انت", "هو", "هي", "لو", "يا", "اه", "طب", "ايوه",
        "ما", "كل", "اي", "ان", "او", "ام", "ثم", "قد", "لم", "لن", "بعد", "قبل", "كان",
        "عشان", "لسه", "برضه", "تمام", "خلاص"
    )

    private class Sug(val shown: String, val word: String, val ar: Boolean)
    private val noCorrect = HashSet<String>()
    private val arNear = HashMap<Char, String>()
    private val enNear = HashMap<Char, String>()
    private val arRows = listOf("ضصثقفغعهخحج", "شسيبلاتنمكط", "ذءؤرىةوزظد")
    private val enRows = listOf("qwertyuiop", "asdfghjkl", "zxcvbnm")
    private val arPre = listOf(
        "و", "ف", "ب", "ل", "ك", "ال", "وال", "بال", "فال", "كال", "لل", "ولل", "وب", "ول"
    )
    private val arFixPre = listOf("", "ال", "لل", "بال")
    private val arSuf = listOf(
        "ه", "ها", "هم", "هن", "ك", "كم", "ني", "نا", "ات", "ين", "ون", "وا", "تي", "ان", "يه", "ته"
    )

    private fun buildNear() {
        for ((r, row) in arRows.withIndex()) {
            for ((c, ch) in row.withIndex()) {
                val sb = StringBuilder()
                for (dr in -1..1) {
                    for (dc in -1..1) {
                        if (dr == 0 && dc == 0) continue
                        val rr = r + dr
                        val cc = c + dc
                        if (rr < 0 || rr >= arRows.size) continue
                        if (cc < 0 || cc >= arRows[rr].length) continue
                        val nbCh = arRows[rr][cc]
                        // حروف نادرة (ة ى ء ؤ ئ) مش بنقترحها كتصحيح
                        if ("ةىءؤئ".indexOf(nbCh) >= 0) continue
                        sb.append(nbCh)
                    }
                }
                arNear[ch] = sb.toString()
            }
        }
        for ((r, row) in enRows.withIndex()) {
            for ((c, ch) in row.withIndex()) {
                val sb = StringBuilder()
                val offs = listOf(
                    Pair(r, c - 1), Pair(r, c + 1),
                    Pair(r - 1, c), Pair(r - 1, c + 1),
                    Pair(r + 1, c - 1), Pair(r + 1, c)
                )
                for (p in offs) {
                    if (p.first < 0 || p.first >= enRows.size) continue
                    if (p.second < 0 || p.second >= enRows[p.first].length) continue
                    sb.append(enRows[p.first][p.second])
                }
                enNear[ch] = sb.toString()
            }
        }
    }

    private fun loadSpell() {
        try {
            var i = 0
            assets.open("words_ar.txt").bufferedReader(Charsets.UTF_8).useLines { lines ->
                for (line in lines) {
                    val w = normalize(line.trim())
                    if (w.isNotEmpty() && !arRank.containsKey(w)) {
                        arRank[w] = i
                        arWords.add(line.trim())
                        arNorm.add(w)
                        i++
                    }
                }
            }
            for (k in dict.keys) {
                if (!arRank.containsKey(k)) {
                    arRank[k] = 100000
                    if (k.length >= 2 && !k.contains(' ')) {
                        arWords.add(k)
                        arNorm.add(normalize(k))
                    }
                }
            }
        } catch (e: Exception) {
            // مش مهم
        }
        try {
            var i = 0
            assets.open("words_en.txt").bufferedReader(Charsets.UTF_8).useLines { lines ->
                for (line in lines) {
                    val w = line.trim()
                    if (w.isNotEmpty() && !enRank.containsKey(w)) {
                        enRank[w] = i
                        enWords.add(w)
                        i++
                    }
                }
            }
        } catch (e: Exception) {
            // مش مهم
        }
        spellReady = true
    }

    private fun loadNoCorrect() {
        noCorrect.clear()
        val s = prefs?.getString("nocorrect", "") ?: ""
        if (s.isNotEmpty()) {
            for (p in s.split("\u0001")) {
                if (p.isNotEmpty()) noCorrect.add(p)
            }
        }
    }

    private fun rememberNoCorrect(raw: String) {
        if (raw.isEmpty()) return
        val k = if (raw[0] in 'ء'..'ي') normalize(raw) else raw.lowercase()
        noCorrect.add(k)
        if (noCorrect.size > 600) {
            val it = noCorrect.iterator()
            if (it.hasNext()) {
                it.next()
                it.remove()
            }
        }
        prefs?.edit()?.putString("nocorrect", noCorrect.joinToString("\u0001"))?.apply()
    }

    private fun isKnownAr(n: String): Boolean {
        if (arRank.containsKey(n)) return true
        for (p in arPre) {
            if (n.length > p.length + 1 && n.startsWith(p)) {
                val r = n.substring(p.length)
                if (arRank.containsKey(r)) return true
                for (s in arSuf) {
                    if (r.length > s.length + 1 && r.endsWith(s) &&
                        arRank.containsKey(r.substring(0, r.length - s.length))
                    ) {
                        return true
                    }
                }
            }
        }
        for (s in arSuf) {
            if (n.length > s.length + 1 && n.endsWith(s) &&
                arRank.containsKey(n.substring(0, n.length - s.length))
            ) {
                return true
            }
        }
        return false
    }

    // أحسن تصحيح بحرف جنبه على الكيبورد أو حرفين متبدلين
    private fun bestFix(
        s: String,
        near: Map<Char, String>,
        rank: Map<String, Int>,
        maxRank: Int,
        norm: (String) -> String,
        keyOf: (Char) -> Char
    ): String? {
        var best: String? = null
        var bestKey = Int.MAX_VALUE
        for (i in 0 until s.length - 1) {
            if (s[i] == s[i + 1]) continue
            val cand = s.substring(0, i) + s[i + 1] + s[i] + s.substring(i + 2)
            val r = rank[norm(cand)]
            if (r != null && r < maxRank && r < bestKey) {
                bestKey = r
                best = cand
            }
        }
        for (i in s.indices) {
            val nb = near[keyOf(s[i])] ?: continue
            for (c in nb) {
                val cand = s.substring(0, i) + c + s.substring(i + 1)
                val r = rank[norm(cand)]
                if (r != null && r < maxRank && 1000000 + r < bestKey) {
                    bestKey = 1000000 + r
                    best = cand
                }
            }
        }
        return best
    }

    private fun fixArabic(raw: String): String? {
        if (raw.length < 4) return null
        for (c in raw) {
            if (c !in 'ء'..'ي' || c == 'ـ') return null
        }
        val n = normalize(raw)
        if (noCorrect.contains(n) || isKnownAr(n)) return null
        var best: String? = null
        var bestRank = Int.MAX_VALUE
        for (p in arFixPre) {
            if (n.length < p.length + 4 || !n.startsWith(p)) continue
            val base = raw.substring(p.length)
            val fixed = bestFix(
                base, arNear, arRank, 500,
                { x -> normalize(x) },
                { c -> if (c == 'أ' || c == 'إ' || c == 'آ') 'ا' else c }
            ) ?: continue
            val r = arRank[normalize(fixed)] ?: continue
            if (r < bestRank) {
                bestRank = r
                best = raw.substring(0, p.length) + fixed
            }
        }
        return best
    }

    // كلمات قصيرة (2-3 حروف): بنصححها بس لو حرف جنبه على الكيبورد بيطلّع كلمة شائعة
    private fun fixArabicShort(raw: String): String? {
        if (raw.length < 2 || raw.length > 3) return null
        for (c in raw) {
            if (c !in 'ء'..'ي' || c == 'ـ') return null
        }
        val n = normalize(raw)
        if (noCorrect.contains(n) || shortAr.contains(n) || isKnownAr(n)) return null
        for (i in raw.indices) {
            val k = if (raw[i] == 'أ' || raw[i] == 'إ' || raw[i] == 'آ') 'ا' else raw[i]
            val nb = arNear[k] ?: continue
            for (c in nb) {
                val cand = raw.substring(0, i) + c + raw.substring(i + 1)
                if (shortAr.contains(normalize(cand))) return cand
            }
        }
        return null
    }

    private fun fixEnglish(raw: String): String? {
        if (raw.length < 3) return null
        for (c in raw) {
            if (c !in 'a'..'z' && c !in 'A'..'Z') return null
        }
        for (i in 1 until raw.length) {
            if (raw[i] in 'A'..'Z') return null
        }
        val low = raw.lowercase()
        if (noCorrect.contains(low) || enRank.containsKey(low)) return null
        val fixed = bestFix(
            low, enNear, enRank, Int.MAX_VALUE,
            { x -> x },
            { c -> c }
        ) ?: return null
        return if (raw[0] in 'A'..'Z') fixed.substring(0, 1).uppercase() + fixed.substring(1) else fixed
    }

    // بتتنادى لما تدوس مسافة أو علامة ترقيم بعد كلمة
    private fun tryCorrect(boundary: String): Boolean {
        if (!autoOn || !spellReady) return false
        val ic = currentInputConnection ?: return false
        val franco = francoOn && layer == L_AR && wordAr.isNotEmpty()
        val raw = if (franco) wordAr.toString() else typed.toString()
        if (raw.length < 2) return false
        val fixed = if (raw[0] in 'ء'..'ي') {
            if (raw.length < 4) fixArabicShort(raw) else fixArabic(raw)
        } else {
            fixEnglish(raw)
        }
        if (fixed == null || fixed == raw) {
            val old = if (franco) wordFr else raw
            val bd = boundary
            handler.post { maybeOnline(raw, old, franco, bd) }
            return false
        }
        val shownOld = if (franco) wordFr else raw
        val shownNew = if (franco) convertWord(fixed) else fixed
        val before = ic.getTextBeforeCursor(shownOld.length, 0)?.toString() ?: ""
        if (before != shownOld) return false
        ic.beginBatchEdit()
        ic.deleteSurroundingText(shownOld.length, 0)
        ic.commitText(shownNew + boundary, 1)
        ic.endBatchEdit()
        resetWord()
        lastFix = Fix(raw, shownOld, shownNew, boundary, franco)
        return true
    }

    private fun showPicker() {
        val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
        imm.showInputMethodPicker()
    }

    private fun go(target: Int) {
        layer = target
        resetWord()
        render()
    }

    // ------------------------------------------------------------------
    // اقتراحات الكلمات (إكمال + تصحيح) في الشريط العلوي
    // ------------------------------------------------------------------

    override fun onUpdateSelection(
        oldSelStart: Int, oldSelEnd: Int, newSelStart: Int, newSelEnd: Int,
        candidatesStart: Int, candidatesEnd: Int
    ) {
        super.onUpdateSelection(oldSelStart, oldSelEnd, newSelStart, newSelEnd, candidatesStart, candidatesEnd)
        scheduleSug()
    }

    private fun scheduleSug() {
        handler.removeCallbacks(sugRun)
        handler.postDelayed(sugRun, 40)
    }

    private fun currentRaw(): Pair<String, Boolean> {
        val franco = francoOn && layer == L_AR && wordAr.isNotEmpty()
        return Pair(if (franco) wordAr.toString() else typed.toString(), franco)
    }

    private fun computeSug(): List<Sug> {
        val out = ArrayList<Sug>()
        if (!spellReady || (layer != L_AR && layer != L_EN)) return out
        val pr = currentRaw()
        val raw = pr.first
        val franco = pr.second
        if (raw.isEmpty()) return out
        val ar = raw[0] in 'ء'..'ي'
        fun show(w: String): String = if (franco && ar) convertWord(w) else w
        fun add(w: String) {
            if (w == raw || out.size >= 3) return
            for (x in out) if (x.word == w) return
            out.add(Sug(show(w), w, ar))
        }
        val fix = try {
            if (ar) (if (raw.length < 4) fixArabicShort(raw) else fixArabic(raw)) else fixEnglish(raw)
        } catch (e: Exception) {
            null
        }
        if (fix != null) add(fix)
        if (ar) {
            val p = normalize(raw)
            for (i in arNorm.indices) {
                if (out.size >= 3) break
                val w = arNorm[i]
                if (w.length > p.length && w.startsWith(p)) add(arWords[i])
            }
        } else {
            val p = raw.lowercase()
            val cap = raw[0] in 'A'..'Z'
            for (w in enWords) {
                if (out.size >= 3) break
                if (w.length > p.length && w.startsWith(p)) {
                    add(if (cap) w.substring(0, 1).uppercase() + w.substring(1) else w)
                }
            }
        }
        return out
    }

    private fun updateSuggestions() {
        val views = sugViews
        if (views.isEmpty()) return
        val list = try {
            computeSug()
        } catch (e: Exception) {
            ArrayList<Sug>()
        }
        for ((i, v) in views.withIndex()) {
            if (i < list.size) {
                v.text = list[i].shown
                v.tag = list[i]
            } else {
                v.text = ""
                v.tag = null
            }
        }
    }

    private fun applySug(sg: Sug) {
        val ic = currentInputConnection ?: return
        val pr = currentRaw()
        val old = if (pr.second) wordFr else pr.first
        if (old.isEmpty()) return
        val before = ic.getTextBeforeCursor(old.length, 0)?.toString() ?: ""
        if (before != old) return
        ic.beginBatchEdit()
        ic.deleteSurroundingText(old.length, 0)
        ic.commitText(sg.shown + " ", 1)
        ic.endBatchEdit()
        resetWord()
    }

    // ------------------------------------------------------------------
    // تصحيح أونلاين للعربي والإنجليزي (منفصل تماماً عن الفرانكو)
    // ------------------------------------------------------------------

    private fun maybeOnline(raw: String, shownOld: String, franco: Boolean, boundary: String) {
        if (!onlineAllowed || !autoOn) return
        if (prefs?.getBoolean("online", true) != true) return
        val ar = raw[0] in 'ء'..'ي'
        if (ar) {
            if (raw.length < 4) return
            for (c in raw) {
                if (c !in 'ء'..'ي' || c == 'ـ') return
            }
            val n = normalize(raw)
            if (noCorrect.contains(n) || isKnownAr(n)) return
        } else {
            if (raw.length < 3) return
            for (c in raw) {
                if (c !in 'a'..'z' && c !in 'A'..'Z') return
            }
            if (raw[0] in 'A'..'Z') return
            val low = raw.lowercase()
            if (noCorrect.contains(low) || enRank.containsKey(low)) return
        }
        val key = (if (ar) "ar:" else "en:") + raw
        if (onlineCache.containsKey(key)) {
            val c = onlineCache[key]
            if (c != null) applyOnline(raw, c, shownOld, franco, boundary)
            return
        }
        val now = SystemClock.uptimeMillis()
        if (onlineBusy || now - onlineLast < 3200) return
        onlineBusy = true
        onlineLast = now
        Thread {
            var ok = false
            var fix: String? = null
            try {
                val c = URL("https://api.languagetool.org/v2/check").openConnection() as HttpURLConnection
                c.requestMethod = "POST"
                c.connectTimeout = 3000
                c.readTimeout = 3500
                c.doOutput = true
                c.setRequestProperty("Content-Type", "application/x-www-form-urlencoded")
                val body = "language=" + (if (ar) "ar" else "en-US") +
                    "&text=" + URLEncoder.encode(raw, "UTF-8")
                c.outputStream.use { it.write(body.toByteArray()) }
                if (c.responseCode == 200) {
                    ok = true
                    val txt = c.inputStream.bufferedReader().readText()
                    val m = JSONObject(txt).getJSONArray("matches")
                    if (m.length() == 1) {
                        val o = m.getJSONObject(0)
                        val type = o.getJSONObject("rule").optString("issueType")
                        val reps = o.getJSONArray("replacements")
                        if (type == "misspelling" && o.getInt("offset") == 0 &&
                            o.getInt("length") == raw.length && reps.length() > 0
                        ) {
                            val r = reps.getJSONObject(0).getString("value")
                            if (r.isNotBlank() && !r.contains(' ') && r != raw &&
                                Math.abs(r.length - raw.length) <= 2
                            ) {
                                fix = r
                            }
                        }
                    }
                }
                c.disconnect()
            } catch (e: Exception) {
                ok = false
            }
            handler.post {
                onlineBusy = false
                if (ok) {
                    if (onlineCache.size > 500) onlineCache.clear()
                    onlineCache[key] = fix
                    if (fix != null) applyOnline(raw, fix!!, shownOld, franco, boundary)
                }
            }
        }.start()
    }

    private fun applyOnline(raw: String, fixed: String, shownOld: String, franco: Boolean, boundary: String) {
        val ic = currentInputConnection ?: return
        val shownNew = if (franco) convertWord(fixed) else fixed
        val tail = shownOld + boundary
        val before = ic.getTextBeforeCursor(tail.length + 40, 0)?.toString() ?: return
        val idx = before.lastIndexOf(tail)
        if (idx < 0) return
        // لو لسه بتكتب كلمات بعدها، بنرجعها زي ما هي
        val suffix = before.substring(idx + tail.length)
        ic.beginBatchEdit()
        ic.deleteSurroundingText(tail.length + suffix.length, 0)
        ic.commitText(shownNew + boundary + suffix, 1)
        ic.endBatchEdit()
        if (suffix.isEmpty()) {
            resetWord()
            lastFix = Fix(raw, shownOld, shownNew, boundary, franco)
        }
    }

    // ------------------------------------------------------------------
    // الكتابة بالصوت: بتتكلم عربي، وبيتكتب عربي أو فرانكو
    // حسب زرار "فرانكو" اللي في الشريط (أخضر = فرانكو)
    // ------------------------------------------------------------------

    private fun toast(msg: String) {
        try {
            Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            // مش مهم
        }
    }

    private fun refreshMic() {
        val b = micBtn ?: return
        b.text = if (listening) "⏹" else "🎤"
        b.background = roundBg(if (listening) "#C62828" else C_FUNC)
    }

    private fun hasMicPermission(): Boolean =
        Build.VERSION.SDK_INT < 23 ||
            checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    private fun askMicPermission() {
        try {
            val i = Intent(this, MicPermissionActivity::class.java)
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(i)
        } catch (e: Exception) {
            // مش مهم
        }
    }

    private fun toggleMic() {
        if (listening) {
            stopVoice()
            return
        }
        if (!hasMicPermission()) {
            askMicPermission()
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            toast("مفيش خدمة تعرّف على الصوت في الموبايل")
            return
        }
        startVoice()
    }

    private fun startVoice() {
        resetWord()
        try {
            recognizer?.destroy()
            val sr = SpeechRecognizer.createSpeechRecognizer(this)
            recognizer = sr
            sr.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onPartialResults(partialResults: Bundle?) {}
                override fun onEvent(eventType: Int, params: Bundle?) {}

                override fun onError(error: Int) {
                    listening = false
                    refreshMic()
                    when (error) {
                        SpeechRecognizer.ERROR_NO_MATCH,
                        SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> toast("ماسمعتش حاجة، جرب تاني")
                        SpeechRecognizer.ERROR_NETWORK,
                        SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> toast("محتاج إنترنت عشان الصوت")
                        SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> askMicPermission()
                        SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> {
                        }
                        else -> toast("الصوت مش شغال دلوقتي (كود $error)")
                    }
                }

                override fun onResults(results: Bundle?) {
                    listening = false
                    refreshMic()
                    val list = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    val text = list?.firstOrNull()?.trim() ?: ""
                    if (text.isNotEmpty()) insertSpoken(text)
                }
            })
            val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            i.putExtra(
                RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                RecognizerIntent.LANGUAGE_MODEL_FREE_FORM
            )
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ar-EG")
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "ar-EG")
            i.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
            i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
            i.putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
            listening = true
            refreshMic()
            sr.startListening(i)
        } catch (e: Exception) {
            listening = false
            refreshMic()
            toast("الصوت مش شغال دلوقتي")
        }
    }

    private fun stopVoice() {
        try {
            recognizer?.cancel()
        } catch (e: Exception) {
            // مش مهم
        }
        listening = false
        refreshMic()
    }

    // كل كلمة عربي بتتحول فرانكو، وأي حاجة تانية بتفضل زي ما هي
    private fun francoize(text: String): String {
        val sb = StringBuilder()
        val w = StringBuilder()
        for (c in text) {
            if (c in 'ء'..'ي' || isMark(c)) {
                w.append(c)
            } else {
                if (w.isNotEmpty()) {
                    sb.append(convertWord(w.toString()))
                    w.setLength(0)
                }
                sb.append(c)
            }
        }
        if (w.isNotEmpty()) sb.append(convertWord(w.toString()))
        return sb.toString()
    }

    private fun insertSpoken(text: String) {
        val ic = currentInputConnection ?: return
        val out = if (francoOn) francoize(text) else text
        resetWord()
        val before = ic.getTextBeforeCursor(1, 0)?.toString() ?: ""
        val prefix = if (before.isNotEmpty() && !before[0].isWhitespace()) " " else ""
        ic.commitText(prefix + out, 1)
    }

    // ------------------------------------------------------------------
    // الحافظة
    // ------------------------------------------------------------------

    private fun loadClips() {
        clips.clear()
        val s = prefs?.getString("clips", "") ?: ""
        if (s.isNotEmpty()) {
            for (p in s.split("\u0001")) {
                if (p.isNotEmpty()) clips.add(p)
            }
        }
    }

    private fun saveClips() {
        prefs?.edit()?.putString("clips", clips.joinToString("\u0001"))?.apply()
    }

    private fun addClip(t: String) {
        val s = t.trim()
        if (s.isEmpty() || s.length > 3000) return
        if (pins.contains(s)) return
        clips.remove(s)
        clips.add(0, s)
        while (clips.size > 30) clips.removeAt(clips.size - 1)
        saveClips()
        refreshChip()
    }

    // fromCopy = true لما المستخدم ينسخ فعلاً (حدث جاي من النظام)
    private fun grabClip(fromCopy: Boolean = false) {
        try {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            val clip = cm.primaryClip ?: return
            if (clip.itemCount > 0) {
                val t = clip.getItemAt(0).coerceToText(this)?.toString() ?: return
                if (fromCopy) {
                    ignoredClip = null
                    prefs?.edit()?.remove("clip_ignored")?.apply()
                    addClip(t)
                } else if (t.trim() != ignoredClip) {
                    addClip(t)
                }
            }
        } catch (e: Exception) {
            // مش مهم
        }
    }

    private fun systemClipText(): String? {
        return try {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            val clip = cm.primaryClip
            if (clip != null && clip.itemCount > 0) {
                clip.getItemAt(0).coerceToText(this)?.toString()
            } else {
                null
            }
        } catch (e: Exception) {
            null
        }
    }

    // نمنع النص ده يرجع من حافظة النظام بعد ما اتمسح من الكيبورد
    private fun blockSystemClip(t: String) {
        ignoredClip = t
        prefs?.edit()?.putString("clip_ignored", t)?.apply()
    }

    private fun forgetClip(t: String) {
        clips.remove(t)
        saveClips()
        val cur = systemClipText()
        if (cur != null && cur.trim() == t.trim()) blockSystemClip(cur.trim())
        refreshChip()
    }

    private fun forgetAllClips() {
        clips.clear()
        saveClips()
        val cur = systemClipText()
        if (cur != null && cur.isNotBlank()) blockSystemClip(cur.trim())
        refreshChip()
    }

    // ------------------------------------------------------------------
    // أدوات الرسم
    // ------------------------------------------------------------------

    private fun dp(v: Int): Int =
        TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP, v.toFloat(), resources.displayMetrics
        ).toInt()

    // ارتفاع الزرار (بيتغير من تغيير الحجم)
    private fun kh(): Int = (dp(46) * hScale).toInt()

    private fun roundBg(color: String): GradientDrawable {
        val bg = GradientDrawable()
        bg.cornerRadius = dp(8).toFloat()
        bg.setColor(Color.parseColor(color))
        return bg
    }

    private fun newRow(): LinearLayout {
        val r = LinearLayout(this)
        r.orientation = LinearLayout.HORIZONTAL
        r.layoutDirection = View.LAYOUT_DIRECTION_LTR
        r.layoutParams = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )
        return r
    }

    private fun spacer(weight: Float): View {
        val v = View(this)
        v.layoutParams = LinearLayout.LayoutParams(0, kh(), weight)
        return v
    }

    private fun toolButton(label: String, onClick: () -> Unit): TextView {
        val t = TextView(this)
        t.text = label
        t.setTextColor(Color.WHITE)
        t.textSize = 15f
        t.gravity = Gravity.CENTER
        t.setPadding(dp(10), 0, dp(10), 0)
        t.background = roundBg(C_FUNC)
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(32))
        lp.setMargins(dp(4), dp(3), dp(4), dp(3))
        t.layoutParams = lp
        t.setOnClickListener { onClick() }
        return t
    }

    // لون الزرار مع الشفافية (لما يكون في خلفية صورة)
    private fun keyInt(color: String): Int {
        val v = Color.parseColor(color)
        return if (bgOn && (color == C_KEY || color == C_FUNC)) {
            (v and 0x00FFFFFF) or (keyAlpha shl 24)
        } else {
            v
        }
    }

    // زرار عام: ضغطة، ضغط مطوّل (قائمة اختيارات أو حدث)، وتكرار للمسح
    // pre = رقم الاختيار المظلل أول ما القائمة تفتح (-1 = مفيش)
    private fun key(
        label: String,
        weight: Float = 1f,
        color: String = C_KEY,
        hint: String? = null,
        opts: List<String> = emptyList(),
        onOpt: ((String) -> Unit)? = null,
        onLong: (() -> Unit)? = null,
        autoRepeat: Boolean = false,
        pre: Int = -1,
        textSize: Float = 18f,
        onTap: () -> Unit
    ): FrameLayout {
        val fl = FrameLayout(this)
        val lp = LinearLayout.LayoutParams(0, kh(), weight)
        lp.setMargins(dp(2), dp(3), dp(2), dp(3))
        fl.layoutParams = lp
        val bg = roundBg(color)
        bg.setColor(keyInt(color))
        fl.background = bg

        val tv = TextView(this)
        tv.text = label
        tv.setTextColor(Color.WHITE)
        tv.textSize = if (textSize == 18f || textSize == 22f) letterSize() else textSize
        tv.gravity = Gravity.CENTER
        fl.addView(
            tv,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        )

        if (hint != null) {
            val h = TextView(this)
            h.text = hint
            h.textSize = 10f
            h.setTextColor(Color.parseColor("#C8C8D0"))
            val hp = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
            hp.gravity = Gravity.TOP or Gravity.END
            hp.setMargins(0, dp(2), dp(5), 0)
            fl.addView(h, hp)
        }

        var longHandled = false
        var popupShown = false
        var selected = -1
        var downX = 0f
        var downY = 0f

        val longTask = Runnable {
            if (onLong != null) {
                longHandled = true
                onLong()
            } else if (opts.isNotEmpty()) {
                popupShown = true
                showPopup(fl, opts, pre)
                selected = pre
                highlightPopup(pre)
            }
        }

        fl.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    longHandled = false
                    popupShown = false
                    selected = -1
                    downX = e.rawX
                    downY = e.rawY
                    bg.setColor(Color.parseColor(C_PRESS))
                    if (autoRepeat) {
                        onTap()
                        startRepeat(onTap)
                    } else if (onLong != null || opts.isNotEmpty()) {
                        handler.postDelayed(longTask, 350)
                    }
                }
                MotionEvent.ACTION_MOVE -> {
                    if (popupShown) {
                        val moved = Math.abs(e.rawX - downX) > dp(10) ||
                            Math.abs(e.rawY - downY) > dp(10)
                        if (moved) {
                            val hit = popupHit(e.rawX, e.rawY)
                            if (hit >= 0) {
                                selected = hit
                            } else if (pre < 0) {
                                selected = -1
                            }
                            highlightPopup(selected)
                        }
                    }
                }
                MotionEvent.ACTION_UP -> {
                    handler.removeCallbacks(longTask)
                    stopRepeat()
                    bg.setColor(keyInt(color))
                    if (popupShown) {
                        val idx = selected
                        dismissPopup()
                        if (idx >= 0) {
                            val cb = onOpt
                            if (cb != null) cb(opts[idx])
                        } else {
                            onTap()
                        }
                    } else if (!longHandled && !autoRepeat) {
                        onTap()
                    }
                }
                MotionEvent.ACTION_CANCEL -> {
                    handler.removeCallbacks(longTask)
                    stopRepeat()
                    bg.setColor(keyInt(color))
                    dismissPopup()
                }
            }
            true
        }
        return fl
    }

    private fun startRepeat(action: () -> Unit) {
        stopRepeat()
        val r = object : Runnable {
            override fun run() {
                action()
                handler.postDelayed(this, 55)
            }
        }
        repeatTask = r
        handler.postDelayed(r, 400)
    }

    private fun stopRepeat() {
        val r = repeatTask
        if (r != null) handler.removeCallbacks(r)
        repeatTask = null
    }

    // ------------------------------------------------------------------
    // قائمة الضغط المطوّل
    // ------------------------------------------------------------------

    private fun pillBg(color: String, radiusDp: Int): GradientDrawable {
        val g = GradientDrawable()
        g.cornerRadius = dp(radiusDp).toFloat()
        g.setColor(Color.parseColor(color))
        return g
    }

    // القائمة بتترسم جوه الكيبورد نفسه (طبقة فوق الزراير)
    private fun showPopup(anchor: View, opts: List<String>, pre: Int) {
        dismissPopup()
        val ov = overlay ?: return
        val n = opts.size
        val rows = if (n <= 6) 1 else if (n <= 16) 2 else 3
        val perRow = (n + rows - 1) / rows
        val itemW = dp(40)
        val itemH = dp(44)

        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.layoutDirection = View.LAYOUT_DIRECTION_LTR
        box.background = pillBg("#F2383842", 24)
        box.setPadding(dp(6), dp(5), dp(6), dp(5))
        var r: LinearLayout? = null
        for ((i, o) in opts.withIndex()) {
            if (i % perRow == 0) {
                val nr = LinearLayout(this)
                nr.orientation = LinearLayout.HORIZONTAL
                nr.layoutDirection = View.LAYOUT_DIRECTION_LTR
                box.addView(nr)
                r = nr
            }
            val t = TextView(this)
            val c = o[0]
            t.text = if (c in 'ً'..'ْ') "◌" + o else o
            t.setTextColor(Color.WHITE)
            t.textSize = 20f
            t.gravity = Gravity.CENTER
            t.layoutParams = LinearLayout.LayoutParams(itemW, itemH)
            r?.addView(t)
            popupViews.add(t)
        }
        box.measure(
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED),
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
        )
        val w = box.measuredWidth
        val h = box.measuredHeight

        val a = IntArray(2)
        anchor.getLocationOnScreen(a)
        val o2 = IntArray(2)
        ov.getLocationOnScreen(o2)
        val keyCx = a[0] - o2[0] + anchor.width / 2
        val keyTop = a[1] - o2[1]

        val col = if (pre >= 0) pre % perRow else 0
        var x = keyCx - dp(6) - col * itemW - itemW / 2
        if (x + w > ov.width - dp(2)) x = ov.width - dp(2) - w
        if (x < dp(2)) x = dp(2)
        var y = keyTop - h - dp(4)
        if (y < 0) y = 0

        val lp = FrameLayout.LayoutParams(w, h)
        lp.gravity = Gravity.TOP or Gravity.LEFT
        lp.leftMargin = x
        lp.topMargin = y
        ov.addView(box, lp)
        pill = box
    }

    private fun popupHit(x: Float, y: Float): Int {
        val b = pill ?: return -1
        if (popupViews.isEmpty()) return -1
        val loc = IntArray(2)
        b.getLocationOnScreen(loc)
        val tol = dp(24)
        if (x < loc[0] - tol || x > loc[0] + b.width + tol) return -1
        val itemH = popupViews[0].height
        if (itemH <= 0) return -1
        var ri = ((y - loc[1] - b.paddingTop) / itemH).toInt()
        if (ri < 0) ri = 0
        if (ri >= b.childCount) ri = b.childCount - 1
        val rowV = b.getChildAt(ri) as LinearLayout
        var best = -1
        var bestD = Float.MAX_VALUE
        val l2 = IntArray(2)
        for (k in 0 until rowV.childCount) {
            val v = rowV.getChildAt(k) as TextView
            v.getLocationOnScreen(l2)
            val d = Math.abs(l2[0] + v.width / 2f - x)
            if (d < bestD) {
                bestD = d
                best = popupViews.indexOf(v)
            }
        }
        return best
    }

    private fun highlightPopup(sel: Int) {
        for ((i, v) in popupViews.withIndex()) {
            if (i == sel) v.background = pillBg("#5B8DEF", 22) else v.background = null
        }
    }

    private fun dismissPopup() {
        val p = pill
        if (p != null) {
            try {
                (p.parent as? ViewGroup)?.removeView(p)
            } catch (e: Exception) {
                // مش مهم
            }
        }
        pill = null
        popupViews.clear()
    }

    // ------------------------------------------------------------------
    // الشاشة والطبقات
    // ------------------------------------------------------------------

    override fun onCreateInputView(): View {
        val frame = KbFrame(this)
        frame.layoutDirection = View.LAYOUT_DIRECTION_LTR
        kbFrame = frame

        // طبقة 0: لون الخلفية، 1: صورة الخلفية، 2: تغميق
        val body = View(this)
        body.setBackgroundColor(Color.parseColor(C_BG))
        frame.addView(body, FrameLayout.LayoutParams(-1, -1))
        val img = ImageView(this)
        img.scaleType = ImageView.ScaleType.CENTER_CROP
        img.visibility = View.GONE
        frame.addView(img, FrameLayout.LayoutParams(-1, -1))
        bgImage = img
        val scrim = View(this)
        scrim.visibility = View.GONE
        frame.addView(scrim, FrameLayout.LayoutParams(-1, -1))
        bgScrim = scrim

        // طبقة 3: الكيبورد نفسه
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.layoutDirection = View.LAYOUT_DIRECTION_LTR
        root.setPadding(dp(3), dp(2), dp(3), dp(6))

        // الشريط العلوي
        val bar = LinearLayout(this)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.layoutDirection = View.LAYOUT_DIRECTION_LTR
        bar.gravity = Gravity.CENTER_VERTICAL
        bar.layoutParams = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            dp(46)
        )
        val mic = toolButton("🎤") { toggleMic() }
        micBtn = mic
        bar.addView(mic)

        // اقتراحات الكلمات
        val svs = ArrayList<TextView>()
        for (k in 0 until 3) {
            val t = TextView(this)
            t.setTextColor(Color.WHITE)
            t.textSize = 16f
            t.maxLines = 1
            t.ellipsize = TextUtils.TruncateAt.END
            t.gravity = Gravity.CENTER
            t.setPadding(dp(4), 0, dp(4), 0)
            t.layoutParams = LinearLayout.LayoutParams(0, dp(36), 1f)
            t.setOnClickListener {
                val sg = it.tag
                if (sg is Sug) applySug(sg)
            }
            svs.add(t)
            bar.addView(t)
        }
        sugViews = svs

        val grid = toolButton("☰") {
            layer = if (layer == L_PANEL) L_AR else L_PANEL
            resetWord()
            render()
        }
        bar.addView(grid)
        root.addView(bar)

        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.layoutDirection = View.LAYOUT_DIRECTION_LTR
        content = c
        root.addView(c)
        frame.addView(root, FrameLayout.LayoutParams(-1, -2))

        // طبقة 4: قوائم الضغط المطوّل
        val ov = FrameLayout(this)
        ov.layoutDirection = View.LAYOUT_DIRECTION_LTR
        frame.addView(ov, FrameLayout.LayoutParams(-1, -1))
        overlay = ov

        // طبقة 5: وضع تغيير الحجم
        val rl = buildResizeLayer()
        frame.addView(rl, FrameLayout.LayoutParams(-1, -1))
        resizeLayer = rl

        applyBackground()
        applyLayoutPrefs()
        render()
        return frame
    }

    // قراءة إعدادات الخلفية (صورة + تغميق + شفافية الزراير)
    private fun applyBackground() {
        val p = prefs ?: getSharedPreferences("franco", Context.MODE_PRIVATE)
        val iv = bgImage ?: return
        val sc = bgScrim ?: return
        val f = File(filesDir, "kb_bg.jpg")
        if (f.exists()) {
            if (bgStamp != f.lastModified()) {
                try {
                    val bmp = BitmapFactory.decodeFile(f.path)
                    iv.setImageBitmap(bmp)
                    bgStamp = if (bmp != null) f.lastModified() else -1L
                } catch (e: Throwable) {
                    bgStamp = -1L
                }
            }
        } else {
            iv.setImageDrawable(null)
            bgStamp = -1L
        }
        bgOn = bgStamp >= 0
        iv.visibility = if (bgOn) View.VISIBLE else View.GONE
        val dim = p.getInt("bg_dim", 35)
        sc.setBackgroundColor(Color.argb(dim * 255 / 100, 0, 0, 0))
        sc.visibility = if (bgOn) View.VISIBLE else View.GONE
        keyAlpha = if (bgOn) p.getInt("key_alpha", 60) * 255 / 100 else 255
    }

    // حجم ومكان الكيبورد المحفوظين
    private fun applyLayoutPrefs() {
        val p = prefs ?: return
        if (!resizeMode) {
            hScale = p.getFloat("kb_h", 1f).coerceIn(0.6f, 1.7f)
            kbL = p.getFloat("kb_l", 0f).coerceIn(0f, 0.55f)
            kbR = p.getFloat("kb_r", 1f).coerceIn(0.45f, 1f)
            if (kbR - kbL < 0.45f) {
                kbL = 0f
                kbR = 1f
            }
        }
        kbFrame?.setBounds(kbL, kbR)
    }

    // ------------------------------------------------------------------
    // وضع تغيير الحجم: إطار أزرق ومقابض
    // ------------------------------------------------------------------

    private fun resizeButton(label: String, onClick: () -> Unit): TextView {
        val t = TextView(this)
        t.text = label
        t.setTextColor(Color.WHITE)
        t.textSize = 15f
        t.gravity = Gravity.CENTER
        t.setPadding(dp(18), 0, dp(18), 0)
        t.background = pillBg("#4F7DF3", 22)
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(44))
        lp.setMargins(dp(6), 0, dp(6), 0)
        t.layoutParams = lp
        t.setOnClickListener { onClick() }
        return t
    }

    private fun handleBox(wDp: Int, hDp: Int, pillW: Int, pillH: Int, gravity: Int): FrameLayout {
        val box = FrameLayout(this)
        val p = View(this)
        p.background = pillBg("#4F7DF3", 4)
        box.addView(p, FrameLayout.LayoutParams(dp(pillW), dp(pillH), Gravity.CENTER))
        box.layoutParams = FrameLayout.LayoutParams(dp(wDp), dp(hDp), gravity)
        return box
    }

    private fun buildResizeLayer(): FrameLayout {
        val rl = FrameLayout(this)
        rl.visibility = View.GONE
        rl.setBackgroundColor(Color.parseColor("#55000000"))
        // بيمنع الضغط على الزراير اللي تحته
        rl.setOnTouchListener { _, _ -> true }

        val border = View(this)
        val bd = GradientDrawable()
        bd.setColor(Color.TRANSPARENT)
        bd.setStroke(dp(3), Color.parseColor("#4F7DF3"))
        bd.cornerRadius = dp(14).toFloat()
        border.background = bd
        rl.addView(border, FrameLayout.LayoutParams(-1, -1))

        // مقبض فوق: الارتفاع
        val top = handleBox(160, 34, 64, 6, Gravity.TOP or Gravity.CENTER_HORIZONTAL)
        var startY = 0f
        var startH = 1f
        top.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    startY = e.rawY
                    startH = hScale
                }
                MotionEvent.ACTION_MOVE -> {
                    val d = (startY - e.rawY) / (4f * dp(46))
                    val nh = (startH + d).coerceIn(0.6f, 1.7f)
                    if (nh != hScale) {
                        hScale = nh
                        render()
                    }
                }
            }
            true
        }
        rl.addView(top)

        // مقبض الشمال واليمين: العرض
        val left = handleBox(34, 120, 6, 64, Gravity.START or Gravity.CENTER_VERTICAL)
        left.setOnTouchListener { _, e ->
            val f = kbFrame
            if (f != null && f.width > 0 &&
                (e.actionMasked == MotionEvent.ACTION_DOWN || e.actionMasked == MotionEvent.ACTION_MOVE)
            ) {
                val loc = IntArray(2)
                f.getLocationOnScreen(loc)
                kbL = ((e.rawX - loc[0]) / f.width).coerceIn(0f, kbR - 0.45f)
                f.setBounds(kbL, kbR)
            }
            true
        }
        rl.addView(left)

        val right = handleBox(34, 120, 6, 64, Gravity.END or Gravity.CENTER_VERTICAL)
        right.setOnTouchListener { _, e ->
            val f = kbFrame
            if (f != null && f.width > 0 &&
                (e.actionMasked == MotionEvent.ACTION_DOWN || e.actionMasked == MotionEvent.ACTION_MOVE)
            ) {
                val loc = IntArray(2)
                f.getLocationOnScreen(loc)
                kbR = ((e.rawX - loc[0]) / f.width).coerceIn(kbL + 0.45f, 1f)
                f.setBounds(kbL, kbR)
            }
            true
        }
        rl.addView(right)

        // النص: تم - تحريك - إعادة ضبط
        val mid = LinearLayout(this)
        mid.orientation = LinearLayout.HORIZONTAL
        mid.layoutDirection = View.LAYOUT_DIRECTION_LTR
        mid.gravity = Gravity.CENTER
        mid.addView(resizeButton("تم ✓") { exitResizeMode(true) })

        val move = TextView(this)
        move.text = "✥"
        move.setTextColor(Color.WHITE)
        move.textSize = 22f
        move.gravity = Gravity.CENTER
        move.background = pillBg("#4F7DF3", 26)
        val mlp = LinearLayout.LayoutParams(dp(52), dp(52))
        mlp.setMargins(dp(6), 0, dp(6), 0)
        move.layoutParams = mlp
        var lastX = 0f
        move.setOnTouchListener { _, e ->
            val f = kbFrame
            if (f != null && f.width > 0) {
                when (e.actionMasked) {
                    MotionEvent.ACTION_DOWN -> lastX = e.rawX
                    MotionEvent.ACTION_MOVE -> {
                        val dx = (e.rawX - lastX) / f.width
                        lastX = e.rawX
                        val w = kbR - kbL
                        val nl = (kbL + dx).coerceIn(0f, 1f - w)
                        kbL = nl
                        kbR = nl + w
                        f.setBounds(kbL, kbR)
                    }
                }
            }
            true
        }
        mid.addView(move)

        mid.addView(resizeButton("إعادة ضبط") {
            hScale = 1f
            kbL = 0f
            kbR = 1f
            kbFrame?.setBounds(kbL, kbR)
            render()
        })
        rl.addView(mid, FrameLayout.LayoutParams(-2, -2, Gravity.CENTER))
        return rl
    }

    private fun enterResizeMode() {
        if (resizeMode) return
        resizeMode = true
        dismissPopup()
        resizeLayer?.visibility = View.VISIBLE
    }

    private fun exitResizeMode(save: Boolean) {
        if (!resizeMode) return
        resizeMode = false
        resizeLayer?.visibility = View.GONE
        if (save) {
            prefs?.edit()
                ?.putFloat("kb_h", hScale)
                ?.putFloat("kb_l", kbL)
                ?.putFloat("kb_r", kbR)
                ?.apply()
        }
    }

    // زرار آخر منسوخ في الشريط
    private fun refreshChip() {
        val c = chipView ?: return
        if (clips.isEmpty()) {
            c.text = ""
            c.background = null
        } else {
            c.text = clips[0].replace('\n', ' ').trim()
            c.background = roundBg(C_FUNC)
        }
    }

    private fun refreshToggle() {
        refreshMic()
        val b = toggleBtn ?: return
        b.text = if (francoOn) "فرانكو ✓" else "عربي"
        b.background = roundBg(if (francoOn) C_GREEN else C_FUNC)
        val a = autoBtn
        if (a != null) {
            a.text = if (autoOn) "تصحيح ✓" else "تصحيح ✗"
            a.background = roundBg(if (autoOn) C_GREEN else C_FUNC)
        }
    }

    private fun render() {
        val c = content ?: return
        dismissPopup()
        c.removeAllViews()
        when (layer) {
            L_AR -> buildArabic(c)
            L_EN -> buildEnglish(c)
            L_SYM1 -> buildSym1(c)
            L_SYM2 -> buildSym2(c)
            L_NUM -> buildNumpad(c)
            L_CLIP -> buildClipboard(c)
            L_EMO -> buildEmoji(c)
            L_PANEL -> buildPanel(c)
        }
        refreshToggle()
        refreshChip()
    }

    private fun variants(ch: Char): List<String> = when (ch) {
        'ا' -> listOf("أ", "إ", "آ", "ء")
        'و' -> listOf("ؤ")
        'ي' -> listOf("ئ", "ى")
        'ه' -> listOf("ة")
        'ب' -> listOf("پ")
        'ج' -> listOf("چ")
        'ف' -> listOf("ڤ")
        'ك' -> listOf("گ")
        'ز' -> listOf("ژ")
        'ل' -> listOf("لا", "لأ", "لإ", "لآ")
        else -> emptyList()
    }

    private val marks: List<String> = listOf(
        "َ", "ُ", "ِ", "ً", "ٌ", "ٍ", "ّ", "ْ"
    )

    // الصف الفوقاني: الرقم (غربي وعربي) أول، وبعده البدايل والتشكيل.
    // باقي الحروف: الحرف نفسه مظلل أول، وبعده البدايل والتشكيل.
    private fun arKey(ch: Char, digit: String?): FrameLayout {
        val opts = ArrayList<String>()
        if (digit != null) {
            opts.add(digit)
            opts.add(arabicIndic(digit[0]))
        } else {
            opts.add(ch.toString())
        }
        opts.addAll(variants(ch))
        opts.addAll(marks)
        return key(ch.toString(), 1f, C_KEY, digit, opts, { o ->
            val c = o[0]
            if (c.isDigit()) {
                commitOther(o)
            } else if (isMark(c)) {
                typeSymbol(o)
            } else {
                for (x in o) typeLetter(x)
            }
        }, pre = 0) {
            typeLetter(ch)
        }
    }

    private fun spaceKey(label: String, w: Float = 4f): FrameLayout =
        key(label, w, C_KEY, textSize = 14f) { commitOther(" ") }

    private fun enterKey(): FrameLayout =
        key("⏎", 1.4f, C_ACCENT) { doEnter() }

    private val enDotOpts: List<String> = listOf(
        "?", "!", ",", "'", "\"", "-", ":", ";", "(", ")", "@", "…"
    )

    private fun dotKey(english: Boolean = false): FrameLayout =
        if (english) {
            key(".", 1f, C_KEY, opts = enDotOpts, onOpt = { commitOther(it) }) { commitOther(".") }
        } else {
            key(".", 1f, C_KEY, opts = dotOpts, onOpt = { typeSymbol(it) }) { commitOther(".") }
        }

    private fun backKey(): FrameLayout =
        key("⌫", 1.5f, C_FUNC, autoRepeat = true) { doDelete() }

    // ---------------- عربي ----------------

    private fun buildArabic(c: LinearLayout) {
        val digits = "1234567890"
        val r0 = newRow()
        for ((i, ch) in "ضصثقفغعهخحج".withIndex()) {
            r0.addView(arKey(ch, if (i < 10) digits[i].toString() else null))
        }
        c.addView(r0)

        val r1 = newRow()
        for (ch in "شسيبلاتنمكط") r1.addView(arKey(ch, null))
        c.addView(r1)

        val r2 = newRow()
        for (ch in "ذءؤرىةوزظد") r2.addView(arKey(ch, null))
        r2.addView(backKey())
        c.addView(r2)

        val b = newRow()
        b.addView(key(if (francoOn) "?123" else "?١٢٣", 1.4f, C_FUNC, textSize = 14f) { go(L_SYM1) })
        b.addView(key("🌐", 1f, C_FUNC, onLong = { showPicker() }) { go(L_EN) })
        b.addView(emojiKey())
        b.addView(
            key("،", 1f, C_KEY, opts = listOf("،", ",", "؛", ":", "!", "؟", "?", "\"", "'", "-", "(", ")", "@"), onOpt = { commitOther(it) }, pre = 0) {
                commitOther("،")
            }
        )
        b.addView(spaceKey(if (francoOn) "فرانكو" else "العربية", 3f))
        b.addView(dotKey())
        b.addView(enterKey())
        c.addView(b)
    }

    // ---------------- إنجليزي ----------------

    private fun enVariants(ch: Char): List<String> = when (ch) {
        'a' -> listOf("à", "á", "â", "ä", "æ", "ã", "å", "ā")
        'c' -> listOf("ç", "ć", "č")
        'd' -> listOf("ð")
        'e' -> listOf("è", "é", "ê", "ë", "ē", "ė", "ę")
        'g' -> listOf("ğ")
        'i' -> listOf("î", "ï", "í", "ī", "į", "ì")
        'l' -> listOf("ł")
        'n' -> listOf("ñ", "ń")
        'o' -> listOf("ô", "ö", "ò", "ó", "œ", "ø", "ō", "õ")
        's' -> listOf("ß", "ś", "š")
        'u' -> listOf("û", "ü", "ù", "ú", "ū")
        'y' -> listOf("ý", "ÿ")
        'z' -> listOf("ž", "ź", "ż")
        else -> emptyList()
    }

    private fun enKey(ch: Char, digit: String?): FrameLayout {
        val shown = if (shift > 0) ch.uppercaseChar().toString() else ch.toString()
        val vs = enVariants(ch)
        val opts = ArrayList<String>()
        if (digit != null) {
            opts.add(digit)
        } else if (vs.isNotEmpty()) {
            opts.add(shown)
        }
        if (opts.isNotEmpty()) {
            for (v in vs) opts.add(if (shift > 0) v.uppercase() else v)
        }
        return key(shown, 1f, C_KEY, digit, opts, { o ->
            commitOther(o)
            if (shift == 1) {
                shift = 0
                render()
            }
        }, pre = if (opts.isNotEmpty()) 0 else -1) {
            commitOther(shown)
            if (shift == 1) {
                shift = 0
                render()
            }
        }
    }

    private fun buildEnglish(c: LinearLayout) {
        val digits = "1234567890"
        val r0 = newRow()
        for ((i, ch) in "qwertyuiop".withIndex()) r0.addView(enKey(ch, digits[i].toString()))
        c.addView(r0)

        val r1 = newRow()
        r1.addView(spacer(0.5f))
        for (ch in "asdfghjkl") r1.addView(enKey(ch, null))
        r1.addView(spacer(0.5f))
        c.addView(r1)

        val r2 = newRow()
        r2.addView(
            key(if (shift == 2) "⇪" else "⇧", 1.5f, if (shift > 0) C_ACCENT else C_FUNC) {
                val now = System.currentTimeMillis()
                shift = if (shift == 1 && now - lastShiftTap < 350) {
                    2
                } else if (shift == 0) {
                    1
                } else {
                    0
                }
                lastShiftTap = now
                render()
            }
        )
        for (ch in "zxcvbnm") r2.addView(enKey(ch, null))
        r2.addView(backKey())
        c.addView(r2)

        val b = newRow()
        b.addView(key("?123", 1.4f, C_FUNC, textSize = 14f) { go(L_SYM1) })
        b.addView(key("🌐", 1f, C_FUNC, onLong = { showPicker() }) { go(L_AR) })
        b.addView(emojiKey())
        b.addView(
            key(
                ",", 1f, C_KEY,
                opts = listOf("&", "%", "+", "\"", "-", ":", "'", "@", ";", "/", "(", ")", "#", "!", ",", "?"),
                onOpt = { commitOther(it) }, pre = 14
            ) { commitOther(",") }
        )
        b.addView(spaceKey("English", 3f))
        b.addView(dotKey(true))
        b.addView(enterKey())
        c.addView(b)
    }

    // ---------------- رموز 1 ----------------

    private fun symVariants(ch: Char): List<String> = when (ch) {
        '(' -> listOf("(", "[", "{", "<")
        ')' -> listOf(")", "]", "}", ">")
        '[' -> listOf("[", "(", "{", "<")
        ']' -> listOf("]", ")", "}", ">")
        '-' -> listOf("-", "–", "—", "•")
        '_' -> listOf("_", "—", "–", "·")
        '+' -> listOf("+", "±")
        '/' -> listOf("/", "\\", "|")
        '|' -> listOf("|", "\\", "¦")
        '$' -> listOf("\$", "¢", "£", "€", "¥", "₹", "₽")
        '&' -> listOf("&", "§")
        '#' -> listOf("#", "№")
        '"' -> listOf("\"", "„", "“", "”", "«", "»")
        '\'' -> listOf("'", "‚", "‘", "’", "‹", "›")
        '!' -> listOf("!", "¡")
        '؟' -> listOf("؟", "?")
        ':' -> listOf(":", "…")
        '*' -> listOf("*", "★", "†", "‡")
        '=' -> listOf("=", "≠", "≈", "∞")
        '%' -> listOf("%", "‰")
        '°' -> listOf("°", "′", "″")
        '^' -> listOf("^", "↑", "←", "↓", "→")
        'π' -> listOf("π", "Ω", "µ")
        '•' -> listOf("•", "♪", "♥", "♦", "♣", "♠")
        '~' -> listOf("~", "≈")
        '£' -> listOf("£", "\$", "€")
        '€' -> listOf("€", "\$", "£")
        '¥' -> listOf("¥", "\$", "€")
        '{' -> listOf("{", "[", "(", "<")
        '}' -> listOf("}", "]", ")", ">")
        else -> emptyList()
    }

    private fun symKey(ch: Char): FrameLayout {
        val s = ch.toString()
        val v = symVariants(ch)
        return key(s, 1f, C_KEY, opts = v, onOpt = { commitOther(it) }, pre = if (v.isNotEmpty()) 0 else -1) {
            commitOther(s)
        }
    }

    private fun arabicIndic(d: Char): String =
        ('٠' + (d - '0')).toString()

    private fun digitOpts(d: Char): List<String> = when (d) {
        '0' -> listOf("0", "⁰", "ⁿ", "∅", "°")
        '1' -> listOf("1", "¹", "½", "⅓", "¼", "⅕", "⅙", "⅐", "⅛", "⅑", "⅒")
        '2' -> listOf("2", "²", "⅔", "⅖")
        '3' -> listOf("3", "³", "¾", "⅗", "⅜")
        '4' -> listOf("4", "⁴", "⅘")
        '5' -> listOf("5", "⁵", "⅚", "⅝")
        '6' -> listOf("6", "⁶")
        '7' -> listOf("7", "⁷", "⅞")
        '8' -> listOf("8", "⁸")
        '9' -> listOf("9", "⁹")
        else -> listOf(d.toString())
    }

    private fun digitKey(d: Char): FrameLayout {
        val list = ArrayList<String>(digitOpts(d))
        list.add(arabicIndic(d))
        return key(d.toString(), 1f, C_KEY, opts = list, onOpt = { commitOther(it) }, pre = 0) {
            commitOther(d.toString())
        }
    }

    // أرقام عربية (١٢٣): الأساسية، والضغط المطوّل بيدي الأرقام الإنجليزي
    private fun digitKeyAr(d: Char): FrameLayout {
        val list = ArrayList<String>()
        list.add(arabicIndic(d))
        list.addAll(digitOpts(d))
        return key(arabicIndic(d), 1f, C_KEY, opts = list, onOpt = { commitOther(it) }, pre = 0) {
            commitOther(arabicIndic(d))
        }
    }

    private fun buildSym1(c: LinearLayout) {
        val r0 = newRow()
        val arSym = !francoOn
        for (d in "1234567890") {
            r0.addView(if (arSym) digitKeyAr(d) else digitKey(d))
        }
        c.addView(r0)

        val r1 = newRow()
        for (ch in "@#\$_&-+()/") r1.addView(symKey(ch))
        c.addView(r1)

        val r2 = newRow()
        r2.addView(key("=\\<", 1.5f, C_FUNC, textSize = 14f) { go(L_SYM2) })
        for (ch in (if (arSym) "*\"':؛!؟" else "*\"':;!?")) r2.addView(symKey(ch))
        r2.addView(backKey())
        c.addView(r2)

        val b = newRow()
        b.addView(key("أبج", 1.4f, C_FUNC, textSize = 14f) { go(L_AR) })
        val comma = if (arSym) "،" else ","
        b.addView(key(comma, 1f) { commitOther(comma) })
        b.addView(key("12/34", 1f, C_FUNC, textSize = 12f) { go(L_NUM) })
        b.addView(spaceKey("العربية"))
        b.addView(dotKey())
        b.addView(enterKey())
        c.addView(b)
    }

    // ---------------- رموز 2 ----------------

    private fun buildSym2(c: LinearLayout) {
        val r0 = newRow()
        for (ch in "~`|•√π÷×§∆") r0.addView(symKey(ch))
        c.addView(r0)

        val r1 = newRow()
        for (ch in "£¢€¥^°={}\\") r1.addView(symKey(ch))
        c.addView(r1)

        val r2 = newRow()
        r2.addView(key(if (francoOn) "?123" else "?١٢٣", 1.5f, C_FUNC, textSize = 14f) { go(L_SYM1) })
        for (ch in "%©®™✓[]") r2.addView(symKey(ch))
        r2.addView(backKey())
        c.addView(r2)

        val b = newRow()
        b.addView(key("أبج", 1.4f, C_FUNC, textSize = 14f) { go(L_AR) })
        b.addView(key("«", 1f) { commitOther("«") })
        b.addView(key("12/34", 1f, C_FUNC, textSize = 12f) { go(L_NUM) })
        b.addView(spaceKey("العربية"))
        b.addView(key("»", 1f) { commitOther("»") })
        b.addView(enterKey())
        c.addView(b)
    }

    // ---------------- لوحة الأرقام ----------------

    private fun numKey(label: String, weight: Float, color: String = C_KEY): FrameLayout =
        key(label, weight, color, textSize = 22f) { commitOther(label) }

    private fun buildNumpad(c: LinearLayout) {
        val ops = 0.8f
        val num = 1.4f

        val r0 = newRow()
        r0.addView(numKey("+", ops, C_FUNC))
        r0.addView(numKey("1", num))
        r0.addView(numKey("2", num))
        r0.addView(numKey("3", num))
        r0.addView(numKey("%", ops, C_FUNC))
        c.addView(r0)

        val r1 = newRow()
        r1.addView(numKey("-", ops, C_FUNC))
        r1.addView(numKey("4", num))
        r1.addView(numKey("5", num))
        r1.addView(numKey("6", num))
        r1.addView(key("␣", ops, C_FUNC) { commitOther(" ") })
        c.addView(r1)

        val r2 = newRow()
        r2.addView(numKey("*", ops, C_FUNC))
        r2.addView(numKey("7", num))
        r2.addView(numKey("8", num))
        r2.addView(numKey("9", num))
        r2.addView(key("⌫", ops, C_FUNC, autoRepeat = true) { doDelete() })
        c.addView(r2)

        val r3 = newRow()
        r3.addView(key("أبج", 1.2f, C_FUNC, textSize = 14f) { go(L_AR) })
        r3.addView(numKey("،", 0.9f))
        r3.addView(key("!?#", 1f, C_FUNC, textSize = 14f) { go(L_SYM1) })
        r3.addView(numKey("0", num))
        r3.addView(numKey("=", 0.9f))
        r3.addView(numKey(".", 0.9f))
        r3.addView(key("⏎", 1.2f, C_ACCENT) { doEnter() })
        c.addView(r3)
    }

    // ---------------- الإيموجي ----------------

    private val emoTabs = listOf(
        Pair("recent", "🕒"), Pair("smileys", "😀"), Pair("people", "👋"),
        Pair("nature", "🐶"), Pair("food", "🍔"), Pair("activities", "⚽"),
        Pair("travel", "🚗"), Pair("objects", "💡"), Pair("symbols", "🔣"),
        Pair("flags", "🏁")
    )

    private fun loadEmoji() {
        if (emoData != null) return
        val m = LinkedHashMap<String, List<String>>()
        try {
            assets.open("emoji.txt").bufferedReader(Charsets.UTF_8).useLines { lines ->
                for (line in lines) {
                    val t = line.indexOf('\t')
                    if (t > 0) {
                        m[line.substring(0, t)] =
                            line.substring(t + 1).trim().split(" ").filter { it.isNotEmpty() }
                    }
                }
            }
        } catch (e: Exception) {
            // مش مهم
        }
        emoData = m
        emoRecent.clear()
        val s = prefs?.getString("emo_recent", "") ?: ""
        for (p in s.split("\u0001")) {
            if (p.isNotEmpty()) emoRecent.add(p)
        }
    }

    private fun addEmoRecent(e: String) {
        emoRecent.remove(e)
        emoRecent.add(0, e)
        while (emoRecent.size > 32) emoRecent.removeAt(emoRecent.size - 1)
        prefs?.edit()?.putString("emo_recent", emoRecent.joinToString("\u0001"))?.apply()
    }

    private fun emojiKey(): FrameLayout =
        key("😊", 1f, C_FUNC) {
            loadEmoji()
            prevLayer = layer
            emoCat = if (emoRecent.isNotEmpty()) "recent" else "smileys"
            go(L_EMO)
        }

    private fun buildEmoji(c: LinearLayout) {
        loadEmoji()
        val tabs = newRow()
        tabs.layoutParams = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, dp(40)
        )
        for (tab in emoTabs) {
            val t = TextView(this)
            t.text = tab.second
            t.textSize = 19f
            t.gravity = Gravity.CENTER
            val lp = LinearLayout.LayoutParams(0, dp(36), 1f)
            lp.setMargins(dp(2), dp(2), dp(2), dp(2))
            t.layoutParams = lp
            if (tab.first == emoCat) t.background = pillBg("#6A6F80", 18)
            t.setOnClickListener {
                emoCat = tab.first
                render()
            }
            tabs.addView(t)
        }
        c.addView(tabs)

        val items: List<String> =
            if (emoCat == "recent") ArrayList(emoRecent) else (emoData?.get(emoCat) ?: emptyList())
        val scroll = ScrollView(this)
        scroll.layoutParams = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, dp(150)
        )
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.layoutDirection = View.LAYOUT_DIRECTION_LTR
        if (items.isEmpty()) {
            val empty = TextView(this)
            empty.text = "الإيموجي اللي بتستخدمها هتظهر هنا"
            empty.setTextColor(Color.parseColor("#C8C8D0"))
            empty.textSize = 15f
            empty.gravity = Gravity.CENTER
            empty.setPadding(dp(8), dp(50), dp(8), dp(8))
            col.addView(empty)
        }
        var row: LinearLayout? = null
        var inRow = 0
        for ((i, e) in items.withIndex()) {
            if (i % 8 == 0) {
                val r = newRow()
                col.addView(r)
                row = r
                inRow = 0
            }
            val tv = TextView(this)
            tv.text = e
            tv.textSize = 24f
            tv.gravity = Gravity.CENTER
            tv.layoutParams = LinearLayout.LayoutParams(0, dp(44), 1f)
            tv.setOnClickListener {
                addEmoRecent(e)
                commitOther(e)
            }
            row?.addView(tv)
            inRow++
        }
        if (row != null && inRow in 1..7) {
            for (k in inRow until 8) {
                val sp = View(this)
                sp.layoutParams = LinearLayout.LayoutParams(0, dp(44), 1f)
                row.addView(sp)
            }
        }
        scroll.addView(col)
        c.addView(scroll)

        val b = newRow()
        b.addView(key("أبج", 1.4f, C_FUNC, textSize = 14f) { go(prevLayer) })
        b.addView(spaceKey(if (francoOn) "فرانكو" else "العربية", 4f))
        b.addView(backKey())
        c.addView(b)
    }

    // ---------------- الحافظة ----------------

    private fun buildClipboard(c: LinearLayout) {
        val head = newRow()
        head.addView(key("أبج", 1.2f, C_FUNC, textSize = 14f) { go(L_AR) })
        val title = TextView(this)
        title.text = "الحافظة"
        title.setTextColor(Color.WHITE)
        title.textSize = 16f
        title.gravity = Gravity.CENTER
        title.layoutParams = LinearLayout.LayoutParams(0, kh(), 3f)
        head.addView(title)
        head.addView(key("مسح الكل", 1.6f, C_FUNC, textSize = 13f) {
            forgetAllClips()
            render()
        })
        c.addView(head)

        val scroll = ScrollView(this)
        scroll.layoutParams = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            dp(190)
        )
        val list = LinearLayout(this)
        list.orientation = LinearLayout.VERTICAL
        if (clips.isEmpty() && pins.isEmpty()) {
            val empty = TextView(this)
            empty.text = "انسخ أي نص وهيظهر هنا"
            empty.setTextColor(Color.parseColor("#B0B0B8"))
            empty.textSize = 15f
            empty.gravity = Gravity.CENTER
            empty.setPadding(dp(8), dp(40), dp(8), dp(8))
            list.addView(empty)
        } else {
            val all = ArrayList(clips)
            val nums = ArrayList<String>()
            val texts = ArrayList<String>()
            for (t in all) if (isNumberClip(t)) nums.add(t) else texts.add(t)
            clipSection(list, "📌 مثبّت", ArrayList(pins), true)
            clipSection(list, "🔢 أرقام", nums, false)
            clipSection(list, "💬 جمل", texts, false)
        }
        scroll.addView(list)
        c.addView(scroll)
    }

    private fun isNumberClip(t: String): Boolean {
        var digit = false
        for (c in t.trim()) {
            if (c.isDigit()) {
                digit = true
            } else if ("+-().,/ :".indexOf(c) < 0) {
                return false
            }
        }
        return digit
    }

    private fun savePins() {
        prefs?.edit()?.putString("pins", pins.joinToString("\u0001"))?.apply()
    }

    private fun loadPins() {
        pins.clear()
        val v = prefs?.getString("pins", "") ?: ""
        if (v.isNotEmpty()) {
            for (p in v.split("\u0001")) if (p.isNotEmpty()) pins.add(p)
        }
    }

    private fun clipSection(list: LinearLayout, title: String, items: List<String>, pinned: Boolean) {
        if (items.isEmpty()) return
        val h = TextView(this)
        h.text = title
        h.setTextColor(Color.parseColor("#C8C8D0"))
        h.textSize = 13f
        h.setPadding(dp(8), dp(8), dp(8), dp(2))
        list.addView(h)
        for (t in items) list.addView(clipItem(t, pinned))
    }

    private fun clipItem(text: String, pinned: Boolean): View {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.background = roundBg(C_KEY)
        val rlp = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )
        rlp.setMargins(dp(2), dp(3), dp(2), dp(3))
        row.layoutParams = rlp

        val tv = TextView(this)
        tv.text = text
        tv.setTextColor(Color.WHITE)
        tv.textSize = 15f
        tv.maxLines = 2
        tv.ellipsize = TextUtils.TruncateAt.END
        tv.setPadding(dp(12), dp(10), dp(12), dp(10))
        tv.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        tv.setOnClickListener {
            commitOther(text)
            go(L_AR)
        }

        val pin = TextView(this)
        pin.text = "📌"
        pin.textSize = 16f
        pin.alpha = if (pinned) 1f else 0.35f
        pin.gravity = Gravity.CENTER
        pin.setPadding(dp(10), dp(10), dp(10), dp(10))
        pin.setOnClickListener {
            if (pinned) {
                pins.remove(text)
                clips.remove(text)
                clips.add(0, text)
            } else {
                clips.remove(text)
                pins.remove(text)
                pins.add(0, text)
            }
            savePins()
            saveClips()
            refreshChip()
            render()
        }

        val del = TextView(this)
        del.text = "✕"
        del.setTextColor(Color.parseColor("#B0B0B8"))
        del.textSize = 16f
        del.gravity = Gravity.CENTER
        del.setPadding(dp(14), dp(10), dp(14), dp(10))
        del.setOnClickListener {
            if (pinned) {
                pins.remove(text)
                savePins()
            } else {
                forgetClip(text)
            }
            render()
        }

        row.addView(tv)
        row.addView(pin)
        row.addView(del)
        return row
    }

    // ---------------- لوحة المميزات (☰) ----------------

    private fun letterSize(): Float = (prefs?.getInt("key_text", 18) ?: 18).toFloat()

    private fun changeLetterSize(d: Int) {
        val v = ((prefs?.getInt("key_text", 18) ?: 18) + d).coerceIn(12, 28)
        prefs?.edit()?.putInt("key_text", v)?.apply()
        render()
    }

    private fun panelRow(a: View, b: View): LinearLayout {
        val r = newRow()
        r.addView(a)
        r.addView(b)
        return r
    }

    private fun buildPanel(c: LinearLayout) {
        val onl = prefs?.getBoolean("online", true) ?: true
        c.addView(
            panelRow(
                key("📋 الحافظة", 1f, C_FUNC, textSize = 15f) {
                    layer = L_CLIP
                    resetWord()
                    grabClip()
                    render()
                },
                key(if (francoOn) "فرانكو ✓" else "عربي", 1f, if (francoOn) C_GREEN else C_FUNC, textSize = 15f) {
                    francoOn = !francoOn
                    resetWord()
                    render()
                }
            )
        )
        c.addView(
            panelRow(
                key(if (autoOn) "تصحيح ✓" else "تصحيح ✗", 1f, if (autoOn) C_GREEN else C_FUNC, textSize = 15f) {
                    autoOn = !autoOn
                    prefs?.edit()?.putBoolean("autocorrect", autoOn)?.apply()
                    resetWord()
                    render()
                },
                key(if (onl) "أونلاين ✓" else "أونلاين ✗", 1f, if (onl) C_GREEN else C_FUNC, textSize = 15f) {
                    prefs?.edit()?.putBoolean("online", !onl)?.apply()
                    render()
                }
            )
        )
        c.addView(
            panelRow(
                key("حروف أصغر  A−", 1f, C_FUNC, textSize = 15f) { changeLetterSize(-2) },
                key("حروف أكبر  A+", 1f, C_FUNC, textSize = 15f) { changeLetterSize(2) }
            )
        )
        c.addView(
            panelRow(
                key("تغيير الحجم", 1f, C_FUNC, textSize = 15f) {
                    layer = L_AR
                    render()
                    enterResizeMode()
                },
                key("⚙ الإعدادات", 1f, C_FUNC, textSize = 15f) {
                    try {
                        val i = Intent(this, SettingsActivity::class.java)
                        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        startActivity(i)
                    } catch (e: Exception) {
                        // مش مهم
                    }
                }
            )
        )
        c.addView(
            panelRow(
                key("إخفاء الكيبورد ⌄", 1f, C_FUNC, textSize = 15f) { requestHideSelf(0) },
                key("أبج  رجوع", 1f, C_FUNC, textSize = 15f) { go(L_AR) }
            )
        )
    }
}

// حاوية الكيبورد: بتقيس الكيبورد (بالعرض المحدد) وبعدين الخلفية والقوائم
// طبقات: 0 لون، 1 صورة، 2 تغميق، 3 الكيبورد، 4 القوائم (على الشاشة كلها)، 5 تغيير الحجم
private class KbFrame(c: Context) : FrameLayout(c) {
    private var leftFrac = 0f
    private var rightFrac = 1f
    private var colLeft = 0
    private var colW = 0

    fun setBounds(l: Float, r: Float) {
        leftFrac = l
        rightFrac = r
        requestLayout()
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val wm = View.MeasureSpec.getMode(widthMeasureSpec)
        val fw = if (wm == View.MeasureSpec.UNSPECIFIED) {
            resources.displayMetrics.widthPixels
        } else {
            View.MeasureSpec.getSize(widthMeasureSpec)
        }
        colW = ((rightFrac - leftFrac) * fw).toInt()
        colLeft = (leftFrac * fw).toInt()
        val hm = View.MeasureSpec.getMode(heightMeasureSpec)
        val hs0 = if (hm == View.MeasureSpec.UNSPECIFIED) {
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
        } else {
            View.MeasureSpec.makeMeasureSpec(
                View.MeasureSpec.getSize(heightMeasureSpec),
                View.MeasureSpec.AT_MOST
            )
        }
        val col = getChildAt(3)
        col.measure(View.MeasureSpec.makeMeasureSpec(colW, View.MeasureSpec.EXACTLY), hs0)
        val h = col.measuredHeight
        setMeasuredDimension(fw, h)
        val cw = View.MeasureSpec.makeMeasureSpec(colW, View.MeasureSpec.EXACTLY)
        val fwS = View.MeasureSpec.makeMeasureSpec(fw, View.MeasureSpec.EXACTLY)
        val hs = View.MeasureSpec.makeMeasureSpec(h, View.MeasureSpec.EXACTLY)
        for (i in 0 until childCount) {
            if (i == 3) continue
            getChildAt(i).measure(if (i == 4) fwS else cw, hs)
        }
    }

    override fun onLayout(changed: Boolean, l: Int, t: Int, r: Int, b: Int) {
        val w = r - l
        val h = b - t
        for (i in 0 until childCount) {
            val v = getChildAt(i)
            if (i == 4) {
                v.layout(0, 0, w, h)
            } else {
                v.layout(colLeft, 0, colLeft + colW, h)
            }
        }
    }
}
